﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Shared.Model;
using SLSiteService.Model;
using SLSiteService.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SiteRoleController : ControllerBase
    {
        private readonly ISiteService _siteService;
        private readonly ILogger<SiteRoleController> _logger;
        private readonly IOptions<ApplicationSettings> applicationsettings;
        private readonly IHttpContextAccessor _accessor;

        public SiteRoleController(ISiteService siteService, IOptions<ApplicationSettings> application, IHttpContextAccessor accessor, ILogger<SiteRoleController> logger)
        {
            _siteService = siteService;
            _logger = logger;
            applicationsettings = application;
            _accessor = accessor;
        }

        [HttpGet]
        [Route("GetRolesList")]
        public async Task<IActionResult> GetRolesList(int id)
        {
            ResponseModel result = await _siteService.GetRolesList(id);
            return Ok(result);
        }

        [HttpGet]
        [Route("GetRoleById")]
        public async Task<IActionResult> GetRoleById(int id)
        {
            ResponseModel result = await _siteService.GetRoleById(id);
            return Ok(result);
        }

        [HttpPost]
        [Route("SaveUserRole")]
        public async Task<IActionResult> SaveUserRole(UserRolesModel model)
        {
            ResponseModel result = await _siteService.SaveUserRole(model);
            return Ok(result);
        }

        [HttpPost]
        [Route("UpdateUserRole")]
        public async Task<IActionResult> UpdateUserRole(UserRolesModel model)
        {
            ResponseModel result = await _siteService.UpdateUserRole(model);
            return Ok(result);
        }

        [HttpPost]
        [Route("DeleteUserRole")]
        public async Task<IActionResult> DeleteUserRole([FromBody] int id)
        {
            ResponseModel result = await _siteService.DeleteUserRole(id);
            return Ok(result);
        }

    }
}

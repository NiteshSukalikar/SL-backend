﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Shared.Model;
using SLSiteService.Model;
using SLSiteService.Models;
using SLSiteService.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SiteInventoryController : ControllerBase
    {
        private readonly ISiteService _siteService;
        private readonly ILogger<SiteInventoryController> _logger;
        private readonly IOptions<ApplicationSettings> applicationsettings;
        private readonly IHttpContextAccessor _accessor;

        public SiteInventoryController(ISiteService siteService, IOptions<ApplicationSettings> application, IHttpContextAccessor accessor, ILogger<SiteInventoryController> logger)
        {
            _siteService = siteService;
            _logger = logger;
            applicationsettings = application;
            _accessor = accessor;
        }

        [HttpPost]
        [Route("GetDetails")]
        public async Task<IActionResult> GetDetails([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.GetDetails(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("AddStudyInventory")]
        public async Task<IActionResult> AddStudyInventory(StudyInventoryModel inventoryModel)
        {
            ResponseModel result = await _siteService.AddStudyInventory(inventoryModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("UpdateStudyInventory")]
        public async Task<IActionResult> UpdateStudyInventory(CSInventoryModel inventoryModel)
        {
            ResponseModel result = await _siteService.UpdateStudyInventory(inventoryModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetStudyInventoryByCSGuid")]
        public async Task<IActionResult> GetStudyInventoryByCSGuid([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.GetStudyInventoryByCSGuid(guidModel);
            return Ok(result);
        }

        [HttpGet]
        [Route("GetCodeList")]
        public async Task<IActionResult> GetCodeList(int type)
        {
            ResponseModel result = await _siteService.GetCodeList(type);
            return Ok(result);
        }

        [HttpPost]
        [Route("DeleteInventory")]
        public async Task<IActionResult> DeleteInventory([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.DeleteInventory(guidModel);
            return Ok(result);
        }


        [HttpPost]
        [Route("SearchInventory")]
        public async Task<IActionResult> SearchInventory([FromBody] SearchModelInventory searchModel)
        {

            ResponseModel result = await _siteService.SearchInventory(searchModel);
            return Ok(result);
        }


    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Shared.Model;
using SLSiteService.Model;
using SLSiteService.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SiteParticipantController : ControllerBase
    {
        private readonly ISiteService _siteService;
        private readonly ILogger<SiteParticipantController> _logger;
        private readonly IOptions<ApplicationSettings> applicationsettings;
        private readonly IHttpContextAccessor _accessor;
        private readonly IOptions<MailconfigModel> mailSmtpCred;

        public SiteParticipantController(ISiteService siteService, IOptions<ApplicationSettings> application, IHttpContextAccessor accessor, IOptions<MailconfigModel> app, ILogger<SiteParticipantController> logger)
        {
            _siteService = siteService;
            _logger = logger;
            applicationsettings = application;
            _accessor = accessor;
            mailSmtpCred = app;
        }

        [HttpPost]
        [Route("SearchParticipant")]
        public async Task<IActionResult> SearchParticipant(ParticipantModel searchModel)
        {
            ResponseModel result = await _siteService.SearchParticipant(searchModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetParticipantInviteList")]
        public async Task<IActionResult> GetParticipantInviteList(ParticipantModel participant)
        {
            ResponseModel result = await _siteService.GetParticipantInviteList(participant);
            return Ok(result);
        }

        [HttpPost]
        [Route("AdminInvite")]
        public async Task<IActionResult> AdminInvite(ParticipantModel participantModel)
        {
            ResponseModel result = await _siteService.AdminInviteForParticipant(participantModel, mailSmtpCred);
            return Ok(result);
        }

        [HttpPost]
        [Route("AcceptInvitationForParticipant")]
        public async Task<IActionResult> AcceptInvitationForParticipant(AcceptInviteModel model)
        {
            ResponseModel result = await _siteService.AcceptInviteForParticipant(model);
            return Ok(result);
        }

        [HttpPost]
        [Route("DeleteParticipant")]
        public async Task<IActionResult> DeleteParticipant([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.DeleteParticipant(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("BlockUnblockParticipant")]
        public async Task<IActionResult> BlockUnblockParticipant([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.BlockUnblockParticipant(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetParticipantInvite")]
        public async Task<IActionResult> GetParticipant([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.GetParticipant(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("UpdateAdminInvite")]
        public async Task<IActionResult> UpdateAdminInvite(ParticipantModel participantModel)
        {
            ResponseModel result = await _siteService.UpdateAdminInviteForParticipant(participantModel, mailSmtpCred);
            return Ok(result);
        }

        [HttpPost]
        [Route("ActiveInactiveParticipant")]
        public async Task<IActionResult> ActiveInactiveParticipant([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.ActiveInactiveParticipant(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetParticipantDetails")]
        public async Task<IActionResult> GetParticipantDetails([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.GetParticipantDetails(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("UpdateUserparticipantDetails")]
        public async Task<IActionResult> UpdateUserparticipantDetails([FromBody] UserDetailProfileModel userModel)
        {
            ResponseModel result = await _siteService.UpdateUserparticipantDetails(userModel);
            return Ok(result);
        }


    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Shared.Model;
using SLSiteService.Model;
using SLSiteService.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SiteInvestigatorController : ControllerBase
    {
        private readonly ISiteService _siteService;
        private readonly ILogger<SiteInvestigatorController> _logger;
        private readonly IOptions<ApplicationSettings> applicationsettings;
        private readonly IHttpContextAccessor _accessor;
        private readonly IOptions<MailconfigModel> mailSmtpCred;

        public SiteInvestigatorController(ISiteService siteService, IOptions<ApplicationSettings> application, IHttpContextAccessor accessor, IOptions<MailconfigModel> app, ILogger<SiteInvestigatorController> logger)
        {
            _siteService = siteService;
            _logger = logger;
            applicationsettings = application;
            _accessor = accessor;
            mailSmtpCred = app;
        }

        [HttpPost]
        [Route("SiteViewPrincipalByRoleId")]
        public async Task<IActionResult> SiteViewPrincipalByRoleId([FromBody] RoleModelData roleModel)
        {
            ResponseModel result = await _siteService.SiteViewPrincipalByRoleId(roleModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("SearchPrincipalInvestigator")]
        public async Task<IActionResult> SearchPrincipalInvestigator(StaffModel searchModel)
        {
            ResponseModel result = await _siteService.SearchPrincipalInvestigator(searchModel);
            return Ok(result);
        }
    }
}

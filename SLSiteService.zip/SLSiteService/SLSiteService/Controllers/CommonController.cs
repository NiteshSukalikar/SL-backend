﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Shared.Model;
using SLSiteService.Model;
using SLSiteService.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommonController : ControllerBase
    {  
        private readonly ISiteService _siteService;

        public CommonController(ISiteService siteService)
        {
            _siteService = siteService;
        }

        [HttpGet]
        [Route("GetCountry")]
        public async Task<IActionResult> GetCountry()
        {
            ResponseModel result = await _siteService.GetCountry();
            return Ok(result);
        }

        [HttpGet]
        [Route("GetState")]
        public async Task<IActionResult> GetState(int id)
        {
            ResponseModel result = await _siteService.GetStateCountrywise(id);
            return Ok(result); 
        }
        [HttpGet]
        [Route("GetCity")]
        public async Task<IActionResult> GetCity(int id)
        {
            ResponseModel result = await _siteService.GetCityStatewise(id);
            return Ok(result);
        }

        #region Menu Permission
        [HttpGet]
        [Route("GetActionWithMenu")]
        public async Task<IActionResult> GetActionWithMenu(long UserId)
        {
            ResponseModel result = await _siteService.GetMenuActionList(UserId);
            return Ok(result);
        }
        [HttpPost]
        [Route("GivePermission")]
        public async Task<IActionResult> GivePermission(List<MenuActionModel> list)
        {
            ResponseModel result = await _siteService.GiveActionPermission(list);
            return Ok(result);
        }
        [HttpGet]
        [Route("GetMenuPermissionForEdit")]
        public async Task<IActionResult> GetMenuPermissionForEdit(long RoleId)
        {
            ResponseModel result = await _siteService.GetMenuPermissionForEdit(RoleId);
            return Ok(result);
        }

        #endregion

        #region UserDetails


        [HttpPost]
        [Route("GetUserDetails")]
        public async Task<IActionResult> GetUserDetails([FromBody] UserInputModel model)
        {
            ResponseModel result = await _siteService.GetUserDetails(model);
            return Ok(result);
        }


        [HttpPost]
        [Route("UpdateUserDetails")]
        public async Task<IActionResult> UpdateUserDetails([FromBody] UserDetailProfileModel userModel)
        {
            ResponseModel result = await _siteService.UpdateUserDetails(userModel);
            return Ok(result);
        }

        #endregion
    }
}

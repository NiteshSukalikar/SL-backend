﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Shared.Model;
using SLSiteService.Model;
using SLSiteService.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SiteStaffController : ControllerBase
    {
        private readonly ISiteService _siteService;
        private readonly ILogger<SiteStaffController> _logger;
        private readonly IOptions<ApplicationSettings> applicationsettings;
        private readonly IHttpContextAccessor _accessor;
        private readonly IOptions<MailconfigModel> mailSmtpCred;

        public SiteStaffController(ISiteService siteService, IOptions<ApplicationSettings> application, IHttpContextAccessor accessor, IOptions<MailconfigModel> app, ILogger<SiteStaffController> logger)
        {
            _siteService = siteService;
            _logger = logger;
            applicationsettings = application;
            _accessor = accessor;
            mailSmtpCred = app;
        }


        [HttpPost]
        [Route("SearchStaff")]
        public async Task<IActionResult> SearchStaff(StaffModel searchModel)
        {
            ResponseModel result = await _siteService.SearchStaff(searchModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("AdminInvite")]
        public async Task<IActionResult> AdminInvite(StaffModel staffModel)
        {
            ResponseModel result = await _siteService.AdminInviteForStaff(staffModel, mailSmtpCred);
            return Ok(result);
        }

        [HttpPost]
        [Route("AcceptInvitation")]
        public async Task<IActionResult> AcceptInvitation(AcceptInviteModel model)
        {
            ResponseModel result = await _siteService.AcceptInvite(model);
            return Ok(result);
        }

        [HttpPost]
        [Route("DeleteStaff")]
        public async Task<IActionResult> DeleteStaff([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.DeleteStaff(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetStaffDetails")]
        public async Task<IActionResult> GetStaffDetails([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.GetStaffDetails(guidModel);
            return Ok(result);
        }

        //[HttpPost]
        //[Route("BlockUnblockStaff")]
        //public async Task<IActionResult> BlockUnblockStaff([FromBody] GuidModel guidModel)
        //{
        //    ResponseModel result = await _usersService.BlockUnblockStaff(guidModel);
        //    return Ok(result);
        //}

        [HttpPost]
        [Route("GetStaffInviteList")]
        public async Task<IActionResult> GetStaffInviteList(StaffModel staffModel)
        {
            ResponseModel result = await _siteService.GetStaffInviteList(staffModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetStaffInvite")]
        public async Task<IActionResult> GetStaffInvite([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.GetStaffInvite(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("ViewInviteStaffById")]
        public async Task<IActionResult> ViewInviteStaffById([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.ViewInviteStaffById(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("UpdateAdminInvite")]
        public async Task<IActionResult> UpdateAdminInvite(StaffModel staffModel)
        {
            ResponseModel result = await _siteService.UpdateAdminInviteForStaff(staffModel, mailSmtpCred);
            return Ok(result);
        }

        [HttpPost]
        [Route("ActiveInactiveStaff")]
        public async Task<IActionResult> ActiveInactiveStaff([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.ActiveInactiveStaff(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("UpdateStaffDetails")]
        public async Task<IActionResult> UpdateStaffDetails([FromBody] StaffDetailsModel staffModel)
        {
            ResponseModel result = await _siteService.UpdateStaffDetails(staffModel);
            return Ok(result);
        }
    }
}

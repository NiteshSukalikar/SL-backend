﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Shared.Model;
using SLSiteService.Model;
using SLSiteService.Service.Interface;
using System.Threading.Tasks;

namespace SLSiteService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SiteAuthController : ControllerBase
    {
        private readonly ISiteService _siteService;
        private readonly ILogger<SiteAuthController> _logger;
        private readonly IOptions<ApplicationSettings> applicationsettings;
        private readonly IHttpContextAccessor _accessor;

        public SiteAuthController(ISiteService siteService, IOptions<ApplicationSettings> application, IHttpContextAccessor accessor, ILogger<SiteAuthController> logger)
        {
            _siteService = siteService;
            _logger = logger;
            applicationsettings = application;
            _accessor = accessor;
        }

        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login([FromBody] LoginModel loginVM)
        {
            ResponseModel result = new ResponseModel();
            result.StatusCode = "205";
            loginVM.ipAddress = "";
            loginVM.Country = "";
            result = await _siteService.Login(loginVM);
            return Ok(result);
        }

        [HttpPost]
        [Route("resendOTP")]
        public async Task<IActionResult> resendOTP([FromBody] resendOTPModel resendOTPModel)
        {
            ResponseModel result = new ResponseModel();
            result.StatusCode = "205";
            result = await _siteService.resendOTP(resendOTPModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("LoginOTPVerification")]
        public async Task<IActionResult> LoginOTPVerification([FromBody] OTPModel model)
        {
            GeoData geodata = new GeoData();
            model.ipAddr = "";
            model.Country = "";
            ResponseModel result = await _siteService.LoginOTPVerification(model);
            return Ok(result);
        }
    }
}

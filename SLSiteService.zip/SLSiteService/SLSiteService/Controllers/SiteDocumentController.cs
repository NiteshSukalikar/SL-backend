﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Shared.Helper;
using Shared.Model;
using SLSiteService.Model;
using SLSiteService.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SiteDocumentController : ControllerBase
    {
        private readonly ISiteService _siteService;
        private readonly ILogger<SiteDocumentController> _logger;
        private readonly IOptions<ApplicationSettings> applicationsettings;
        private readonly CommonMethods _commonMethods;

        public SiteDocumentController(ISiteService siteService, IOptions<ApplicationSettings> application, IHttpContextAccessor accessor, ILogger<SiteDocumentController> logger, IOptions<MailconfigModel> app)
        {
            _siteService = siteService;
            _logger = logger;
            applicationsettings = application;
            _commonMethods = new CommonMethods();
        }


        [HttpPost]
        [Route("SaveDocument")]
        public async Task<IActionResult> SaveDocument(DocumentCenterModel documentCenterModel)
        {
            ResponseModel result = await _siteService.SaveDocument(documentCenterModel);
            return Ok(result);
        }



        [HttpPost]
        [Route("GetDocumentById")]
        public async Task<IActionResult> GetDocumentById([FromBody] SearchModel searchModel)
        {
            ResponseModel result = await _siteService.GetDocumentCenterFilesId(searchModel);
            return Ok(result);
        }


        [HttpGet]
        [Route("GetExistingDocumentTitlesById")]
        public async Task<IActionResult> GetExistingDocumentTitlesById(int id)
        {
            ResponseModel result = await _siteService.GetExistingDocumentTitlesById(id);
            return Ok(result);
        }

        [HttpGet]
        [Route("GetFiledownloadBylink")]
        public async Task<IActionResult> GetFiledownloadBylink(string link)
        {
            ResponseModel result = await _siteService.GetFiledownloadBylink(link);
            return Ok(result);
        }
    }
}

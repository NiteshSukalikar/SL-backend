﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Shared.Model;
using SLSiteService.Model;
using SLSiteService.Models;
using SLSiteService.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SiteStudyController : ControllerBase
    {
        private readonly ISiteService _siteService;
        private readonly ILogger<SiteStudyController> _logger;
        private readonly IOptions<ApplicationSettings> applicationsettings;
        private readonly IHttpContextAccessor _accessor;

        public SiteStudyController(ISiteService siteService, IOptions<ApplicationSettings> application, IHttpContextAccessor accessor, ILogger<SiteStudyController> logger)
        {
            _siteService = siteService;
            _logger = logger;
            applicationsettings = application;
            _accessor = accessor;
        }

        [HttpPost]
        [Route("AddStudy")]
        public async Task<IActionResult> AddStudy(StudyInsertionModel Studies)
        {
            ResponseModel result = await _siteService.AddStudyInsertion(Studies);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetCSList")]
        public async Task<IActionResult> GetCSList([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.GetCSDetailList(guidModel);
            return Ok(result);
        }
        [HttpPost]
        [Route("GetStudyByCSGuid")]
        public async Task<IActionResult> GetStudyByCSGuid([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.GetStudyInsertionByCSGuid(guidModel);
            return Ok(result);
        }
        [HttpPost]
        [Route("DeleteStudyByCSGuid")]
        public async Task<IActionResult> DeleteStudyByCSGuid([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.DeleteStudyByCSGuid(guidModel);
            return Ok(result);
        }
        [HttpPost]
        [Route("ActiveInactiveStudy")]
        public async Task<IActionResult> ActiveInactiveStudyByCSGuid([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _siteService.ActiveInactiveStudyByCSGuid(guidModel);
            return Ok(result);
        }
        [HttpPost]
        [Route("UpdateStudy")]
        public async Task<IActionResult> UpdateStudy(StudyInsertionModel Studies)
        {
            Guid csGuid = (Guid)Studies.CSDetailsModels.CSGuiD;
            ResponseModel result = await _siteService.UpdateStudyInsertion(Studies, csGuid);
            return Ok(result);
        }
        [HttpPost]
        [Route("SearchStudies")]
        public async Task<IActionResult> SearchStudies(CSDetailsModel model)
        {

            ResponseModel result = await _siteService.SearchStudies(model);
            return Ok(result);
        }

    }
}

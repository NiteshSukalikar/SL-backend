﻿
using Shared.Model;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Threading;

namespace SLSiteService.Common
{
    public class MailConfig
    {
        private Attachment Attachment;

        public void SendEmail(string ReceiverEmail, List<string> CCReceiverEmail, List<string> BCCReceiverEmail, string EmailSubject, string EmailBody, List<string> AttachZipFilePath, Microsoft.Extensions.Options.IOptions<MailconfigModel> mailSmtpCred)
        {
            try
            {
                String FROM = mailSmtpCred.Value.FROM;
                String FROMNAME = mailSmtpCred.Value.FROMNAME;
                String SMTP_USERNAME = mailSmtpCred.Value.SMTP_USERNAME;
                String SMTP_PASSWORD = mailSmtpCred.Value.SMTP_PASSWORD;
                String HOST = mailSmtpCred.Value.HOST;
                int PORT = mailSmtpCred.Value.PORT;

                Thread T1 = new Thread(delegate ()
                {
                    MailMessage message = new MailMessage();
                    message.IsBodyHtml = true;
                    message.From = new MailAddress(FROM, FROMNAME);
                    if (!string.IsNullOrWhiteSpace(ReceiverEmail))
                    {
                        message.To.Add(new MailAddress(ReceiverEmail));
                        if (CCReceiverEmail != null)
                        {
                            if (CCReceiverEmail.Count > 0)
                            {
                                foreach (var CCMail in CCReceiverEmail)
                                {
                                    message.CC.Add(CCMail);
                                }
                            }
                        }
                        if (BCCReceiverEmail != null)
                        {
                            if (BCCReceiverEmail.Count > 0)
                            {
                                foreach (var BCCMail in BCCReceiverEmail)
                                {
                                    message.Bcc.Add(BCCMail);
                                }
                            }
                        }

                        message.IsBodyHtml = true;
                        message.Subject = EmailSubject;
                        message.Body = EmailBody;

                        if (AttachZipFilePath != null)
                        {
                            foreach (var eachAttachZip in AttachZipFilePath)
                            {
                                Attachment = new Attachment(eachAttachZip);
                                if (Attachment != null) { message.Attachments.Add(Attachment); }
                            }
                        }
                        using (var client = new System.Net.Mail.SmtpClient(HOST, PORT))
                        {
                            // Pass SMTP credentials
                            client.Credentials =
                                new NetworkCredential(SMTP_USERNAME, SMTP_PASSWORD);
                            // Enable SSL encryption
                            client.EnableSsl = true;
                            {
                                {
                                    client.Send(message);
                                }
                            }
                        }
                    }
                    else
                    {
                        string Message = "Receiver email is blank " + EmailSubject;
                        string filePath = AppDomain.CurrentDomain.BaseDirectory;
                        filePath = filePath + "/LogFiles/EmailErrorLogFile.txt";
                        // LogFile.LogFileWrite(Message, filePath);
                    }
                });
                T1.Start();
            }
            catch (Exception ex)
            {
                string Message = ReceiverEmail + " " + EmailSubject + " " + ex;
                string filePath = AppDomain.CurrentDomain.BaseDirectory;
                filePath = filePath + "/LogFiles/EmailErrorLogFile.txt";
                // LogFile.LogFileWrite(Message, filePath);
            }
        }

    }
}

﻿namespace SLSiteService.Common.StaticConstants
{
    /// <summary>
    /// Constants for Stored Procedure Names
    /// Defines the <see cref="SpConstants" />
    /// </summary>
    public static class SpConstants
    {
        #region Auth SP
        public const string GetUserDetailsForLogin = "USP_GetUserDetailsForLogin";
        public const string GetUserById = "USP_GetUserById";
        public const string SaveLogUserSystem = "USP_SaveLogUserSystem";
        public const string UIGetNavMenuForSponser = "USP_UIGetMenuWithPermission";
        public const string Logout = "USP_Logout";
        #endregion

        #region Common SP
        public const string GetCountryList = "USP_GetCountryList";
        public const string GetStateListCountrywise = "USP_GetStateListCountrywise";
        public const string GetCityListStatewise = "USP_GetCityListStatewise";

        public const string UIGetMenuActionList = "USP_GetMenuActionList";
        public const string UIPermissionEntry = "USP_PermissionEntry";
        public const string UIGetMenuWithPermissionForRole = "USP_UIGetMenuWithPermissionForRole";

        
        // User Profile Details
        public const string GetUserDetails = "USP_GetUserDetailsForProfile";
        public const string UpdateUserDetails = "USP_UpdateUserProfileDetails";
        #endregion

        #region Document Center
        public const string SaveDocument = "USP_AddDocument";
        public const string GetDocumentById = "USP_GetDocumentById";
        public const string GetFolderStructurePath = "USP_GetFolderPath";
        public const string GetExistingDocumentTitlesById = "USP_GetExistingDocumentTitlesById";
        #endregion

        #region User Roles
        public const string GetRolesList = "USP_GetMasterRole";
        public const string GetRolesByID = "USP_GetUserRole";
        public const string SaveUserRole = "USP_AddMasterRoles";
        public const string UpdateUserRole = "USP_UpdateUserRoles";
        public const string DeleteUserRole = "USP_DeleteUserRole";
        #endregion

        #region Staff Service
        public const string SearchStaff = "USP_StaffSearch";
        public const string GetStaffDetails = "USP_GetStaffDetails";
        public const string SaveInvite_Staff = "USP_AddAccountInvites";
        public const string DeleteStaff = "USP_DeleteStaff";
        public const string GetStaffInvite = "USP_GetSponsor_StaffInvite_List";
        public const string ViewStaffInviteById = "USP_ViewSponsor_Staff_InviteById";
        public const string UpdateInvite_Staff = "USP_UpdateInvite_Staff";
        public const string GetStaffAdminInvite = "USP_GetStaffInvite";
        public const string ActiveInactiveStaff = "USP_ActiveInactiveStaff";
        public const string UpdateStaffDetails = "USP_UpdateStaffDetails";

        //for sending Emails
        public const string EmailTemplate = "USP_GetEmailTemplateByCode";
        public const string AdminInviteUrlSave = "USP_AdminInviteUrlSave";

        //for Accept invitation
        public const string AcceptInvite = "USP_AcceptInvite";
        #endregion

        #region Study
        public const string AddStudyInvention = "USP_AddStudyInvention";
        public const string GETStudyList = "USP_GetStudyList";
        public const string GETStudyByCSGuID = "USP_GetStudyByCSGuID";
        public const string DeleteStudy = "USP_DELETESTUDY";
        public const string ActiveInactiveStudy = "USP_ActiveInactiveStudy";
        public const string UpdateStudyInvention = "USP_UpdateStudyWithChild";
        public const string SearchStudies = "USP_CSDetailsSearch";
        #endregion

        #region Inventory      
        public const string AddStudyInventory = "USP_AddStudyInventory";
        public const string UpdateStudyInventory = "USP_UpdateStudyInventory";
        public const string GetStudyInventoryByCSGuID = "USP_GetStudyInventoryByCSGuID";
        public const string GetStudyCodeList = "USP_GetCodesList";
        public const string SearchInventory = "USP_SearchInventory";
        public const string DeleteInventory = "USP_DeleteInventory";
        public const string GetInventoryRecord = "USP_GetInventoryRecord";
        #endregion

        #region Participant
        public const string SearchParticipant = "USP_ParticipantSearch";
        public const string GetParticipantInviteList = "USP_GetOrganization_ParticipantInvite_List";
        public const string UpdateInvite_Participant = "USP_UpdateInvite_Participant";
        public const string DeleteParticipant = "USP_DeleteParticipant";
        public const string BlockUnblockParticipant = "USP_BlockUnblockParticipant";
        public const string GetParticipantInvite = "USP_ViewOrganization_Participant_InviteById";
        public const string AddAccountInvites = "USP_AddAccountInvites";
        public const string GetParticipantDetails = "USP_GetParticipantDetails";
        public const string ActiveInactiveParticipant = "USP_ActiveInactiveParticipant";

        public const string GetUserParticipantDetails = "USP_GetUserParticipantDetailsForProfile";
        public const string UpdateUserParticipantDetails = "USP_UpdateUserParticipantProfileDetails";
        #endregion

        #region Principal Investigator
        public const string ViewPrincipalInvestigatorList = "USP_ViewPrincipalInvestigatorList"; 
        public const string SearchPrincipalInvestigator = "USP_PrincipalInvestigatorSearch";
        #endregion
    }
}

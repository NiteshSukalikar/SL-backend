﻿
using SLSiteService.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace SLSiteService.Common
{
    public static class FileUploadUtility
    {
        public static string UploadBase64File(string file)
        {
            if (!string.IsNullOrEmpty(file))
            {
                string FileName = string.Empty;
                try
                {

                    file.Replace("\"", "");
                    string base64data = Regex.Match(file, @"(?<type>.+?),(?<data>.+)").Groups["data"].Value;
                    string extension = Regex.Match(file, @"data:image/(?<type>.+?),(?<data>.+)").Groups["type"].Value.Split(';')[0];
                    string filename = Guid.NewGuid().ToString();
                    filename = filename.Replace(" ", "_").Replace(":", "_");
                    filename = filename + "." + extension;
                    byte[] imageBytes = Convert.FromBase64String(base64data);
                    FileName = filename;

                    var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), "images\\");

                    if (!Directory.Exists(pathToSave))
                    {
                        Directory.CreateDirectory(pathToSave);
                    }
                    pathToSave = pathToSave + FileName;
                    File.WriteAllBytes(pathToSave, imageBytes);
                    // var s = GetBase64File(FileName);
                    //DeleteOldBase64File(FileName);
                }
                catch (Exception ex)
                {

                }
                return FileName;
            }
            return string.Empty;
        }
        public static string UploadBase64MultipleFile(string file, string fileExtention, string fileLocation) //filepath parameter
        {            
            if (!string.IsNullOrEmpty(file))
            {
                string FileName = string.Empty;
                try
                {

                    file.Replace("\"", "");
                    string base64data = Regex.Match(file, @"(?<type>.+?),(?<data>.+)").Groups["data"].Value;
                    string extension = fileExtention;
                    string filename = Guid.NewGuid().ToString();
                    filename = filename.Replace(" ", "_").Replace(":", "_");
                    filename = filename + "." + extension;
                    byte[] documentFileBytes = Convert.FromBase64String(base64data);
                   

                    var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), "DocumentCenter\\" + fileLocation + "//");

                    if (!Directory.Exists(pathToSave))
                    {
                        Directory.CreateDirectory(pathToSave);
                    }
                    FileName = filename;
                    pathToSave = pathToSave + FileName;
                    File.WriteAllBytes(pathToSave, documentFileBytes);
                }
                catch (Exception ex)
                {
                   
                }
                return FileName;
            }
            return string.Empty;
        }

        public static string UploadConsentFormbase64(string file, string fileExtention, string fileLocation) //filepath parameter
        {            
            if (!string.IsNullOrEmpty(file))
            {
                string FileName = string.Empty;
                try
                {

                    file.Replace("\"", "");
                    string base64data = Regex.Match(file, @"(?<type>.+?),(?<data>.+)").Groups["data"].Value;
                    string extension = fileExtention;
                    string filename = Guid.NewGuid().ToString();
                    filename = filename.Replace(" ", "_").Replace(":", "_");
                    filename = filename + "." + extension;
                    byte[] documentFileBytes = Convert.FromBase64String(base64data);
                   

                    var pathToSave = Path.Combine(Directory.GetCurrentDirectory(),  fileLocation + "//");

                    if (!Directory.Exists(pathToSave))
                    {
                        Directory.CreateDirectory(pathToSave);
                    }
                    FileName = filename;
                    pathToSave = pathToSave + FileName;
                    File.WriteAllBytes(pathToSave, documentFileBytes);
                }
                catch (Exception ex)
                {
                   
                }
                return FileName;
            }
            return string.Empty;
        }
        public static List<SaveFileList> UploadBase64MultipleFileList(List<DocumentCenterFileModel> FileModel) //filepath parameter
        {
            List<SaveFileList> fList = new List<SaveFileList>();
            if (FileModel.Count>0)
            {
                foreach (var CSfile in FileModel)
                {
                   
                    string file = CSfile.OriginalFileNameBase64;
                    string fileExtention = CSfile.FileExtension;
                   
                    string FileName = string.Empty;
                    try
                    {

                        file.Replace("\"", "");
                        string base64data = Regex.Match(file, @"(?<type>.+?),(?<data>.+)").Groups["data"].Value;
                        string extension = fileExtention;
                        string filename = Guid.NewGuid().ToString();
                        filename = filename.Replace(" ", "_").Replace(":", "_");
                        filename = filename + "." + extension;
                        byte[] documentFileBytes = Convert.FromBase64String(base64data);

                        var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), "CSStudyDoc//");
                        if (!Directory.Exists(pathToSave))
                        {
                            Directory.CreateDirectory(pathToSave);
                        }
                        FileName = filename;
                        pathToSave = pathToSave + FileName;
                        File.WriteAllBytes(pathToSave, documentFileBytes);

                        SaveFileList fObj = new SaveFileList()
                        {
                           FileNameGuid= FileName,
                           OriginalName= CSfile.OriginalFileName,
                           Extension = extension
                        };
                        fList.Add(fObj);
                    }
                    catch (Exception ex)
                    {

                    }

                }
            }
            return fList;
        }
        public static string GetBase64FileBylink(string link)
        {
            string base64 = string.Empty;
            string fileExtention = String.Empty;
            if (!string.IsNullOrEmpty(link))
            {
                var extArr = link.Split('.');
                fileExtention = extArr[1];
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), "DocumentCenter\\") + link;

                byte[] fileArray = System.IO.File.ReadAllBytes(pathToSave);
                base64 = Convert.ToBase64String(fileArray);
                
                if (fileExtention != null)
                {
                    var returntr = GetFileMIMEType(fileExtention, base64);
                    return returntr;
                }            

            }

            return base64;
        }
        public static string GetFileMIMEType(string fileType,string base64)
        {
            string fileMimeType = string.Empty;

            if (fileType == "doc")
            {
                fileMimeType = "data:application/msword;base64," + base64;
            }

            else if (fileType == "docx")
            {
                fileMimeType = "data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + base64;
            }            

            else if ((fileType == "jpg") || (fileType == "jpeg"))
            {
                fileMimeType = "data:application/image/jpeg;base64,"+ base64;
            }

            else if(fileType == "gif")
            {
                fileMimeType = "data:application/image/gif;base64," + base64;
            }

            else if (fileType == "bmp")
            {
                fileMimeType = "data:application/image/bmp;base64,"+ base64;
            }

            else if (fileType == "png")
            {
                fileMimeType = "data:application/ image/png;base64,"+ base64;
            }

            else if (fileType == "ico")
            {
                fileMimeType = "data:application/image/vnd.microsoft.icon;base64,"+ base64;
            }

            else if (fileType == "pdf")
            {
                fileMimeType = "data:application/application/pdf;base64,"+ base64;
            }

          
            else if (fileType == "xls") {
                fileMimeType = "data:application/vnd.ms-excel;base64,"+ base64;
            }

            else if (fileType == "xlsx")
            {
                fileMimeType = "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,"+ base64;
            }

            else if (fileType == "txt")
            {
                fileMimeType = "data:application/text/plain;base64,"+ base64;
            }

            else if (fileType == "csv")
            {
                fileMimeType = "data:application/text/csv;base64," + base64;
            }

            //else if (fileType == "ppt")
            //{
            //    fileMimeType = "data:application/vnd.ms-powerpoint;base64,"  + base64;
            //}

            //else if (fileType == "pptx")
            //{
            //    fileMimeType = "data:application/vnd.openxmlformats-officedocument.presentationml.presentation;base64,"+ base64;
            //}

            //else if (fileType == "m4v")
            //{
            //    fileMimeType = "data:application/video/x-m4v;base64,"+ base64;
            //}

            //else if (fileType == "avi")
            //{
            //    fileMimeType = "data:application/video/x-msvideo;base64,"+base64;
            //}

            //else if (fileType == "mpeg")
            //{
            //    fileMimeType = "data:application/video/mpeg;base64,"+base64;
            //}

            //else if (fileType == "mp4")
            //{
            //    fileMimeType = "data:application/video/mp4;base64,"+ base64;
            //}

            //else if (fileType == "mov")
            //{
            //    fileMimeType = "data:application/video/quicktime;base64,"+ base64;
            //}

            //else if (fileType == "flv")
            //{
            //    fileMimeType = "data:application/video/x-flv;base64,"+ base64;
            //}


            //else if (fileType == "xml")
            //{
            //    fileMimeType = "data:application/xml;base64,"+ base64;
            //}

            //else if (fileType == "odp")
            //{
            //    fileMimeType = "data:application/vnd.oasis.opendocument.presentation;base64,"+ base64;
            //}


            //else if ((fileType == "htm") || (fileType == "html")){

            //    fileMimeType = "data:application/text/html;base64,"+ base64;
            //}         


            //else if (fileType == "m4a")
            //{
            //    fileMimeType = "data:application/audio/m4a;base64,"+ base64;
            //}

            //else if (fileType == "mp3")
            //{
            //    fileMimeType = "data:application/audio/mpeg;base64,"+ base64;
            //}

            //else if (fileType == "wav")
            //{
            //    fileMimeType = "data:application/audio/wav;base64,"+ base64;
            //}

            return fileMimeType;

        }
        public static string GetBase64File(string fileName,string type)
        {
            var returntr = string.Empty;
            try
            {
              
                if (!string.IsNullOrEmpty(fileName))
                {
                    var split = fileName.Split(".");
                    string base64 = string.Empty;
                    var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), "images\\") + fileName;
                    byte[] imageArray = System.IO.File.ReadAllBytes(pathToSave);
                    base64 = Convert.ToBase64String(imageArray);
                    returntr = "data:image/" + split[1] + ";base64," + base64;
                }
                else
                {
                    returntr = type == "Fav" ? DefaultFabGetBase64File() : DefaultLogoGetBase64File();
                }
            }
            catch (Exception)
            {
                returntr = type == "Fav" ? DefaultFabGetBase64File() : DefaultLogoGetBase64File();
            }

            return returntr;



        }
        public static void  DeleteOldBase64File(string file)
        {
            if (!string.IsNullOrEmpty(file))
            {
                var split = file.Split(".");
                string base64 = string.Empty;
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), "images\\") + file;
                if (File.Exists(pathToSave))
                {
                    File.Delete(pathToSave);
                }
            }
           
        }
        public static string DefaultFabGetBase64File()
        {
                string base64 = string.Empty;
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), "images\\default\\") + "DFFav.png";
                byte[] imageArray = System.IO.File.ReadAllBytes(pathToSave);
                base64 = Convert.ToBase64String(imageArray);
                var returntr = "data:image/" + "png" + ";base64," + base64;
                return returntr;
        }
        public static string DefaultLogoGetBase64File()
        {
            string base64 = string.Empty;
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), "images\\default\\") + "DFLogo.png";
            byte[] imageArray = System.IO.File.ReadAllBytes(pathToSave);
            base64 = Convert.ToBase64String(imageArray);
            var returntr = "data:image/" + "png" + ";base64," + base64;
            return returntr;
        }
    }
}

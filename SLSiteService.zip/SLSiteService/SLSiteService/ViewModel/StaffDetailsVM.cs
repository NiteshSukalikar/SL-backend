﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.ViewModel
{
    public class StaffDetailsVM
    {
        public string FirstName { get; set; }
        public string StaffCode { get; set; }
        public DateTime? LastLogin { get; set; }
        public string MiddleName { get; set; }
        public string UserName { get; set; }
        public string MaidenName { get; set; }
        public string OtherName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int GenderId { get; set; }
        public int MaritalStatusId { get; set; }
        public int CountryID { get; set; }
        public string Phone { get; set; }
        public string StateName { get; set; }
        public string NativeSpokenLanguage { get; set; }
        public string RoleName { get; set; }
        public string? ProfilePicture { get; set; }
        public string? ProfilePictureBase64 { get; set; }
        public string Age { get; set; }
        public string DOB { get; set; }
        public string PrimaryContactNumber { get; set; }
        public string Description { get; set; }
        public string SecondaryContactNumber { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? Isblocked { get; set; }
        public bool? InviteAccept { get; set; }
        public long UserID { get; set; }

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? InviteDate { get; set; }
        public DateTime? InviteSentDate { get; set; }
        public Guid AccountInviteToken { get; set; }
        public long OrganizationID { get; set; }
        public long OrganizationTypeID { get; set; }
        public bool IsStaff { get; set; }
        public Guid StaffGuid { get; set; }

    }
}

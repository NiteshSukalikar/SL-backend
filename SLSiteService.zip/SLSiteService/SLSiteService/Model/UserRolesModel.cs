﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class UserRolesModel
    {
        public long RoleID { get; set; }
        public long? UserID { get; set; }
        public Guid RoleGuid { get; set; }
        public string RoleName { get; set; }
        public string RoleDescription { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public string? ReturnCode { get; set; }
    }
}

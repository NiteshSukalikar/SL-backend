﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class CityMasterModel
    {
        public int cityId { get; set; }
        public string cityName { get; set; }
        public int stateId { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Models
{

    public class CodesModel
    {
        public List<CodesModelData> HCPCSCodesModelData { get; set; }
        public List<CodesModelData> NDCCodesModelData { get; set; }
    }
    public class CodesModelData
    {
        public long Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class MasterEmailTemplateModel
    {
        public long EmailTemplateID { get; set; }
        public string EmailTemplateName { get; set; }
        public string EmailTemplateDescription { get; set; }
        public string EmailTemplateBody { get; set; }

        public Guid? EmailTemplateGuid { get; set; }
        public string EmailTemplateCode { get; set; }
        public int EmailTemplateType { get; set; }
        public string EmailTemplateSenderName { get; set; }
        public string EmailTemplateSenderEmailAddress { get; set; }
        public string EmailTemplateSubject { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
    }
}

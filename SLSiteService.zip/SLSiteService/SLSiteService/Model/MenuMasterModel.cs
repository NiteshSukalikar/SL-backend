﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class MenuMasterModel
    {
        public string MenuText { get; set; }
        public string MenuController { get; set; }
        public string MenuAction { get; set; }
        public string MenuURL { get; set; }
        public long ParentMenuId { get; set; }
        public string OrderId { get; set; }
        public bool IsActive { get; set; }
    }
}

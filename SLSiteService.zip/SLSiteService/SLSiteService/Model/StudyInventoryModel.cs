﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Models
{
    public class StudyInventoryModel
    {
        public List<CSInventoryModel> CSInventoryModels { get; set; }
        public Guid CSGuid { get; set; }
    }

    public class CSInventoryModel
    {
        public Guid? CSInventoryGuiD { get; set; }
        public int? InventoryType { get; set; }        
        public string? InventoryCode { get; set; }
        public string? InventoryName { get; set; }
        public int? InventoryAvailableQuantity { get; set; }
        public int? InventoryQuantity { get; set; }
        public int? InventoryBeginningAmount { get; set; }
        public int? InventoryCurrentAmount { get; set; }
        public int? OrderNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsPublish { get; set; }
        public bool IsDeleted { get; set; }
    }

    public class CSInventoryModelWithGuid
    {
        public Guid? CSInventoryGuiD { get; set; }
        public Guid? CSGuiD { get; set; }
        public int? InventoryType { get; set; }
        public string? InventoryCode { get; set; }
        public string? InventoryName { get; set; }
        public int? InventoryAvailableQuantity { get; set; }
        public int? InventoryBeginningAmount { get; set; }
        public int? InventoryCurrentAmount { get; set; }
        public int? OrderNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsPublish { get; set; }
        public bool IsDeleted { get; set; }
    }
}

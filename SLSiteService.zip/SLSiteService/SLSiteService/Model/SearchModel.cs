﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class SearchModel
    {
        public int Id { get; set; }
        public string Search { get; set; }
    }
}

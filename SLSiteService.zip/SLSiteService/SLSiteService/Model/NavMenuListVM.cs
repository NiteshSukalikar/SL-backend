﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class NavMenuListVMAuth
    {
        public List<NavMenuListAuth> navMenuList { get; set; }
        public List<SideMenuAuth> sideMenu { get; set; }
    }
    public class NavMenuListAuth
    {
        //public long NavMenuActionID { get; set; }
        public string NavName { get; set; }
        public string ActionName { get; set; }
    }
    public class SideMenuAuth
    {
        
        public long UISideMenuID { get; set; }
        public long? ParentSideMenuID { get; set; }
        public string Header { get; set; }
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public int? Order { get; set; }
        public string ActionName { get; set; }
        public bool HasAccess { get; set; }
        public bool IsShow { get; set; }

    }
    public class SideMenu_Auth
    {
        //public SideMenu_(List<SideMenu_> _InnersideMenu)
        //{
        //    InnersideMenu = _InnersideMenu;
        //}
        public long UISideMenuID { get; set; }
        public long? ParentSideMenuID { get; set; }
        public string Header { get; set; }
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public int? Order { get; set; }
        public string ActionName { get; set; }
        public bool HasAccess { get; set; }
        public List<SideMenu_Auth> SubModules { get; set; }
    }


    public class NavListDecorationAuth
    {
        public long SideMenuID { get; set; }
        public string moduleName { get; set; }
        public string Header { get; set; }   
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public bool IsShow { get; set; }
        public List<PermissionAuth> permissions { get; set; }
        public List<NavListDecorationAuth> SubModules { get; set; }

    }
    public class PermissionAuth
    {
        public string label { get; set; }

        public bool value { get; set; }
    }
}

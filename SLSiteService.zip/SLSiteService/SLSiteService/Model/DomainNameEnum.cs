﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public enum DomainNameEnum
    {
        organization = 1,
        sponsor = 2,
        principalInvestigator = 3,
        cro = 4,
        participant = 5,
        superadmin = 0
    }
}

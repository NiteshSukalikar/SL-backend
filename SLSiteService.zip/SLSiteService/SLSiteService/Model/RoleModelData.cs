﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class RoleModelData
    {
        public int? Id { get; set; }
        public bool? Type { get; set; }
    }
}

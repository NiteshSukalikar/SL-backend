﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class UserInputModel
    {
        public string Guid { get; set; }
        public string OrganizationType { get; set; }
    }
}

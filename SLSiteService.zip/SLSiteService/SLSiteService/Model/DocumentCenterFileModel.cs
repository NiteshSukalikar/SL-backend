﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class DocumentCenterFileModel
    {
        public Int64 DocumentCenterFileId { get; set; }
        public Guid DocumentCenterFileGUID { get; set; }
        public string? OriginalFileName { get; set; }
        public string? OriginalFileNameBase64 { get; set; }
        public string? SaveFileName { get; set; }
        public string FileExtension { get; set; }
        public decimal FileVersion { get; set; }
        public int FileUploadedBy { get; set; }
        public DateTime UploadedDate { get; set; }
        public string CommentText { get; set; }
        public string FileDownloadLink { get; set; }

        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public int? DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class StaffDetailsModel
    {
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? UserName { get; set; }
        public string? MaidenName { get; set; }
        public string? OtherName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public int? GenderId { get; set; }
        public int? MaritalStatusId { get; set; }
        public int? CountryID { get; set; }
        public string? Phone { get; set; }
        public string? StateName { get; set; }
        public string? NativeSpokenLanguage { get; set; }
        public string? RoleName { get; set; }
        public string? ProfilePicture { get; set; }
        public string? ProfilePicturebase64 { get; set; }
        public string? Age { get; set; }
        public DateTime DobDateTime { get; set; }
        public string? DOB { get; set; }
        public string? PrimaryContactNumber { get; set; }
        public string? Description { get; set; }
        public string? SecondaryContactNumber { get; set; }
        public long? UserID { get; set; }
        public Guid? StaffGuid { get; set; }
        public long? CreatedByLoginID { get; set; }
        public bool? IsEdit { get; set; }
    }
}

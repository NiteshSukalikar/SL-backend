﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class StateMasterModel
    {
        public int stateId { get; set; }
        public string stateName { get; set; }
        public int countryId { get; set; }
    }
}

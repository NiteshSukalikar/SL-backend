﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class DocumentCenterModel
    {
        public long DocumentCenterId { get; set; }
        public Guid DocumentCenterGUID { get; set; }
        public string DocumentTitle { get; set; }
        public DocumentCenterFileModel FileModel { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public int? DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public int ResultMessage { get; set; }

    }
}


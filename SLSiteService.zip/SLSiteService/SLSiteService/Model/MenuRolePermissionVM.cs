﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class MenuRolePermissionVM
    {
        public List<RoleModel> role { get; set; }
        public List<MenuModel> menuModel { get; set; }
    }
    public class RoleModel
    {
        public int RoleId { get; set; }
        public int RoleName { get; set; }
    }
    public class MenuModel
    {
        public int MenuId { get; set; }
        public string MenuText { get; set; }
        public string MenuURL { get; set; }
        public int ParentMenuMenuId { get; set; }
        public string ParentMenuMenu { get; set; }
    }
}

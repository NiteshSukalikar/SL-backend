﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class StaffModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public long? InitialRoleId { get; set; }
        public string RoleName { get; set; }
        public string Phone { get; set; }
        public long? ChildOrganizationsID { get; set; }

        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }      
        public bool? InviteAccept { get; set; }

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? InviteDate { get; set; }
        public DateTime? InviteSentDate { get; set; }
        public Guid AccountInviteToken { get; set; }
        public long OrganizationID { get; set; }
        public long OrganizationTypeID { get; set; }        
        public bool IsStaff { get; set; }
        public Guid StaffGuid { get; set; }
        public string? ReturnEmailAddress { get; set; }
        public string? Type { get; set; }
        public string? DepartmentName { get; set; }
    }
}

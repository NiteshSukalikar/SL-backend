﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class DocumentListModel
    {
        public long DocumentCenterId { get; set; }
        public long DocumentCenterFileId { get; set; }
        public string DocumentTitle { get; set; }
        public string OrigionalFileName { get; set; }
        public string Comment { get; set; }
        public DateTime UploadedDate { get; set; }
        public float DocumentVersion { get; set; }
        public string UploadedBy { get; set; }
        public string DocumentType { get; set; }
        public string FileDownloadLink { get; set; }
    }

    public class DocumentCentreVM
    {
        public DocumentCentreVM()
        {
            documentCentreListVM = new List<DocumentCentreListVM>();
        }
        public long DocumentCenterId { get; set; }
        public string DocumentTitle { get; set; }
        public List<DocumentCentreListVM> documentCentreListVM { get; set; }
    }
    public class DocumentCentreListVM
    {
        public long DocumentCenterFileId { get; set; }
        public string OrigionalFileName { get; set; }
        public string Comment { get; set; }
        public DateTime UploadedDate { get; set; }
        public float DocumentVersion { get; set; }
        public string strDocumentVersion
        {
            get
            {
                return DocumentVersion + ".0";
            }
        }
        public string UploadedBy { get; set; }
        public string DocumentType { get; set; }
        public string FileDownloadLink { get; set; }
    }
}


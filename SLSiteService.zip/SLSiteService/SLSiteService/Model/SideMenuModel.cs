﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{

    public class SideMenuModel
    {

        public long UISideMenuID { get; set; }
        public long? ParentSideMenuID { get; set; }
        public string Header { get; set; }
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public int? Order { get; set; }
        public string ActionName { get; set; }
        public long MenuActionID { get; set; }

    }
    public class NavListDecoration
    {
        public long SideMenuID { get; set; }
        public string moduleName { get; set; }
        public string Header { get; set; }
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public List<Permission> permissions { get; set; }
        public List<NavListDecoration> SubModules { get; set; }

    }
    public class Permission
    {
        public string label { get; set; }

        public long MenuActionID { get; set; }
        public bool Istrue { get; set; }
    }
    public class MenuActionModel
    {
        public long SideMenuActionID { get; set; }
        public long RoleId { get; set; }
        public bool IsTrue { get; set; }

    }

    public class MenuPermissionEditModel
    {

        public long UISideMenuID { get; set; }
        public long? ParentSideMenuID { get; set; }
        public string Header { get; set; }
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public int? Order { get; set; }
        public string ActionName { get; set; }
        public bool HasAccess { get; set; }
        public long MenuActionID { get; set; }
    }
    public class NavListDecorationModel
    {
        public long SideMenuID { get; set; }
        public string moduleName { get; set; }
        public string Header { get; set; }
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public List<Permission_> permissions { get; set; }
        public List<NavListDecorationModel> SubModules { get; set; }

    }
    public class Permission_
    {
        public string label { get; set; }

        public bool value { get; set; }
        public long MenuActionID { get; set; }
    }
    public class MenuPermissionEditModel_
    {
        //public SideMenu_(List<SideMenu_> _InnersideMenu)
        //{
        //    InnersideMenu = _InnersideMenu;
        //}
        public long UISideMenuID { get; set; }
        public long? ParentSideMenuID { get; set; }
        public string Header { get; set; }
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public int? Order { get; set; }
        public string ActionName { get; set; }
        public bool HasAccess { get; set; }
        public List<MenuPermissionEditModel_> SubModules { get; set; }
    }

}


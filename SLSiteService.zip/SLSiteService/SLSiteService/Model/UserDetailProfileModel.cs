﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class UserDetailProfileModel
    {
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? UserName { get; set; }
        public string? MaidenName { get; set; }
        public string? OtherName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public int? GenderId { get; set; }
        public int? MaritalStatusId { get; set; }
        public int? CountryID { get; set; }
        public string? Phone { get; set; }
        public DateTime? LastLogin { get; set; }
        public string? StateName { get; set; }
        public string? NativeSpokenLanguage { get; set; }
        public string? RoleName { get; set; }
        public string? ProfilePicture { get; set; }
        public string? ProfilePicturebase64 { get; set; }
        public string? Age { get; set; }
        public DateTime DobDateTime { get; set; }
        public string? DOB { get; set; }
        public string? PrimaryContactNumber { get; set; }
        public string? Description { get; set; }
        public string? SecondaryContactNumber { get; set; }
        public long? UserID { get; set; }
        public Guid? UserGuid { get; set; }
        public long? CreatedByLoginID { get; set; }
        public bool? IsEdit { get; set; }
        public string OrganizationName { get; set; }
        public string BusinessName { get; set; }

        //For Participant Use
        public int? Race { get; set; }
        public int? Ethnicity { get; set; }
        public string? CaregiverName { get; set; }
        public string? CaregiverEmail { get; set; }
        public string? CaregiverPhone { get; set; }
        public string? ReferralPhysicianName { get; set; }
        public string? ReferralPhysicianEmail { get; set; }
        public string? ReferralPhysicianPhone { get; set; }
        public string? StreetAddress1 { get; set; }
        public string? StreetAddress2 { get; set; }
        public string? ZipCode { get; set; }
        public bool? IsVolunteer { get; set; }
        public bool? IsMedicalCondition { get; set; }
        public string OrganizationType { get; set; }
    }
}

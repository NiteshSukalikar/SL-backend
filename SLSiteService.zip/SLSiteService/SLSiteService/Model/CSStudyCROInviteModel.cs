﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Model
{
    public class CSStudyCROInviteModel
    {
        
        public long CSStudyStudyID { get; set; }
        public Guid csGuiD { get; set; }
        public long SponsorID { get; set; }
        public List<long> CROList { get; set; }
        public List<DocumentCenterFileModel> FileModel { get; set; }
        public string InviteMessage { get; set; }     

    }

    public class CROInviteModelForSPVM
    {
        public CROInviteModelForSPVM()
        {
            cROInviteList = new List<CROInviteModelForSP>();
            //fileList = new List<SaveFileList>();
        }
        public List<CROInviteModelForSP> cROInviteList { get; set; }
        public List<SaveFileList> fileList { get; set; }
    }
    public class CROInviteModelForSP
    {

        public long CSStudyStudyID { get; set; }
        public long SponsorID { get; set; }
        public long CROID { get; set; }
        public string InviteMessage { get; set; }
     //   public DateTime? InviteSentDate { get; set; }
       
    }
    public class SaveFileList
    {
            public string FileNameGuid { get; set; }
            public string OriginalName { get; set; }
            public string Extension { get; set; }
    }

    //returnInviteModel

    public class returnInviteModel
    { 
          public List<CRODetails> cRODetails { get; set; }
          public StudyDetails studyDetails { get; set; }
          public EmailTemplate emailTemplate { get; set; }
    }
    public class CRODetails
    {
        public long CROId { get; set; }
        public string CROMailId { get; set; }
        public string CROName { get; set; }
    }
    public class StudyDetails
    {
        public string CSCode { get; set; }
        public string CSShortDescription { get; set; }
    }

    public class EmailTemplate
    {
        public string EmailTemplateDescription { get; set; }
        public string EmailTemplateBody { get; set; }
    }
    public class AcceptCSInviteModel
    {
        public long CROID { get; set; }
        public long SponsorID { get; set; }
        public long CSStudyID { get; set; }
        public bool ISAccept { get; set; }
        public string Comment { get; set; }
    }

}

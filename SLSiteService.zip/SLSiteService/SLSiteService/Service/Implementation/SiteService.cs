﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Shared.Enum;
using Shared.Model;
using SLSiteService.Common;
using SLSiteService.Common.StaticConstants;
using SLSiteService.Model;
using SLSiteService.Models;
using SLSiteService.Repository.UnitOfWorkAndBaseRepo;
using SLSiteService.Service.Interface;
using SLSiteService.ViewModel;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SLSiteService.Service.Implementation
{
    public class SiteService : ISiteService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IConfiguration _configuration;
        List<NavListDecorationAuth> navMenuAuth_ = new List<NavListDecorationAuth>();
        List<NavListDecorationModel> navMenu_ = new List<NavListDecorationModel>();
        bool IsShowMenu = false;

        public SiteService(IUnitOfWork unitOfWork, IConfiguration Configuration)
        {
            _unitOfWork = unitOfWork;
            _configuration = Configuration;
        }

        #region Auth Login Services

        public async Task<ResponseModel> Login(LoginModel loginVM)
        {
            var ResponseModel = new ResponseModel();
            ResponseModel.StatusCode = ((int)StatusCode.StatusCode203).ToString();
            try
            {
                var user = new UserDetails();

                // Database                                       
                user = await _unitOfWork.SiteModel.GetUserDetailsForLogin(loginVM);

                // Key and Iv Values                                          
                var keybytes = Encoding.UTF8.GetBytes(Constants.keybytes);
                var iv = Encoding.UTF8.GetBytes(Constants.iv);


                if (user == null)
                {
                    ResponseModel.Code = ((int)StatusCode.StatusCode202).ToString();
                    ResponseModel.Data = null;
                    ResponseModel.Message = IEHMessages.UserNotFound;
                }
                else if (user.UserPassword != loginVM.Password)
                {
                    ResponseModel.Code = ((int)StatusCode.StatusCode204).ToString();
                    ResponseModel.Data = null;
                    ResponseModel.Message = IEHMessages.EmailorPasswordWrong;
                }
                else
                {
                    var _otpSent = false;
                    var responseData = new ResponseModel();
                    var ActivationRequired = false;


                    //onces SMTP added 
                    var respOTP = await StartVerificationAsync(user.ContactNumber, loginVM.otpVia, user.EmailAddress, user.Firstname, user.Lastname, null);

                    _otpSent = respOTP.IsValid;
                    ResponseModel.Data = new { userId = user.UserId, otpSent = _otpSent, activationRequired = ActivationRequired, DomainRoleId = user.OrganizationID == null ? 0 : user.DomainRoleID };
                    ResponseModel.Code = ((int)StatusCode.StatusCode200).ToString();
                    ResponseModel.Message = IEHMessages.OperationSuccessful;

                }
                return ResponseModel;
            }
            catch (Exception e)
            {
                ResponseModel.Code = ((int)StatusCode.StatusCode203).ToString(); ;
                ResponseModel.Message = IEHMessages.InternalServerError;
                return ResponseModel;
            }
        }

        public void CheckAllChildIsShown(List<NavListDecorationAuth> SubModules)
        {
            IsShowMenu = false;
            foreach (var action in SubModules)
            {
                foreach (var CP in action.permissions)
                {
                    if (CP.value == true)
                    {
                        IsShowMenu = true;
                        break;
                    }
                }
            }

        }
        public void ChangeEachRowVal(NavListDecorationAuth ParentObj)
        {

            if (ParentObj.SubModules != null && ParentObj.SubModules.Count > 0)
            {
                ParentObj.permissions = null;
                CheckAllChildIsShown(ParentObj.SubModules);
                ParentObj.IsShow = IsShowMenu;
                foreach (var action in ParentObj.SubModules)
                {
                    ChangeEachRowVal(action);
                }
            }
            else
            {
                if (ParentObj.permissions != null)
                {
                    foreach (var action in ParentObj.permissions)
                    {
                        if (action.value == true)
                        {

                            //IsShowMenu = true;
                            ParentObj.IsShow = true;
                            break;
                        }
                    }
                }

            }
            // ParentObj.IsShow = IsShowMenu;
        }
        public NavListDecorationAuth FindNested(List<NavListDecorationAuth> navMenu_, long? parentId)
        {
            foreach (var item in navMenu_)
            {
                if (item.SideMenuID == parentId)
                {
                    return item;
                }
                else if (item.SubModules != null && item.SubModules.Count > 0)
                {
                    var ret = FindNested(item.SubModules, parentId);
                    if (ret != null)
                    {
                        return ret;
                    }
                }

            }
            return null;
        }

        public async Task<ResponseModel> LoginOTPVerification(OTPModel model)
        {

            var responseVM = new ResponseModel()
            {
                Code = ((int)StatusCode.StatusCode500).ToString(),
                Data = null,
                Message = "Internal Server Error"
            };
            try
            {
                var user = new UserDetails();
                user = await _unitOfWork.SiteModel.GetUserDetailsById(model.UserId);

                if (user != null)
                {
                    var otpValid = true;
                    if (model.otpVia != "notrequired")
                    {
                        var respOTP = await CheckVerificationAsync(model.OTP);
                        // respOTP.Sid = "200";
                        if (respOTP != null)
                        {
                            if (respOTP.Sid == "200")
                            {
                                otpValid = respOTP.IsValid;
                            }
                            else
                            {
                                otpValid = false;
                            }
                        }
                    }
                    if (otpValid)
                    {

                        // After Identity -->
                        //JsonModel obj = await IdentityLogin(user);
                        var mySecret = "asdv234234^&%&^%&^hjsdfb2%%%";
                        var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

                        var myIssuer = "http://mysite.com";
                        var myAudience = "http://myaudience.com";
                        var now = DateTime.UtcNow;
                        var IsStaffFlag = user.IsStaff == null ? "false" : user.IsStaff.ToString();
                        var logo = string.Empty;

                        //if (IsStaffFlag == "false")
                        //{
                        //    logo = FileUploadUtility.GetBase64File(user.LogoName, "Logo");
                        //}
                        //else
                        //{
                        //    logo = FileUploadUtility.GetBase64File(user.ProfilePicture, "Logo");
                        //}


                        var claims = new Claim[]
                        {
                            new Claim("UserID", user.UserId.ToString()),
                            new Claim("EmailAddress", user.EmailAddress),
                            new Claim("IsStaff", IsStaffFlag),
                            new Claim("FirstName", user.Firstname.ToString() == null ? "" : user.Firstname.ToString()),
                            new Claim("OrganizationTypesId", user.OrganizationTypesId.ToString() == null ? " " :user.OrganizationTypesId.ToString()),
                            new Claim("LastName",  user.Lastname.ToString()),
                            new Claim("AccountId", user.AccountId.ToString() == null ? " " : user.AccountId.ToString() ),
                            new Claim("FullName",  user.Firstname.ToString() + " " + user.Lastname.ToString()),
                           // new Claim("Logo",logo),
                        };
                        var tokenValidationParameters = new TokenValidationParameters
                        {
                            ValidateIssuerSigningKey = true,
                            IssuerSigningKey = mySecurityKey,
                            ValidateIssuer = true,
                            ValidIssuer = myIssuer,
                            ValidateAudience = true,
                            ValidAudience = myAudience,
                            ValidateLifetime = true,
                            ClockSkew = TimeSpan.Zero,
                            RequireExpirationTime = true,

                        };

                        var jwt = new JwtSecurityToken(
                            issuer: myIssuer,
                            audience: myAudience,
                            claims: claims,
                            notBefore: now,
                            expires: DateTime.UtcNow.AddDays(7),
                            signingCredentials: new SigningCredentials(mySecurityKey, SecurityAlgorithms.HmacSha256)
                        );
                        var encodedJwt = new JwtSecurityTokenHandler().WriteToken(jwt);

                        List<SideMenuAuth> navMenuList = _unitOfWork.SiteModel.UINavMenuList(Convert.ToInt32(model.UserId));

                        #region SubMenu
                        foreach (var item in navMenuList)
                        {

                            if (Convert.ToInt32(item.ParentSideMenuID) != 0) //4
                            {

                                var pdata = FindNested(navMenuAuth_, item.ParentSideMenuID);
                                NavListDecorationAuth childMenu = (pdata != null && pdata.SubModules != null) ? pdata.SubModules.FirstOrDefault(y => y.SideMenuID == item.UISideMenuID) : null;

                                if (childMenu == null)
                                {
                                    NavListDecorationAuth subModu =

                                        new NavListDecorationAuth()
                                        {
                                            SideMenuID = item.UISideMenuID,
                                            Header = item.Header,
                                            moduleName = item.Navigationlink,
                                            ClassStyle = item.ClassStyle,
                                            Navigationlink = item.Navigationlink,

                                            permissions = new List<PermissionAuth>()
                                                {
                                                    new PermissionAuth()
                                                        {
                                                            label=item.ActionName,
                                                            value=item.HasAccess
                                                         }
                                                }

                                        };
                                    pdata.SubModules.Add(subModu);

                                }
                                else
                                {
                                    childMenu.permissions.Add(new PermissionAuth()
                                    {
                                        label = item.ActionName,
                                        value = item.HasAccess
                                    });

                                }


                            }
                            else
                            {
                                var s = navMenuAuth_.Any(x => x.SideMenuID == item.UISideMenuID);
                                if (s != true)
                                {
                                    NavListDecorationAuth obj = new NavListDecorationAuth()
                                    {
                                        SideMenuID = item.UISideMenuID,
                                        Header = item.Header,
                                        moduleName = item.Navigationlink,
                                        ClassStyle = item.ClassStyle,
                                        Navigationlink = item.Navigationlink,

                                        permissions = new List<PermissionAuth>()
                               {
                                   new PermissionAuth()
                                   {
                                       label=item.ActionName,
                                       value=item.HasAccess
                                   }
                               }

                                    };
                                    navMenuAuth_.Add(obj);
                                }
                                else
                                {
                                    var data = navMenuAuth_.FirstOrDefault(x => x.SideMenuID == item.UISideMenuID);
                                    data.permissions.Add(new PermissionAuth
                                    {
                                        label = item.ActionName,
                                        value = item.HasAccess
                                    });
                                }
                            }
                        }
                        foreach (var item in navMenuAuth_)
                        {
                            ChangeEachRowVal(item);
                        }

                        #endregion
                        var responseJson = new
                        {
                            access_token = encodedJwt,
                            expires_in = DateTime.UtcNow.AddDays(7),
                            claims = user,
                            // navMenuList= sideMenu_,//navMenuList.navMenuList,
                            // sideMenuList = navMenuAuth_
                            sideMenuList = navMenuAuth_.OrderBy(x => x.Header.Trim())
                        };

                        if (responseJson != null)
                        {
                            SaveLogUserSystem saveLogUserSystem = new SaveLogUserSystem();
                            saveLogUserSystem.SystemIPAddress = model.ipAddr;
                            saveLogUserSystem.SystemLocationAddress = model.Country;
                            saveLogUserSystem.UserLoggedInTime = DateTime.UtcNow;
                            saveLogUserSystem.OrganizationsToken = responseJson.access_token;
                            saveLogUserSystem.UserId = model.UserId;
                            saveLogUserSystem.LoggingMessage = "Logged In";
                            var res = _unitOfWork.SiteModel.SaveLogUserSystem(saveLogUserSystem);
                        }

                        //if (obj.StatusCode.ToString() == ((int)StatusCode.StatusCode200).ToString())
                        //{
                        //    model.LoginAttempt = "SUCCESS";
                        //    model.OrganizationId = model.RoleId == 1 ? model.OrganizationId : Convert.ToInt32(user.OrganizationId);
                        //    var log = SaveLoginLogs(model);
                        //}
                        //if (obj.StatusCode.ToString() == ((int)StatusCode.StatusCode200).ToString() && !string.IsNullOrEmpty(model.DeviceToken))
                        //{
                        //    var res = await _unitOfWork.User.UpdateDeviceTokenByUserId(model.DeviceToken, model.UserId);
                        //}

                        responseVM.Code = "200";
                        responseVM.Data = responseJson;
                        responseVM.Message = "Sucessfully Login";
                    }
                    else
                    {
                        responseVM.Code = ((int)StatusCode.StatusCode201).ToString();
                        responseVM.Data = null;
                        responseVM.Message = IEHMessages.InvalidOTP;
                    }
                }
                else
                {
                    responseVM.Code = ((int)StatusCode.StatusCode202).ToString();
                    responseVM.Data = null;
                    responseVM.Message = IEHMessages.InvalidUser;
                }
                return responseVM;
            }
            catch (Exception e)
            {
                responseVM.StatusCode = ((int)StatusCode.StatusCode202).ToString();
                responseVM.Data = null;
                responseVM.Message = e.Message;
                return responseVM;
            }
        }

        public async Task<ResponseModel> resendOTP(resendOTPModel resendOTPModel)
        {
            var responseVM = new ResponseModel();
            responseVM.Code = ((int)StatusCode.StatusCode203).ToString();
            try
            {
                var user = new UserDetails();
                var loginModel = new LoginModel();
                loginModel.Email = resendOTPModel.Email;

                // Database                                       
                user = await _unitOfWork.SiteModel.GetUserDetailsForLogin(loginModel);

                if (user == null)
                {
                    responseVM.Code = ((int)StatusCode.StatusCode202).ToString();
                    responseVM.Data = null;
                    responseVM.Message = IEHMessages.UserNotFound;
                }
                else
                {
                    var _otpSent = false;
                    var responseData = new ResponseModel();
                    var ActivationRequired = false;


                    //onces SMTP added 
                    var respOTP = await StartVerificationAsync(user.ContactNumber, "email", user.EmailAddress, user.Firstname, user.Lastname, null);

                    _otpSent = respOTP.IsValid;
                    responseVM.Data = new { userId = user.UserId, otpSent = _otpSent, activationRequired = ActivationRequired };
                    responseVM.Code = ((int)StatusCode.StatusCode200).ToString();
                    responseVM.Message = IEHMessages.OperationSuccessful;


                }
                return responseVM;
            }
            catch (Exception e)
            {
                responseVM.Code = ((int)StatusCode.StatusCode203).ToString(); ;
                responseVM.Message = IEHMessages.InternalServerError;
                return responseVM;
            }
        }


        public async Task<VerificationResult> StartVerificationAsync(string phoneNumber, string channel, string email, string firstname, string lastname, string? forgotPasswordUrl)
        {
            try
            {
                //int port = 587;
                //string host = _configuration["Mailconfig:HOST"].ToString();
                //string username = _configuration["Mailconfig:SMTP_USERNAME"].ToString();
                //string password = _configuration["Mailconfig:SMTP_PASSWORD"].ToString();
                //string mailFrom = _configuration["Mailconfig:FROM"].ToString();
                //string mailTo = email;
                //string mailTitle = "";
                //string mailMessage;


                //if (forgotPasswordUrl != null)
                //{
                //    mailTitle = "CRLink – Password reset";
                //    var htmlEmailContent = "<br/><br/><span>The user ID {0} has requested to change the password for CRLink, if this is you then please <a href='http://localhost:4200/superadmin/confirm-password'><strong>click on the link Reset Password</strong></a> to finish the process.</span><br/><br/><span>If you did not request a password reset, please ignore this email.</span>";
                //    mailMessage = string.Format(htmlEmailContent, email);
                //}
                //else
                //{
                //    mailTitle = "CRLink - Two factor authentication";
                //    mailMessage = "<br/><br/><span>Dear {0} </span><br/><br/><span> The email {1} has requested to login to CRLink platform. If this is you, then enter the code 123456 to continue with your login.</span><br/><br/><span>If you did not request to login to CRLink, please ignore this email.</span>";
                //    var fullname = firstname + " " + lastname;
                //    mailMessage = string.Format(mailMessage, fullname, email);
                //}

                //using (SmtpClient client = new SmtpClient())
                //{
                //    MailAddress from = new MailAddress(mailFrom);
                //    MailMessage message = new MailMessage
                //    {
                //        From = from
                //    };
                //    message.To.Add(mailTo);
                //    message.Subject = mailTitle;
                //    message.Body = mailMessage;
                //    message.IsBodyHtml = true;
                //    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                //    client.UseDefaultCredentials = false;
                //    client.Host = host;
                //    client.Port = port;
                //    client.EnableSsl = true;
                //    client.Credentials = new NetworkCredential
                //    {
                //        UserName = username,
                //        Password = password
                //    };
                //    client.Send(message);
                //}
                return new VerificationResult("200", null);
            }
            catch (Exception e)
            {
                return new VerificationResult(new List<string> { e.Message });
            }
        }

        public async Task<VerificationResult> CheckVerificationAsync(string code)
        {
            try
            {

                if (code == "123456")
                {
                    return new VerificationResult("200", null);
                }
                return new VerificationResult("400", null);
            }
            catch (Exception e)
            {
                return new VerificationResult(new List<string> { e.Message });
            }
        }

        public string Logout(LogoutModel model)
        {
            var responseVM = new ResponseModel();
            var res = string.Empty;
            try
            {
                model.UserLoggedInTime = DateTime.UtcNow;
                res = _unitOfWork.SiteModel.Logout(model);
                if (res != null)
                {
                    responseVM.Code = ((int)StatusCode.StatusCode200).ToString(); ;
                    responseVM.Message = IEHMessages.Success;
                }
                return res;
            }
            catch (Exception e)
            {
                return res;
            }
        }

        #endregion

        #region Common Services
        public async Task<ResponseModel> GetCountry()
        {
            var response = new ResponseModel();
            try
            {
                //Task<MasterEmailTemplateModel> GetEmailTemplate
                List<CountryMasterModel> result = await _unitOfWork.SiteModel.GetCountry();
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetStateCountrywise(int id)
        {
            var response = new ResponseModel();
            try
            {
                //Task<MasterEmailTemplateModel> GetEmailTemplate
                List<StateMasterModel> result = await _unitOfWork.SiteModel.GetStateCountrywise(id);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetCityStatewise(int id)
        {
            var response = new ResponseModel();
            try
            {
                //Task<MasterEmailTemplateModel> GetEmailTemplate
                List<CityMasterModel> result = await _unitOfWork.SiteModel.GetCityStatewise(id);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        // User deatils 

        public async Task<ResponseModel> GetUserDetails(UserInputModel model)
        {
            var response = new ResponseModel();
            try
            {

                UserInfoDetailsVM result = await _unitOfWork.SiteModel.GetUserDetails(model);


                if (result != null)
                {
                    var LastLoginTime = result.LastLogin == null ? DateTime.UtcNow : (DateTime)result.LastLogin;
                    var easternAcceptDateZone = TimeZoneInfo.FindSystemTimeZoneById(_configuration["DateTimeFormat:TimeZone"]);
                    result.LastLogin = TimeZoneInfo.ConvertTimeFromUtc(LastLoginTime, easternAcceptDateZone);
                    var profilePicture = FileUploadUtility.GetBase64File(result.ProfilePicture, "Logo");
                    result.ProfilePictureBase64 = profilePicture;
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        public async Task<ResponseModel> UpdateUserDetails(UserDetailProfileModel userDetailsModel)
        {
            var response = new ResponseModel();
            try
            {
                if (userDetailsModel.IsEdit == true)
                {
                    #region Delete existing and add new

                    if (userDetailsModel.ProfilePicturebase64 != null)
                    {
                        FileUploadUtility.DeleteOldBase64File(userDetailsModel.ProfilePicture);
                        var Favi = FileUploadUtility.UploadBase64File(userDetailsModel.ProfilePicturebase64);
                        userDetailsModel.ProfilePicture = Favi;
                    }
                    #endregion
                }
                else
                {
                    if (userDetailsModel.ProfilePicturebase64 != null)
                    {
                        var profilePicture = FileUploadUtility.UploadBase64File(userDetailsModel.ProfilePicturebase64);
                        userDetailsModel.ProfilePicture = profilePicture;
                    }

                }


                var age = commonMethod.CalculateYourAge(userDetailsModel.DobDateTime);
                userDetailsModel.Age = age;

                ResponseModel result = await _unitOfWork.SiteModel.UpdateUserDetails(userDetailsModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    //  response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode400).ToString();
                    //response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        #endregion

        #region Menu Permission
        public async Task<ResponseModel> GetMenuActionList(long userID)
        {
            var response = new ResponseModel();
            try
            {
                List<SideMenuModel> result = await _unitOfWork.SiteModel.GetMenuActionList(userID);


                List<NavListDecoration> navMenu_ = new List<NavListDecoration>();

                #region SubMenu
                foreach (var item in result)
                {

                    if (item.ParentSideMenuID != 0)
                    {

                        var pdata = navMenu_.FirstOrDefault(x => x.SideMenuID == item.ParentSideMenuID);
                        var childMenu = pdata.SubModules != null ? pdata.SubModules.FirstOrDefault(y => y.SideMenuID == item.UISideMenuID) : null;
                        if (childMenu == null)
                        {
                            pdata.SubModules = new List<NavListDecoration>()
                                    {
                                        new NavListDecoration()
                                        {
                                            SideMenuID = item.UISideMenuID,
                                            Header = item.Header,
                                            moduleName = item.Navigationlink,
                                            ClassStyle = item.ClassStyle,
                                            Navigationlink=item.Navigationlink,
                                            permissions = new List<Permission>()
                                                {
                                                    new Permission()
                                                        {
                                                            label=item.ActionName,
                                                            MenuActionID=item.MenuActionID,
                                                            Istrue=false
                                                         }
                                                }

                                        }
                                    };

                        }
                        else
                        {
                            childMenu.permissions.Add(new Permission()
                            {
                                label = item.ActionName,
                                MenuActionID = item.MenuActionID,
                                Istrue = false
                            });

                        }


                    }
                    else
                    {
                        var s = navMenu_.Any(x => x.SideMenuID == item.UISideMenuID);
                        if (s != true)
                        {
                            NavListDecoration obj = new NavListDecoration()
                            {
                                SideMenuID = item.UISideMenuID,
                                Header = item.Header,
                                moduleName = item.Navigationlink,
                                ClassStyle = item.ClassStyle,
                                Navigationlink = item.Navigationlink,
                                permissions = new List<Permission>()
                               {
                                   new Permission()
                                   {
                                       label=item.ActionName,
                                       MenuActionID=item.MenuActionID,
                                       Istrue = false
                                   }
                               }

                            };
                            navMenu_.Add(obj);
                        }
                        else
                        {
                            var data = navMenu_.FirstOrDefault(x => x.SideMenuID == item.UISideMenuID);
                            data.permissions.Add(new Permission
                            {
                                label = item.ActionName,
                                MenuActionID = item.MenuActionID,
                                Istrue = false
                            });
                        }
                    }
                }
                foreach (var item in navMenu_)
                {
                    if (item.SubModules != null)
                    {
                        item.permissions = null;
                    }
                }
                #endregion

                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = navMenu_;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        public async Task<ResponseModel> GiveActionPermission(List<MenuActionModel> list)
        {
            var response = new ResponseModel();
            try
            {
                //Task<MasterEmailTemplateModel> GetEmailTemplate
                bool result = await _unitOfWork.SiteModel.GiveActionPermission(list);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public void CheckAllChildIsShown(List<NavListDecorationModel> SubModules)
        {
            IsShowMenu = false;
            foreach (var action in SubModules)
            {
                foreach (var CP in action.permissions)
                {
                    if (CP.value == true)
                    {
                        IsShowMenu = true;
                        break;
                    }
                }
            }

        }
        public void ChangeEachRowVal(NavListDecorationModel ParentObj)
        {

            if (ParentObj.SubModules != null && ParentObj.SubModules.Count > 0)
            {
                ParentObj.permissions = null;
                CheckAllChildIsShown(ParentObj.SubModules);
                ParentObj.IsShow = IsShowMenu;
                foreach (var action in ParentObj.SubModules)
                {
                    ChangeEachRowVal(action);
                }
            }
            else
            {
                if (ParentObj.permissions != null)
                {
                    foreach (var action in ParentObj.permissions)
                    {
                        if (action.value == true)
                        {

                            //IsShowMenu = true;
                            ParentObj.IsShow = true;
                            break;
                        }
                    }
                }

            }
            // ParentObj.IsShow = IsShowMenu;
        }
        public NavListDecorationModel FindNested(List<NavListDecorationModel> navMenu_, long? parentId)
        {
            foreach (var item in navMenu_)
            {
                if (item.SideMenuID == parentId)
                {
                    return item;
                }
                else if (item.SubModules != null && item.SubModules.Count > 0)
                {
                    var ret = FindNested(item.SubModules, parentId);
                    if (ret != null)
                    {
                        return ret;
                    }
                }

            }
            return null;
        }

        public async Task<ResponseModel> GetMenuPermissionForEdit(long RoleID)
        {
            var response = new ResponseModel();
            try
            {
                //Task<MasterEmailTemplateModel> GetEmailTemplate
                List<MenuPermissionEditModel> navMenuList = await _unitOfWork.SiteModel.GetMenuPermissionForEdit(RoleID);

                #region SubMenu
                foreach (var item in navMenuList)
                {

                    if (item.ParentSideMenuID != 0)
                    {
                        var pdata = FindNested(navMenu_, item.ParentSideMenuID);
                        NavListDecorationModel childMenu = (pdata != null && pdata.SubModules != null) ? pdata.SubModules.FirstOrDefault(y => y.SideMenuID == item.UISideMenuID) : null;

                        if (childMenu == null)
                        {
                            NavListDecorationModel subModu =
                                     new NavListDecorationModel()
                                     {
                                         SideMenuID = item.UISideMenuID,
                                         Header = item.Header,
                                         moduleName = item.Navigationlink,
                                         ClassStyle = item.ClassStyle,
                                         Navigationlink = item.Navigationlink,
                                         permissions = new List<Permission_>()
                                                {
                                                    new Permission_()
                                                        {
                                                            label=item.ActionName,
                                                            value=item.HasAccess,
                                                            MenuActionID=item.MenuActionID
                                                         }
                                                }

                                     };

                            pdata.SubModules.Add(subModu);

                        }
                        else
                        {
                            childMenu.permissions.Add(new Permission_()
                            {
                                label = item.ActionName,
                                value = item.HasAccess,
                                MenuActionID = item.MenuActionID
                            });

                        }


                    }
                    else
                    {
                        var s = navMenu_.Any(x => x.SideMenuID == item.UISideMenuID);
                        if (s != true)
                        {
                            NavListDecorationModel obj = new NavListDecorationModel()
                            {
                                SideMenuID = item.UISideMenuID,
                                Header = item.Header,
                                moduleName = item.Navigationlink,
                                ClassStyle = item.ClassStyle,
                                Navigationlink = item.Navigationlink,
                                permissions = new List<Permission_>()
                               {
                                   new Permission_()
                                   {
                                       label=item.ActionName,
                                       value=item.HasAccess,
                                       MenuActionID=item.MenuActionID
                                   }
                               }

                            };
                            navMenu_.Add(obj);
                        }
                        else
                        {
                            var data = navMenu_.FirstOrDefault(x => x.SideMenuID == item.UISideMenuID);
                            data.permissions.Add(new Permission_
                            {
                                label = item.ActionName,
                                value = item.HasAccess,
                                MenuActionID = item.MenuActionID
                            });
                        }
                    }
                }
                foreach (var item in navMenu_)
                {
                    ChangeEachRowVal(item);
                }
                #endregion
                if (navMenu_ != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = navMenu_;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        #endregion

        #region Document Center
        public async Task<ResponseModel> SaveDocument(DocumentCenterModel documentCenterModel)
        {

            var response = new ResponseModel();
            try
            {

                var fileStructureLocation = await _unitOfWork.SiteModel.GetFileStructureLocation((int)documentCenterModel.FileModel.CreatedBy);

                var savedFileName = FileUploadUtility.UploadBase64MultipleFile(documentCenterModel.FileModel.OriginalFileNameBase64, documentCenterModel.FileModel.FileExtension, fileStructureLocation);

                documentCenterModel.DocumentCenterGUID = Guid.NewGuid();

                documentCenterModel.FileModel.DocumentCenterFileGUID = Guid.NewGuid();

                documentCenterModel.FileModel.SaveFileName = savedFileName;

                var fileDownloadLink = fileStructureLocation + "/" + savedFileName;

                documentCenterModel.FileModel.FileDownloadLink = fileDownloadLink;

                //var fileVersion = 1.0M;
                //documentCenterModel.FileModel.FileVersion = fileVersion;
                //documentCenterModel.FileModel.FileVersion = documentCenterModel.FileModel.FileVersion + 1.0M;
                //Sponsor / 758BF36C - 6E42 - 46AF - 84AB - ED62DB9078A2 / BFBC5318 - 7C58 - 4AE6 - 9EC7 - 8BBE8BDE0C2E / file

                DocumentCenterModel result = await _unitOfWork.SiteModel.SaveDocument(documentCenterModel);

                if (result.ResultMessage == 200)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else if (result.ResultMessage == 201)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode201).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.DuplicateDocumentTitle;
                }

                //response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                //response.Data = result;
                //response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetDocumentCenterFilesId(SearchModel searchModel)
        {
            var response = new ResponseModel();
            try
            {
                List<DocumentListModel> result = new List<DocumentListModel>();

                result = await _unitOfWork.SiteModel.GetDocumentCenterFilesId(searchModel);

                List<DocumentCentreVM> docList = new List<DocumentCentreVM>();
                foreach (var item in result)
                {

                    var s = docList.Any(x => x.DocumentCenterId == item.DocumentCenterId);
                    if (s != true)
                    {
                        DocumentCentreVM objVM = new DocumentCentreVM();
                        objVM.DocumentCenterId = item.DocumentCenterId;
                        objVM.DocumentTitle = item.DocumentTitle;
                        objVM.documentCentreListVM.Add(new DocumentCentreListVM
                        {
                            DocumentCenterFileId = item.DocumentCenterFileId,
                            OrigionalFileName = item.OrigionalFileName,
                            Comment = item.Comment,
                            UploadedDate = item.UploadedDate,
                            DocumentVersion = item.DocumentVersion,
                            UploadedBy = item.UploadedBy,
                            DocumentType = item.DocumentType,
                            FileDownloadLink = item.FileDownloadLink

                        });
                        docList.Add(objVM);

                    }
                    else
                    {
                        var data = docList.FirstOrDefault(x => x.DocumentCenterId == item.DocumentCenterId);
                        data.documentCentreListVM.Add(new DocumentCentreListVM
                        {
                            DocumentCenterFileId = item.DocumentCenterFileId,
                            OrigionalFileName = item.OrigionalFileName,
                            Comment = item.Comment,
                            UploadedDate = item.UploadedDate,
                            DocumentVersion = item.DocumentVersion,
                            UploadedBy = item.UploadedBy,
                            DocumentType = item.DocumentType,
                            FileDownloadLink = item.FileDownloadLink
                        });

                    }
                }

                if (docList != null)
                {
                    foreach (var doc in docList)
                    {
                        foreach (var docCenterData in doc.documentCentreListVM)
                        {
                            if ((docCenterData.DocumentType == "doc") || (docCenterData.DocumentType == "docx"))
                            {
                                docCenterData.DocumentType = "Document";
                            }
                            else if ((docCenterData.DocumentType == "ppt") || (docCenterData.DocumentType == "pptx"))
                            {
                                docCenterData.DocumentType = "Presentation";
                            }

                            else if ((docCenterData.DocumentType == "m4v") || (docCenterData.DocumentType == "avi") || (docCenterData.DocumentType == "m4v") || (docCenterData.DocumentType == "mpg") || (docCenterData.DocumentType == "mp4") || (docCenterData.DocumentType == "m4v") || (docCenterData.DocumentType == "mov") || (docCenterData.DocumentType == "flv"))
                            {
                                docCenterData.DocumentType = "Video";

                            }
                            else if ((docCenterData.DocumentType == "jpg") || (docCenterData.DocumentType == "jpeg") || (docCenterData.DocumentType == "bmp") || (docCenterData.DocumentType == "png") || (docCenterData.DocumentType == "ico"))
                            {
                                docCenterData.DocumentType = "Image";

                            }

                            else if ((docCenterData.DocumentType == "pdf"))
                            {
                                docCenterData.DocumentType = "PDF Document";
                            }

                            else if ((docCenterData.DocumentType == "xml"))
                            {
                                docCenterData.DocumentType = "XML Document";
                            }

                            else if ((docCenterData.DocumentType == "xls") || (docCenterData.DocumentType == "xlsx"))
                            {
                                docCenterData.DocumentType = "Spreadsheet Document";
                            }

                            else if ((docCenterData.DocumentType == "txt"))
                            {
                                docCenterData.DocumentType = "Text Document";
                            }

                            else if ((docCenterData.DocumentType == "odp"))
                            {
                                docCenterData.DocumentType = "ODP Document";
                            }

                            else if ((docCenterData.DocumentType == "csv"))
                            {
                                docCenterData.DocumentType = "CSV Document";
                            }

                            else if ((docCenterData.DocumentType == "htm") || (docCenterData.DocumentType == "html"))
                            {
                                docCenterData.DocumentType = "Html Document";
                            }

                            else if ((docCenterData.DocumentType == "m4a") || (docCenterData.DocumentType == "mp3") || (docCenterData.DocumentType == "wav"))
                            {
                                docCenterData.DocumentType = "Audio";
                            }

                        }
                    }

                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = docList;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        public async Task<ResponseModel> GetExistingDocumentTitlesById(int Id)
        {
            var response = new ResponseModel();
            try
            {
                List<DocumentCenterModel> result = new List<DocumentCenterModel>();

                result = await _unitOfWork.SiteModel.GetExistingDocumentTitlesById(Id);

                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }



                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        public async Task<ResponseModel> GetFiledownloadBylink(string link)
        {
            {
                var response = new ResponseModel();
                try
                {

                    var result = FileUploadUtility.GetBase64FileBylink(link);



                    if (result != null)
                    {
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                        response.Data = result;
                        response.Message = IEHMessages.OperationSuccessful;
                    }
                    else
                    {
                        response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                        response.Data = null;
                        response.Message = IEHMessages.UserNotFound;
                    }

                    return response;
                }
                catch (Exception e)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.InternalServerError;
                    return response;
                }
            }
        }
        #endregion

        #region User Roles
        public async Task<ResponseModel> GetRolesList(int id)
        {
            var response = new ResponseModel();
            try
            {
                List<UserRolesModel> result = await _unitOfWork.SiteModel.GetRolesList(id);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetRoleById(int id)
        {
            var response = new ResponseModel();
            try
            {
                UserRolesModel result = await _unitOfWork.SiteModel.GetRoleById(id);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> SaveUserRole(UserRolesModel model)
        {
            var response = new ResponseModel();
            try
            {
                string result = await _unitOfWork.SiteModel.SaveUserRole(model);

                response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                response.Data = result;
                response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> DeleteUserRole(int id)
        {
            var response = new ResponseModel();
            try
            {
                UserRolesModel result = await _unitOfWork.SiteModel.DeleteUserRole(id);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> UpdateUserRole(UserRolesModel model)
        {
            var response = new ResponseModel();
            try
            {
                UserRolesModel result = await _unitOfWork.SiteModel.UpdateUserRole(model);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        #endregion

        #region Staff

        public async Task<ResponseModel> GetStaffInviteList(StaffModel staffModel)
        {
            var response = new ResponseModel();
            try
            {
                List<StaffModel> result = await _unitOfWork.SiteModel.GetStaffInviteById(staffModel.OrganizationID, staffModel.InviteAccept);
                response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                response.Data = result;
                response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetStaffDetails(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {

                StaffDetailsVM result = await _unitOfWork.SiteModel.GetStaffDetails(guidModel);

                var LastLoginTime = result.LastLogin == null ? DateTime.UtcNow : (DateTime)result.LastLogin;
                var easternAcceptDateZone = TimeZoneInfo.FindSystemTimeZoneById(_configuration["DateTimeFormat:TimeZone"]);
                result.LastLogin = TimeZoneInfo.ConvertTimeFromUtc(LastLoginTime, easternAcceptDateZone);

                var profilePicture = FileUploadUtility.GetBase64File(result.ProfilePicture, "Logo");
                result.ProfilePictureBase64 = profilePicture;

                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }



        public async Task<ResponseModel> ViewInviteStaffById(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {

                StaffModel result = await _unitOfWork.SiteModel.ViewInviteStaffById(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }


        public async Task<ResponseModel> SearchStaff(StaffModel modelSearch)
        {
            var response = new ResponseModel();
            try
            {

                List<StaffModel> result = await _unitOfWork.SiteModel.SearchStaff(modelSearch);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> AdminInviteForStaff(StaffModel adminInviteModel, IOptions<MailconfigModel> mailSmtpCred)
        {
            var response = new ResponseModel();
            try
            {
                // adminInviteModel.InviteDate = _commonMethods.ConvertUtcTime(DateTime.Now, "EST");
                StaffModel result = await _unitOfWork.SiteModel.SaveInvite_Staff(adminInviteModel);

                if (result != null)
                {
                    #region Template Send
                    string code = "AA00";
                    MasterEmailTemplateModel template = await _unitOfWork.SiteModel.GetEmailTemplate(code);

                    // string domainAddress = "http://localhost:4200/";
                    // string domainAddress = " https://ms.stagingsdei.com:4002/";
                    string domainAddress = _configuration["ActivationUrl:Development"];
                    string queryStringParams = "token=" + result.AccountInviteToken + "$mail=" + adminInviteModel.Email + "$name=" + adminInviteModel.FirstName + "|" + adminInviteModel.LastName;

                    DomainNameEnum domainNameValue = (DomainNameEnum)result.OrganizationTypeID;
                    string domainUrl = domainAddress + "/#/" + domainNameValue + "/activation?key=";

                    //string domainUrl = domainAddress + "superadmin/activation?key=";



                    #region Template URL replace params
                    string input = template.EmailTemplateDescription;
                    string pattern = @"\bNAME\b";

                    string replace = adminInviteModel.FirstName + " " + adminInviteModel.LastName;
                    string input2 = Regex.Replace(input, pattern, replace);

                    string pattern1 = @"\bACCOUNTSETUPLINK\b";

                    var encryoFromJavascript = commonMethod.EncryptStringToBytes(queryStringParams);
                    string queryString = Convert.ToBase64String(encryoFromJavascript);
                    string replace2 = domainUrl + queryString;
                    #endregion

                    string dbsaveURL = domainNameValue + "/activation?key=" + queryString;
                    string returnCode = await _unitOfWork.SiteModel.SaveUrlAdminInvitetable(result.AccountInviteToken, dbsaveURL);
                    string encriptUrl = Regex.Replace(input2, pattern1, "<a href=\"" + replace2 + "\">ACCOUNTSETUPLINK</a>");
                    SLSiteService.Common.MailConfig Email = new SLSiteService.Common.MailConfig();
                    string MailSubject = "Accept Admin Invitation";

                    Email.SendEmail(adminInviteModel.Email, null, null, MailSubject, encriptUrl, null, mailSmtpCred);

                    #endregion

                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }


        public async Task<ResponseModel> UpdateAdminInviteForStaff(StaffModel adminInviteModel, IOptions<MailconfigModel> mailSmtpCred)
        {
            var response = new ResponseModel();
            try
            {
                //adminInviteModel.InviteDate = _commonMethods.ConvertUtcTime(DateTime.Now, "EST");
                StaffModel result = await _unitOfWork.SiteModel.UpdateInvite_Staff(adminInviteModel);

                response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                //  response.Data = result;
                response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> UpdateStaffDetails(StaffDetailsModel staffDetailsModel)
        {
            var response = new ResponseModel();
            try
            {
                if (staffDetailsModel.IsEdit == true)
                {
                    #region Del Existing and Add New
                    if (staffDetailsModel.ProfilePicturebase64 != null)
                    {
                        FileUploadUtility.DeleteOldBase64File(staffDetailsModel.ProfilePicture);
                        var Favi = FileUploadUtility.UploadBase64File(staffDetailsModel.ProfilePicturebase64);
                        staffDetailsModel.ProfilePicture = Favi;
                    }
                    #endregion
                }
                else
                {
                    if (staffDetailsModel.ProfilePicturebase64 != null)
                    {
                        var profilePicture = FileUploadUtility.UploadBase64File(staffDetailsModel.ProfilePicturebase64);
                        staffDetailsModel.ProfilePicture = profilePicture;
                    }

                }




                var age = commonMethod.CalculateYourAge(staffDetailsModel.DobDateTime);
                staffDetailsModel.Age = age;

                ResponseModel result = await _unitOfWork.SiteModel.UpdateStaffDetails(staffDetailsModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    //  response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode400).ToString();
                    //response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }




        public async Task<ResponseModel> DeleteStaff(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                StaffModel result = await _unitOfWork.SiteModel.DeleteStaff(guidModel);
                response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                response.Data = result;
                response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetStaffInvite(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {

                StaffModel result = await _unitOfWork.SiteModel.GetStaffInvite(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> ActiveInactiveStaff(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                ResponseModel result = await _unitOfWork.SiteModel.ActiveInactiveStaff(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }


        public async Task<ResponseModel> AcceptInvite(AcceptInviteModel model)
        {
            var response = new ResponseModel();
            try
            {
                AdminInviteModel result = await _unitOfWork.SiteModel.AcceptInvite(model);
                response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                response.Data = result;
                response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }


        #endregion

        #region Study

        public async Task<ResponseModel> AddStudyInsertion(StudyInsertionModel Studies)
        {
            var response = new ResponseModel();
            try
            {
                response = await _unitOfWork.SiteModel.AddStudyInsertion(Studies);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }

        }

        public async Task<ResponseModel> GetCSDetailList(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                List<CSDetailsModel> result = await _unitOfWork.SiteModel.GetCSDetailList(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetStudyInsertionByCSGuid(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                StudyInsertionModel result = await _unitOfWork.SiteModel.GetStudyInsertionByCSGuid(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> DeleteStudyByCSGuid(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                response = await _unitOfWork.SiteModel.DeleteStudyByCSGuid(guidModel);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> UpdateStudyInsertion(StudyInsertionModel Studies, Guid csGuid)
        {
            var response = new ResponseModel();
            try
            {
                if (Studies.CSDetailsModels.IsPublish == true)
                {

                    Studies.CSDetailsModels.IsActive = true;
                }
                response = await _unitOfWork.SiteModel.UpdateStudyInsertion(Studies, csGuid);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> SearchStudies(CSDetailsModel modelSearch)
        {
            var response = new ResponseModel();
            try
            {
                //Task<MasterEmailTemplateModel> GetEmailTemplate
                List<CSDetailsModel> result = await _unitOfWork.SiteModel.SearchStudies(modelSearch);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> ActiveInactiveStudyByCSGuid(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                response = await _unitOfWork.SiteModel.ActiveInactiveStudyByCSGuid(guidModel);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        #endregion

        #region Inventory
        public async Task<ResponseModel> GetDetails(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                CSInventoryModelWithGuid result = await _unitOfWork.SiteModel.GetDetails(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetCodeList(int type)
        {
            var response = new ResponseModel();
            try
            {
                List<CodesModelData> result = await _unitOfWork.SiteModel.GetCodeList(type);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> SearchInventory(SearchModelInventory search)
        {
            var response = new ResponseModel();
            try
            {
                StudyInventoryModel result = await _unitOfWork.SiteModel.SearchInventory(search);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }


                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> AddStudyInventory(StudyInventoryModel inventoryModel)
        {
            var response = new ResponseModel();
            try
            {
                response = await _unitOfWork.SiteModel.AddStudyInventory(inventoryModel);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> DeleteInventory(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                ResponseModel result = await _unitOfWork.SiteModel.DeleteInventory(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        public async Task<ResponseModel> UpdateStudyInventory(CSInventoryModel inventoryModel)
        {
            var response = new ResponseModel();
            try
            {
                response = await _unitOfWork.SiteModel.UpdateStudyInventory(inventoryModel);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetStudyInventoryByCSGuid(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                StudyInventoryModel result = await _unitOfWork.SiteModel.GetStudyInventoryByCSGuid(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        #endregion

        #region Participant

        public async Task<ResponseModel> GetParticipantInviteList(ParticipantModel participantModel)
        {
            var response = new ResponseModel();
            try
            {
                List<ParticipantModel> result = await _unitOfWork.SiteModel.GetParticipantInviteById(participantModel.OrganizationID, participantModel.InviteAccept);
                response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                response.Data = result;
                response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        public async Task<ResponseModel> SearchParticipant(ParticipantModel modelSearch)
        {
            var response = new ResponseModel();
            try
            {
                //Task<MasterEmailTemplateModel> GetEmailTemplate
                List<ParticipantModel> result = await _unitOfWork.SiteModel.SearchParticipant(modelSearch);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> AdminInviteForParticipant(ParticipantModel adminInviteModel, IOptions<MailconfigModel> mailSmtpCred)
        {
            var response = new ResponseModel();
            try
            {
                var LastLoginTime = DateTime.UtcNow;
                var easternAcceptDateZone = TimeZoneInfo.FindSystemTimeZoneById(_configuration["DateTimeFormat:TimeZone"]);
                adminInviteModel.InviteDate = TimeZoneInfo.ConvertTimeFromUtc(LastLoginTime, easternAcceptDateZone);

                ParticipantModel result = await _unitOfWork.SiteModel.SaveInvite_Participant(adminInviteModel);

                if (result != null)
                {
                    #region Template Send

                    string code = "AA00";
                    MasterEmailTemplateModel template = await _unitOfWork.SiteModel.GetEmailTemplate(code);

                    // string domainAddress = "http://localhost:4200/";
                    // string domainAddress = " https://ms.stagingsdei.com:4002/";
                    string domainAddress = _configuration["ActivationUrl:Development"];

                    string queryStringParams = "token=" + result.AccountInviteToken + "$mail=" + adminInviteModel.Email + "$name=" + adminInviteModel.FirstName + "|" + adminInviteModel.LastName + "$Identity=Participant";

                    DomainNameEnum domainNameValue = (DomainNameEnum)result.OrganizationTypeID;
                    string domainUrl = domainAddress + "/#/" + domainNameValue + "/activation?key=";

                    //string domainUrl = domainAddress + "superadmin/activation?key=";



                    #region Template URL replace params
                    string input = template.EmailTemplateDescription;
                    string pattern = @"\bNAME\b";

                    string replace = adminInviteModel.FirstName + " " + adminInviteModel.LastName;
                    string input2 = Regex.Replace(input, pattern, replace);

                    string pattern1 = @"\bACCOUNTSETUPLINK\b";

                    var encryoFromJavascript = commonMethod.EncryptStringToBytes(queryStringParams);
                    string queryString = Convert.ToBase64String(encryoFromJavascript);
                    string replace2 = domainUrl + queryString;
                    #endregion

                    string dbsaveURL = domainNameValue + "/activation?key=" + queryString;
                    string returnCode = await _unitOfWork.SiteModel.SaveUrlAdminInvitetable(result.AccountInviteToken, dbsaveURL);
                    string encriptUrl = Regex.Replace(input2, pattern1, "<a href=\"" + replace2 + "\">ACCOUNTSETUPLINK</a>");
                    SLSiteService.Common.MailConfig Email = new SLSiteService.Common.MailConfig();
                    string MailSubject = "Accept Admin Invitation";

                    Email.SendEmail(adminInviteModel.Email, null, null, MailSubject, encriptUrl, null, mailSmtpCred);

                    #endregion

                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetParticipant(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                ParticipantModel result = await _unitOfWork.SiteModel.GetParticipant(guidModel);
                response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                response.Data = result;
                response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> DeleteParticipant(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                ParticipantModel result = await _unitOfWork.SiteModel.DeleteParticipant(guidModel);
                response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                response.Data = result;
                response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }


        public async Task<ResponseModel> BlockUnblockParticipant(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                ParticipantModel result = await _unitOfWork.SiteModel.BlockUnblockParticipant(guidModel);
                response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                response.Data = result;
                response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> UpdateAdminInviteForParticipant(ParticipantModel adminInviteModel, IOptions<MailconfigModel> mailSmtpCred)
        {
            var response = new ResponseModel();
            try
            {                
                ParticipantModel result = await _unitOfWork.SiteModel.UpdateInvite_Participant(adminInviteModel);

                if (result.ReturnCode == "200")
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.Success;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }


                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetParticipantDetails(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {

                StaffDetailsVM result = await _unitOfWork.SiteModel.GetParticipantDetails(guidModel);

                var LastLoginTime = result.LastLogin == null ? DateTime.UtcNow : (DateTime)result.LastLogin;
                var easternAcceptDateZone = TimeZoneInfo.FindSystemTimeZoneById(_configuration["DateTimeFormat:TimeZone"]);
                result.LastLogin = TimeZoneInfo.ConvertTimeFromUtc(LastLoginTime, easternAcceptDateZone);

                var profilePicture = FileUploadUtility.GetBase64File(result.ProfilePicture, "Logo");
                result.ProfilePictureBase64 = profilePicture;

                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }


        public async Task<ResponseModel> ActiveInactiveParticipant(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                ResponseModel result = await _unitOfWork.SiteModel.ActiveInactiveParticipant(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> AcceptInviteForParticipant(AcceptInviteModel model)
        {
            var response = new ResponseModel();
            try
            {
                AdminInviteModel result = await _unitOfWork.SiteModel.AcceptInviteForParticipant(model);
                response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                response.Data = result;
                response.Message = IEHMessages.OperationSuccessful;

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }


        public async Task<ResponseModel> UpdateUserparticipantDetails(UserDetailProfileModel userDetailsModel)
        {
            var response = new ResponseModel();
            try
            {
                if (userDetailsModel.IsEdit == true)
                {
                    #region Delete existing and add new

                    if (userDetailsModel.ProfilePicturebase64 != null)
                    {
                        FileUploadUtility.DeleteOldBase64File(userDetailsModel.ProfilePicture);
                        var Favi = FileUploadUtility.UploadBase64File(userDetailsModel.ProfilePicturebase64);
                        userDetailsModel.ProfilePicture = Favi;
                    }
                    #endregion
                }
                else
                {
                    if (userDetailsModel.ProfilePicturebase64 != null)
                    {
                        var profilePicture = FileUploadUtility.UploadBase64File(userDetailsModel.ProfilePicturebase64);
                        userDetailsModel.ProfilePicture = profilePicture;
                    }
                }

                var age = commonMethod.CalculateYourAge(userDetailsModel.DobDateTime);
                userDetailsModel.Age = age;

                ResponseModel result = await _unitOfWork.SiteModel.UpdateUserparticipantDetails(userDetailsModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    //  response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode400).ToString();
                    //response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        #endregion



        #region Principal Investigator

        public async Task<ResponseModel> SiteViewPrincipalByRoleId(RoleModelData roleModel)
        {
            var response = new ResponseModel();
            try
            {
                List<StaffModel> result = await _unitOfWork.SiteModel.SiteViewPrincipalByRoleId(roleModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }


        public async Task<ResponseModel> SearchPrincipalInvestigator(StaffModel modelSearch)
        {
            var response = new ResponseModel();
            try
            {

                List<StaffModel> result = await _unitOfWork.SiteModel.SearchPrincipalInvestigator(modelSearch);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        #endregion
    }
}

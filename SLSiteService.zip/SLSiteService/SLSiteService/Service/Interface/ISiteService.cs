﻿
using Shared.Model;
using SLSiteService.Common.ResponseVM;
using SLSiteService.Model;
using SLSiteService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Service.Interface
{
    public interface ISiteService
    {
        #region Auth Service
        Task<ResponseModel> Login(LoginModel loginVM);
        Task<ResponseModel> resendOTP(resendOTPModel resendOTPModel);
        Task<ResponseModel> LoginOTPVerification(OTPModel model);
        string Logout(LogoutModel model);

        #endregion

        #region Common Service
        Task<ResponseModel> GetCountry();
        Task<ResponseModel> GetStateCountrywise(int id);
        Task<ResponseModel> GetCityStatewise(int id);

        // MENU WISE PERMISSION
        Task<ResponseModel> GetMenuActionList(long id);
        Task<ResponseModel> GiveActionPermission(List<MenuActionModel> list);
        Task<ResponseModel> GetMenuPermissionForEdit(long RoleID);


        //User details for dashboard
        Task<ResponseModel> GetUserDetails(UserInputModel model);
        Task<ResponseModel> UpdateUserDetails(UserDetailProfileModel userDetailsModel);
        #endregion

        #region Document Center
        Task<ResponseModel> SaveDocument(DocumentCenterModel documentCenterModel);
        Task<ResponseModel> GetDocumentCenterFilesId(SearchModel Model);
        Task<ResponseModel> GetExistingDocumentTitlesById(int id);
        Task<ResponseModel> GetFiledownloadBylink(string link);
        #endregion

        #region User Roles
        Task<ResponseModel> GetRolesList(int id);
        Task<ResponseModel> GetRoleById(int id);
        Task<ResponseModel> SaveUserRole(UserRolesModel model);
        Task<ResponseModel> DeleteUserRole(int id);
        Task<ResponseModel> UpdateUserRole(UserRolesModel model);
        #endregion

        #region Staff Service
        Task<ResponseModel> SearchStaff(StaffModel search);
        Task<ResponseModel> AdminInviteForStaff(StaffModel adminInviteModel, Microsoft.Extensions.Options.IOptions<MailconfigModel> mailSmtpCred);
        Task<ResponseModel> DeleteStaff(GuidModel guidModel);
        Task<ResponseModel> UpdateAdminInviteForStaff(StaffModel adminInviteModel, Microsoft.Extensions.Options.IOptions<MailconfigModel> mailSmtpCred);
        Task<ResponseModel> GetStaffInviteList(StaffModel staffModel);
        Task<ResponseModel> GetStaffInvite(GuidModel guidModel);
        Task<ResponseModel> ViewInviteStaffById(GuidModel guidModel);
        Task<ResponseModel> GetStaffDetails(GuidModel guidModel);
        Task<ResponseModel> ActiveInactiveStaff(GuidModel guidModel);
        Task<ResponseModel> UpdateStaffDetails(StaffDetailsModel staffDetailsModel);

        //Invitation accept
        Task<ResponseModel> AcceptInvite(AcceptInviteModel model);
        #endregion

        #region Study
        Task<ResponseModel> AddStudyInsertion(StudyInsertionModel Studies);
        Task<ResponseModel> GetCSDetailList(GuidModel guidModel);
        Task<ResponseModel> GetStudyInsertionByCSGuid(GuidModel guidModel);
        Task<ResponseModel> DeleteStudyByCSGuid(GuidModel guidModel);
        Task<ResponseModel> ActiveInactiveStudyByCSGuid(GuidModel guidModel);
        Task<ResponseModel> UpdateStudyInsertion(StudyInsertionModel Studies, Guid csGuid);
        Task<ResponseModel> SearchStudies(CSDetailsModel search);

        #endregion

        #region Inventory
     
        Task<ResponseModel> AddStudyInventory(StudyInventoryModel inventoryModel);
        Task<ResponseModel> UpdateStudyInventory(CSInventoryModel inventoryModel);
        Task<ResponseModel> GetStudyInventoryByCSGuid(GuidModel guidModel);
        Task<ResponseModel> GetCodeList(int type);
        Task<ResponseModel> DeleteInventory(GuidModel guidModel);
        Task<ResponseModel> GetDetails(GuidModel guidModel);
        Task<ResponseModel> SearchInventory(SearchModelInventory searchModel);
        #endregion

        #region Participant
        Task<ResponseModel> SearchParticipant(ParticipantModel search);
        Task<ResponseModel> GetParticipantInviteList(ParticipantModel staffModel);
        Task<ResponseModel> AdminInviteForParticipant(ParticipantModel adminInviteModel, Microsoft.Extensions.Options.IOptions<MailconfigModel> mailSmtpCred);
        Task<ResponseModel> UpdateAdminInviteForParticipant(ParticipantModel adminInviteModel, Microsoft.Extensions.Options.IOptions<MailconfigModel> mailSmtpCred);
        Task<ResponseModel> GetParticipant(GuidModel guidModel);
        Task<ResponseModel> DeleteParticipant(GuidModel guidModel);
        Task<ResponseModel> BlockUnblockParticipant(GuidModel guidModel);
        Task<ResponseModel> GetParticipantDetails(GuidModel guidModel);
        Task<ResponseModel> ActiveInactiveParticipant(GuidModel guidModel);
        Task<ResponseModel> AcceptInviteForParticipant(AcceptInviteModel model);        
        Task<ResponseModel> UpdateUserparticipantDetails(UserDetailProfileModel userDetailsModel);
        #endregion

        #region Principal Investigator
        Task<ResponseModel> SiteViewPrincipalByRoleId(RoleModelData roleModel);
        Task<ResponseModel> SearchPrincipalInvestigator(StaffModel search);
        #endregion
    }
}

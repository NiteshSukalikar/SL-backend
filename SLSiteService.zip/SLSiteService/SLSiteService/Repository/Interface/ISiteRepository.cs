﻿using Shared.Model;
using SLSiteService.Model;
using SLSiteService.Models;
using SLSiteService.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Repository.Interface
{
    public interface ISiteRepository
    {

        #region Auth Services
        Task<UserDetails> GetUserDetailsById(string UserId);
        Task<UserDetails> GetUserDetailsForLogin(LoginModel loginVM);
        string Logout(LogoutModel model);
        string SaveLogUserSystem(SaveLogUserSystem model);
        List<SideMenuAuth> UINavMenuList(long domainID);
        #endregion

        #region Common Service
        Task<List<CountryMasterModel>> GetCountry();
        Task<List<StateMasterModel>> GetStateCountrywise(int id);
        Task<List<CityMasterModel>> GetCityStatewise(int id);
        Task<List<SideMenuModel>> GetMenuActionList(long id);
        Task<bool> GiveActionPermission(List<MenuActionModel> list);
        Task<List<MenuPermissionEditModel>> GetMenuPermissionForEdit(long RoleID);

        // User Details For Profile

        Task<UserInfoDetailsVM> GetUserDetails(UserInputModel model);
        Task<ResponseModel> UpdateUserDetails(UserDetailProfileModel userDetailsModel);
        #endregion

        #region Document Center
        Task<DocumentCenterModel> SaveDocument(DocumentCenterModel documentCenterModel);
        Task<List<DocumentListModel>> GetDocumentCenterFilesId(SearchModel searchModel);
        Task<DocumentCenterModel> GetDocumentCenterFileVersion(long documentCenterId, long createdBy);
        Task<string> GetFileStructureLocation(int userId);
        Task<List<DocumentCenterModel>> GetExistingDocumentTitlesById(int Id);
        #endregion

        #region User Roles
        Task<UserRolesModel> DeleteUserRole(int id);
        Task<UserRolesModel> UpdateUserRole(UserRolesModel model);
        Task<List<UserRolesModel>> GetRolesList(int id);
        Task<UserRolesModel> GetRoleById(int id);
        Task<string> SaveUserRole(UserRolesModel model);
        #endregion

        #region Staff Service

        //for sending template emails
        Task<MasterEmailTemplateModel> GetEmailTemplate(string code);
        Task<string> SaveUrlAdminInvitetable(Guid tokenGuid, string encripURL);
        Task<List<StaffModel>> SearchStaff(StaffModel model);
        Task<StaffModel> SaveInvite_Staff(StaffModel adminInviteModel);
        Task<StaffModel> DeleteStaff(GuidModel guidModel);
        Task<List<StaffModel>> GetStaffInviteById(long id, bool? type);
        Task<StaffModel> UpdateInvite_Staff(StaffModel adminInviteModel);
        Task<StaffModel> GetStaffInvite(GuidModel guidModel);
        Task<StaffDetailsVM> GetStaffDetails(GuidModel guidModel);
        Task<ResponseModel> ActiveInactiveStaff(GuidModel guidModel);
        Task<StaffModel> ViewInviteStaffById(GuidModel guidModel);
        Task<ResponseModel> UpdateStaffDetails(StaffDetailsModel staffDetailsModel);

        //Invitation accept
        Task<AdminInviteModel> AcceptInvite(AcceptInviteModel model);
        #endregion

        #region Study
        Task<ResponseModel> AddStudyInsertion(StudyInsertionModel Studies);
        Task<List<CSDetailsModel>> GetCSDetailList(GuidModel guidModel);
        Task<StudyInsertionModel> GetStudyInsertionByCSGuid(GuidModel guidModel);
        Task<ResponseModel> DeleteStudyByCSGuid(GuidModel guidModel);
        Task<ResponseModel> ActiveInactiveStudyByCSGuid(GuidModel guidModel);
        Task<ResponseModel> UpdateStudyInsertion(StudyInsertionModel Studies, Guid csGuid);
        Task<List<CSDetailsModel>> SearchStudies(CSDetailsModel model);

        #endregion

        #region Inventory
        
        Task<List<CodesModelData>> GetCodeList(int type);
        Task<StudyInventoryModel> SearchInventory(SearchModelInventory searchModel);
        Task<ResponseModel> AddStudyInventory(StudyInventoryModel inventoryModel);
        Task<ResponseModel> UpdateStudyInventory(CSInventoryModel inventoryModel);
        Task<StudyInventoryModel> GetStudyInventoryByCSGuid(GuidModel guidModel);
        Task<CSInventoryModelWithGuid> GetDetails(GuidModel guidModel);
        Task<ResponseModel> DeleteInventory(GuidModel guidModel);
        #endregion

        #region Participant
        Task<List<ParticipantModel>> SearchParticipant(ParticipantModel model);
        Task<List<ParticipantModel>> GetParticipantInviteById(long id, bool? type);
        Task<ParticipantModel> SaveInvite_Participant(ParticipantModel adminInviteModel);
        Task<ParticipantModel> UpdateInvite_Participant(ParticipantModel adminInviteModel);
        Task<ParticipantModel> GetParticipant(GuidModel guidModel);
        Task<ParticipantModel> DeleteParticipant(GuidModel guidModel);
        Task<ParticipantModel> BlockUnblockParticipant(GuidModel guidModel);
        Task<StaffDetailsVM> GetParticipantDetails(GuidModel guidModel);
        Task<ResponseModel> ActiveInactiveParticipant(GuidModel guidModel);
        Task<AdminInviteModel> AcceptInviteForParticipant(AcceptInviteModel model);        
        Task<ResponseModel> UpdateUserparticipantDetails(UserDetailProfileModel userDetailsModel);

        #endregion

        #region Principal Investigator
        Task<List<StaffModel>> SiteViewPrincipalByRoleId(RoleModelData roleModel);
        Task<List<StaffModel>> SearchPrincipalInvestigator(StaffModel model);
        #endregion
    }
}

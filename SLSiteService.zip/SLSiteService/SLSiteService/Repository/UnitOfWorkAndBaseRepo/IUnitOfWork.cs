﻿
namespace SLSiteService.Repository.UnitOfWorkAndBaseRepo
{
    using SLSiteService.Repository.Interface;
    using System;

    /// <summary>
    /// Defines the <see cref="IUnitOfWork" />
    /// </summary>
    public interface IUnitOfWork : IDisposable
    {
        /// <summary>
        /// Gets the UserDetailsModel
        /// </summary>
        ISiteRepository SiteModel { get; }
        /// <summary>
        /// The Complete
        /// </summary>
        /// <returns>The <see cref="int"/></returns>
        int Complete();
    }
}

﻿using IEH_Shared.Utility;
using Microsoft.Data.SqlClient;
using Shared.Enum;
using Shared.Helper;
using Shared.Model;
using SLSiteService.Common.StaticConstants;
using SLSiteService.Infrastructure.DataAccess;
using SLSiteService.Model;
using SLSiteService.Models;
using SLSiteService.Repository.Interface;
using SLSiteService.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SLSiteService.Repository.Implementation
{
    public class SiteRepository : ISiteRepository
    {
        private readonly IEHDbContext _IEHDbContext;
        private readonly CommonMethods _commonMethods;
        public SiteRepository(IEHDbContext IEHDbContext)
        {
            _IEHDbContext = IEHDbContext;
            _commonMethods = new CommonMethods();
        }

        #region Auth 
        public async Task<UserDetails> GetUserDetailsForLogin(LoginModel loginVM)
        {
            SqlParameter[] param = {
                new SqlParameter("@Email", loginVM.Email.ToLower()),
                new SqlParameter("@DomainId", loginVM.DomainID)
            };

            var connection = _IEHDbContext.GetDbConnection();
            try
            {
                if (connection.State == ConnectionState.Closed) { connection.Open(); }
                using (var cmd = connection.CreateCommand())
                {
                    _IEHDbContext.AddParametersToDbCommand(SpConstants.GetUserDetailsForLogin, param, cmd);
                    using (var reader = cmd.ExecuteReader())
                    {
                        UserDetails LastLoginDetail = null;
                        LastLoginDetail = _IEHDbContext.DataReaderMapToList<UserDetails>(reader).FirstOrDefault();
                        return LastLoginDetail;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }
        }

        public async Task<UserDetails> GetUserDetailsById(string userId)
        {
            UserDetails result = new UserDetails();
            SqlParameter[] param = {
                new SqlParameter("@Id", userId),
            };

            var connection = _IEHDbContext.GetDbConnection();
            try
            {
                if (connection.State == ConnectionState.Closed) { connection.Open(); }
                using (var cmd = connection.CreateCommand())
                {
                    _IEHDbContext.AddParametersToDbCommand(SpConstants.GetUserById, param, cmd);
                    using (var reader = cmd.ExecuteReader())
                    {
                        var LastLoginDetail = _IEHDbContext.DataReaderMapToList<UserDetails>(reader).FirstOrDefault();
                        return LastLoginDetail;
                    }
                }
            }
            catch (Exception ex)
            {
                result.ContactNumber = ex.Message;
                return result;
            }

            finally
            {
                connection.Close();
            }
        }

        public List<SideMenuAuth> UINavMenuList(long UserID)
        {

            SqlParameter[] param = {
              new SqlParameter("@UserID",UserID)
            };

            var connection = _IEHDbContext.GetDbConnection();
            List<SideMenuAuth> LastLoginDetail = new List<SideMenuAuth>();
            try
            {
                if (connection.State == ConnectionState.Closed) { connection.Open(); }
                using (var cmd = connection.CreateCommand())
                {
                    _IEHDbContext.AddParametersToDbCommand(SpConstants.UIGetNavMenuForSponser, param, cmd);
                    using (var reader = cmd.ExecuteReader())
                    {

                        LastLoginDetail = _IEHDbContext.DataReaderMapToList<SideMenuAuth>(reader).ToList();
                        reader.NextResult();

                    }
                }
                return LastLoginDetail;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }

        }

        public string SaveLogUserSystem(SaveLogUserSystem model)
        {
            var LogUserCreatedOn = DateTime.UtcNow;
            var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
            {
                Direction = ParameterDirection.Output
            };

            SqlParameter[] param = {
                new SqlParameter("@SystemIPAddress", model.SystemIPAddress),
                new SqlParameter("@OrganizationsToken", model.OrganizationsToken),
                new SqlParameter("@SystemLocationAddress", model.SystemLocationAddress),
                new SqlParameter("@UserLoggedInTime", model.UserLoggedInTime),
                new SqlParameter("@LogUserCreatedOn", LogUserCreatedOn),
                new SqlParameter("@UserId", long.Parse(model.UserId)),
                outParam
            };
            var connection = _IEHDbContext.GetDbConnection();
            try
            {
                SqlHelper.ExecuteProcedureReturnString(Constants.DbConn, SpConstants.SaveLogUserSystem, param);
                return (string)outParam.Value;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }
        }
        #endregion

        #region Common 
        public async Task<List<CountryMasterModel>> GetCountry()
        {
            try
            {
                SqlParameter[] param = { };
                var connection = _IEHDbContext.GetDbConnection();
                List<CountryMasterModel> result = new List<CountryMasterModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetCountryList, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<CountryMasterModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<StateMasterModel>> GetStateCountrywise(int id)
        {
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@Id",id)
                };
                var connection = _IEHDbContext.GetDbConnection();
                List<StateMasterModel> result = new List<StateMasterModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetStateListCountrywise, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<StateMasterModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<CityMasterModel>> GetCityStatewise(int id)
        {
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@Id",id)
                };
                var connection = _IEHDbContext.GetDbConnection();
                List<CityMasterModel> result = new List<CityMasterModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetCityListStatewise, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<CityMasterModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<SideMenuModel>> GetMenuActionList(long UserID)
        {
            SqlParameter[] param = {
              new SqlParameter("@UserID",UserID)
            };

            var connection = _IEHDbContext.GetDbConnection();
            List<SideMenuModel> LastLoginDetail = new List<SideMenuModel>();
            try
            {
                if (connection.State == ConnectionState.Closed) { connection.Open(); }
                using (var cmd = connection.CreateCommand())
                {
                    _IEHDbContext.AddParametersToDbCommand(SpConstants.UIGetMenuActionList, param, cmd);
                    using (var reader = cmd.ExecuteReader())
                    {

                        LastLoginDetail = _IEHDbContext.DataReaderMapToList<SideMenuModel>(reader).ToList();
                        reader.NextResult();

                    }
                }
                return LastLoginDetail;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }
        }

        public async Task<bool> GiveActionPermission(List<MenuActionModel> list)
        {
            //List<NavInsertionModel> list = new List<NavInsertionModel>();
            //foreach (var item in obj.NavMenuActionId)
            //{
            //    list.Add(new NavInsertionModel() { DomainRolesID = obj.DomainRolesID, NavMenuActionId = item });
            //}

            try
            {
                //SeedChildMasterMenu
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                //var IsSuccessful = new SqlParameter("@IsSuccessful", SqlDbType.Bit)
                //{
                //    Direction = ParameterDirection.Output
                //};
                //convert list to datatable
                DataTable dtChildMenus = list.ToDataTable<MenuActionModel>();
                SqlParameter[] param = {
                   new SqlParameter("@ChildMastertemp",dtChildMenus),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                bool result = false;
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.UIPermissionEntry, param, cmd);
                        cmd.ExecuteNonQuery();

                        //result = (bool)cmd.Parameters["@IsSuccessful"].Value;
                    }
                }
                finally
                {
                    connection.Close();
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<MenuPermissionEditModel>> GetMenuPermissionForEdit(long RoleID)
        {

            SqlParameter[] param = {
              new SqlParameter("@RoleID",RoleID)
            };

            var connection = _IEHDbContext.GetDbConnection();
            List<MenuPermissionEditModel> LastLoginDetail = new List<MenuPermissionEditModel>();
            try
            {
                if (connection.State == ConnectionState.Closed) { connection.Open(); }
                using (var cmd = connection.CreateCommand())
                {
                    _IEHDbContext.AddParametersToDbCommand(SpConstants.UIGetMenuWithPermissionForRole, param, cmd);
                    using (var reader = cmd.ExecuteReader())
                    {

                        LastLoginDetail = _IEHDbContext.DataReaderMapToList<MenuPermissionEditModel>(reader).ToList();
                        reader.NextResult();

                    }
                }
                return LastLoginDetail;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }

        }
        #endregion

        #region Document Center
        public async Task<DocumentCenterModel> SaveDocument(DocumentCenterModel documentCenterModel)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                var outParamDocumentCenterId = new SqlParameter("@DocumentCenterId", SqlDbType.BigInt)
                {
                    Direction = ParameterDirection.Output
                };

                var outParamDocumentCenterFileId = new SqlParameter("@DocumentCenterFileId", SqlDbType.BigInt)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@DropdownDocID ",documentCenterModel.DocumentCenterId),
                    new SqlParameter("@DocumentCenterGUID",documentCenterModel.DocumentCenterGUID),
                    new SqlParameter("@DocumentTitle",documentCenterModel.DocumentTitle),
                    new SqlParameter("@DocumentCenterFileGUID",documentCenterModel.FileModel.DocumentCenterFileGUID),
                    new SqlParameter("@DocumentCenterOriginalFileName",documentCenterModel.FileModel.OriginalFileName),
                    new SqlParameter("@DocumentCenterSaveFileName",documentCenterModel.FileModel.SaveFileName),
                    new SqlParameter("@DocumentCenterFileExtension",documentCenterModel.FileModel.FileExtension),
                     new SqlParameter("@DocumentCenterFileVersion",documentCenterModel.FileModel.FileVersion),
                    new SqlParameter("@DocumentCenterFileUploadedBy",documentCenterModel.FileModel.FileUploadedBy),
                    new SqlParameter("@DocumentCenterFileCommentText",documentCenterModel.FileModel.CommentText),
                    new SqlParameter("@DocumentCenterFileDownloadLink",documentCenterModel.FileModel.FileDownloadLink),
                   new SqlParameter("@CreatedBy",documentCenterModel.FileModel.CreatedBy),


                    outParam,outParamDocumentCenterId,outParamDocumentCenterFileId
                };
                var connection = _IEHDbContext.GetDbConnection();
                DocumentCenterModel result = new DocumentCenterModel();
                result.FileModel = new DocumentCenterFileModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.SaveDocument, param, cmd);
                        cmd.ExecuteNonQuery();
                        string message = (string)cmd.Parameters["@ReturnCode"].Value;
                        result.DocumentCenterId = (long)cmd.Parameters["@DocumentCenterId"].Value;
                        result.FileModel.DocumentCenterFileId = (long)cmd.Parameters["@DocumentCenterFileId"].Value;
                        result.ResultMessage = Convert.ToInt32(message);
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<DocumentListModel>> GetDocumentCenterFilesId(SearchModel searchModel)
        {

            SqlParameter[] param = {
              new SqlParameter("@Id",searchModel.Id),
              new SqlParameter("@Search",searchModel.Search)
            };

            var connection = _IEHDbContext.GetDbConnection();
            DocumentListModel documentListDetail = new DocumentListModel();

            List<DocumentListModel> documentList = new List<DocumentListModel>();
            try
            {
                if (connection.State == ConnectionState.Closed) { connection.Open(); }
                using (var cmd = connection.CreateCommand())
                {
                    _IEHDbContext.AddParametersToDbCommand(SpConstants.GetDocumentById, param, cmd);
                    using (var reader = cmd.ExecuteReader())
                    {

                        documentList = _IEHDbContext.DataReaderMapToList<DocumentListModel>(reader).ToList();
                        reader.NextResult();

                    }
                }


                // documentListDetail.DocumentTitleContent = documentList.Where(d=>d.DocumentCenterId)

                return documentList;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }

        }
        public async Task<List<DocumentCenterModel>> GetExistingDocumentTitlesById(int Id)
        {

            SqlParameter[] param = {
              new SqlParameter("@Id",Id)
            };

            var connection = _IEHDbContext.GetDbConnection();
            DocumentListModel documentListDetail = new DocumentListModel();

            List<DocumentCenterModel> documentList = new List<DocumentCenterModel>();
            try
            {
                if (connection.State == ConnectionState.Closed) { connection.Open(); }
                using (var cmd = connection.CreateCommand())
                {
                    _IEHDbContext.AddParametersToDbCommand(SpConstants.GetExistingDocumentTitlesById, param, cmd);
                    using (var reader = cmd.ExecuteReader())
                    {

                        documentList = _IEHDbContext.DataReaderMapToList<DocumentCenterModel>(reader).ToList();
                        reader.NextResult();

                    }
                }


                // documentListDetail.DocumentTitleContent = documentList.Where(d=>d.DocumentCenterId)

                return documentList;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }

        }
        public async Task<string> GetFileStructureLocation(int userId)
        {

            var outParam = new SqlParameter("@fullpath", SqlDbType.NVarChar, 500)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
              new SqlParameter("@UserID",userId),
             outParam
            };

            var connection = _IEHDbContext.GetDbConnection();
            string fileFullPath = "";
            try
            {
                if (connection.State == ConnectionState.Closed) { connection.Open(); }
                using (var cmd = connection.CreateCommand())
                {
                    _IEHDbContext.AddParametersToDbCommand(SpConstants.GetFolderStructurePath, param, cmd);
                    cmd.ExecuteNonQuery();
                    fileFullPath = (string)cmd.Parameters["@fullpath"].Value;
                }

                return fileFullPath;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }

        }
        public async Task<DocumentCenterModel> GetDocumentCenterFileVersion(long documentCenterId, long createdBy)
        {

            SqlParameter[] param = {
              new SqlParameter("@documentCenterId",documentCenterId),
              new SqlParameter("@createdBy",createdBy)
            };

            var connection = _IEHDbContext.GetDbConnection();
            DocumentCenterModel LastLoginDetail = new DocumentCenterModel();
            try
            {
                if (connection.State == ConnectionState.Closed) { connection.Open(); }
                using (var cmd = connection.CreateCommand())
                {
                    _IEHDbContext.AddParametersToDbCommand(SpConstants.UIGetMenuWithPermissionForRole, param, cmd);
                    //using (var reader = cmd.ExecuteReader())
                    //{

                    //    LastLoginDetail = _IEHDbContext.DataReaderMapToList<MenuPermissionEditModel>(reader).ToList();
                    //    reader.NextResult();

                    //}
                }
                return LastLoginDetail;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }

        }
        #endregion

        #region User Roles
        public async Task<List<UserRolesModel>> GetRolesList(int id)
        {
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@UserID",id)
                };
                var connection = _IEHDbContext.GetDbConnection();
                List<UserRolesModel> result = new List<UserRolesModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetRolesList, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<UserRolesModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<UserRolesModel> DeleteUserRole(int id)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@RoleID",id),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                UserRolesModel result = new UserRolesModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.DeleteUserRole, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            _IEHDbContext.DataReaderMapToList<UserRolesModel>(reader).FirstOrDefault();
                            string message = (string)cmd.Parameters["@ReturnCode"].Value;
                            result.ReturnCode = message;
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<UserRolesModel> UpdateUserRole(UserRolesModel model)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@RoleID",model.RoleID),
                    new SqlParameter("@RoleName",model.RoleName),
                    new SqlParameter("@RoleDescription",model.RoleDescription),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                UserRolesModel result = new UserRolesModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.UpdateUserRole, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            _IEHDbContext.DataReaderMapToList<UserRolesModel>(reader).FirstOrDefault();
                            string message = (string)cmd.Parameters["@ReturnCode"].Value;
                            result.ReturnCode = message;
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<UserRolesModel> GetRoleById(int id)
        {
            try
            {

                SqlParameter[] param = {
                    new SqlParameter("@Id",id)
                };
                var connection = _IEHDbContext.GetDbConnection();
                UserRolesModel result = new UserRolesModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetRolesByID, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<UserRolesModel>(reader).FirstOrDefault();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<string> SaveUserRole(UserRolesModel model)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@RoleName",model.RoleName),
                    new SqlParameter("@UserID",model.UserID),
                    new SqlParameter("@RoleDescription",model.RoleDescription),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                string result = string.Empty;
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.SaveUserRole, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            _IEHDbContext.DataReaderMapToList<UserRolesModel>(reader).FirstOrDefault();

                            string message = (string)cmd.Parameters["@ReturnCode"].Value;
                            result = message;
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region Staff Service
        public async Task<List<StaffModel>> GetStaffInviteById(long id, bool? type)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@OrganizationID",id),
                    new SqlParameter("@InviteFlag",type),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                List<StaffModel> result = new List<StaffModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetStaffInvite, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<StaffModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<StaffDetailsVM> GetStaffDetails(GuidModel guidModel)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@AccountGUID",guidModel.Guid),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                StaffDetailsVM result = new StaffDetailsVM();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetStaffDetails, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<StaffDetailsVM>(reader).FirstOrDefault();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<StaffModel> ViewInviteStaffById(GuidModel guidModel)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@AccountInviteGuid",guidModel.Guid),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                StaffModel result = new StaffModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.ViewStaffInviteById, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<StaffModel>(reader).FirstOrDefault();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<StaffModel>> SearchStaff(StaffModel searchModel)
        {

            if (searchModel.StartDate == null)
            {
                searchModel.StartDate = DateTime.Now.AddYears(-70);
            }
            if (searchModel.EndDate == null)
            {
                searchModel.EndDate = DateTime.Now.AddYears(70);
            }
            try
            {
                SqlParameter[] param = { };
                if (searchModel.Type == "View")
                {
                    SqlParameter[] viewParam = {
                    new SqlParameter("@FirstName", searchModel.FirstName),
                    new SqlParameter("@LastName", searchModel.LastName),
                    new SqlParameter("@EmailAddress", searchModel.Email),
                    new SqlParameter("@StartDate", searchModel.StartDate),
                    new SqlParameter("@EndDate", searchModel.EndDate),
                    new SqlParameter("@IsActive", searchModel.IsActive),
                    new SqlParameter("@InviteAccept", true),
                    new SqlParameter("@organizationID", searchModel.OrganizationID),
                   // outParam
                };

                    param = viewParam;
                }
                else
                {

                    SqlParameter[] inviteParam = {
                    new SqlParameter("@FirstName", searchModel.FirstName),
                    new SqlParameter("@LastName", searchModel.LastName),
                    new SqlParameter("@EmailAddress", searchModel.Email),
                    new SqlParameter("@StartDate", searchModel.StartDate),
                    new SqlParameter("@EndDate", searchModel.EndDate),
                    new SqlParameter("@IsActive", searchModel.IsActive),
                    new SqlParameter("@InviteAccept", false),
                    new SqlParameter("@organizationID", searchModel.OrganizationID),
                   // outParam
                };
                    param = inviteParam;
                }

                var connection = _IEHDbContext.GetDbConnection();
                List<StaffModel> result = new List<StaffModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.SearchStaff, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<StaffModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<StaffModel> SaveInvite_Staff(StaffModel staffInviteModel)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                var TokenGuid = new SqlParameter("@AccountInviteToken", SqlDbType.UniqueIdentifier)
                {
                    Direction = ParameterDirection.Output
                };
                var orgTypeId = new SqlParameter("@OrganizationType", SqlDbType.BigInt)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@OrganizationsID",staffInviteModel.OrganizationID),
                    new SqlParameter("@FirstName",staffInviteModel.FirstName),
                    new SqlParameter("@LastName",staffInviteModel.LastName),
                    new SqlParameter("@EmailAddress",staffInviteModel.Email),
                    new SqlParameter("@IsStaff",staffInviteModel.IsStaff),
                    new SqlParameter("@DepartmentName",staffInviteModel.DepartmentName),
                    new SqlParameter("@InitialRoleId",staffInviteModel.InitialRoleId),
                    outParam,TokenGuid,orgTypeId
                    };
                var connection = _IEHDbContext.GetDbConnection();
                StaffModel result = new StaffModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.SaveInvite_Staff, param, cmd);
                        cmd.ExecuteNonQuery();
                        string message = (string)cmd.Parameters["@ReturnCode"].Value;
                        Guid InviteToken = (Guid)cmd.Parameters["@AccountInviteToken"].Value;
                        result.AccountInviteToken = InviteToken;
                        result.OrganizationTypeID = (long)cmd.Parameters["@OrganizationType"].Value;
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }




        }

        public async Task<StaffModel> DeleteStaff(GuidModel guidModel)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@AccountGUID",guidModel.Guid),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                StaffModel result = new StaffModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.DeleteStaff, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<StaffModel>(reader).FirstOrDefault();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<StaffModel> UpdateInvite_Staff(StaffModel staffInviteModel)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                //var TokenGuid = new SqlParameter("@AccountInviteToken", SqlDbType.UniqueIdentifier)
                //{
                //    Direction = ParameterDirection.Output
                //};
                //var email = new SqlParameter("@ReturnEmailAddress", SqlDbType.NVarChar, 500)
                //{
                //    Direction = ParameterDirection.Output
                //};
                SqlParameter[] param = {
                    new SqlParameter("@AccountInviteGuid",staffInviteModel.StaffGuid),
                    new SqlParameter("@FirstName",staffInviteModel.FirstName),
                    new SqlParameter("@LastName",staffInviteModel.LastName),
                    new SqlParameter("@RoleID",staffInviteModel.InitialRoleId),
                    new SqlParameter("@DepartmentName",staffInviteModel.DepartmentName),
                    outParam
                   // new SqlParameter("@EmailAddress",staffInviteModel.Email),
                    //new SqlParameter("@InviteDate",staffInviteModel.InviteDate),
                    //outParam,TokenGuid,email
                };
                var connection = _IEHDbContext.GetDbConnection();
                StaffModel result = new StaffModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {

                        _IEHDbContext.AddParametersToDbCommand(SpConstants.UpdateInvite_Staff, param, cmd);
                        cmd.ExecuteNonQuery();
                        string message = (string)cmd.Parameters["@ReturnCode"].Value;
                        //  Guid InviteToken = (Guid)cmd.Parameters["@AccountInviteToken"].Value;
                        // string returnEmail = (string)cmd.Parameters["@ReturnEmailAddress"].Value;
                        // result.AccountInviteToken = InviteToken;
                        // result.ReturnEmailAddress = returnEmail;

                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<StaffModel> GetStaffInvite(GuidModel guidModel)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@AccountGUID",guidModel.Guid),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                StaffModel result = new StaffModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetStaffAdminInvite, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<StaffModel>(reader).FirstOrDefault();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ResponseModel> UpdateStaffDetails(StaffDetailsModel staffDetailsModel)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@FirstName",staffDetailsModel.FirstName),
                    new SqlParameter("@LastName",staffDetailsModel.LastName),
                    new SqlParameter("@MiddleName",staffDetailsModel.MiddleName),
                    new SqlParameter("@Email",staffDetailsModel.Email),
                    new SqlParameter("@MaidenName",staffDetailsModel.MaidenName),
                    new SqlParameter("@OtherName",staffDetailsModel.OtherName),
                    new SqlParameter("@GenderId",staffDetailsModel.GenderId),
                    new SqlParameter("@MaritalStatusId",staffDetailsModel.MaritalStatusId),
                    new SqlParameter("@Age",staffDetailsModel.Age),
                    new SqlParameter("@NativeSpokenLanguage",staffDetailsModel.NativeSpokenLanguage),
                    new SqlParameter("@DOB",staffDetailsModel.DOB),
                    new SqlParameter("@PrimaryContactNumber",staffDetailsModel.PrimaryContactNumber),
                    new SqlParameter("@SecondaryContactNumber",staffDetailsModel.SecondaryContactNumber),
                    new SqlParameter("@CountryID",staffDetailsModel.CountryID),
                    new SqlParameter("@StateName",staffDetailsModel.StateName),
                    new SqlParameter("@UserID",staffDetailsModel.UserID),
                    new SqlParameter("@SponsorID",staffDetailsModel.UserID),
                    new SqlParameter("@AccountID",staffDetailsModel.StaffGuid),
                    new SqlParameter("@ProfilePicture",staffDetailsModel.ProfilePicture),
                    outParam
                    };
                var connection = _IEHDbContext.GetDbConnection();
                ResponseModel result = new ResponseModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.UpdateStaffDetails, param, cmd);
                        cmd.ExecuteNonQuery();
                        result.ReturnCode = (string)cmd.Parameters["@ReturnCode"].Value;
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ResponseModel> ActiveInactiveStaff(GuidModel guidModel)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                    new SqlParameter("@Id",guidModel.Guid),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                ResponseModel result = new ResponseModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.ActiveInactiveStaff, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            _IEHDbContext.DataReaderMapToList<ResponseModel>(reader).FirstOrDefault();
                            result.ReturnCode = (string)cmd.Parameters["@ReturnCode"].Value;
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        //For Sendig email templates

        public async Task<MasterEmailTemplateModel> GetEmailTemplate(string code)
        {
            try
            {
                SqlParameter[] param = {
                    new SqlParameter("@Code",code)
                };
                var connection = _IEHDbContext.GetDbConnection();
                MasterEmailTemplateModel result = new MasterEmailTemplateModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.EmailTemplate, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<MasterEmailTemplateModel>(reader).FirstOrDefault();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<string> SaveUrlAdminInvitetable(Guid tokenGuid, string encripURL)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };

                var userId = new SqlParameter("@UserId", SqlDbType.BigInt, 20)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@TokenGUID",tokenGuid),
                    new SqlParameter("@URL",encripURL),

                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                string result = string.Empty;
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {

                        _IEHDbContext.AddParametersToDbCommand(SpConstants.AdminInviteUrlSave, param, cmd);
                        cmd.ExecuteNonQuery();
                        result = (string)cmd.Parameters["@ReturnCode"].Value;
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<AdminInviteModel> AcceptInvite(AcceptInviteModel model)
        {
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };

                SqlParameter[] param = {
                    new SqlParameter("@AcceptenceToken",model.token),
                    new SqlParameter("@Password",model.password),
                    new SqlParameter("@UserName",model.username),
                    outParam
                };
                var connection = _IEHDbContext.GetDbConnection();
                AdminInviteModel result = new AdminInviteModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {

                        _IEHDbContext.AddParametersToDbCommand(SpConstants.AcceptInvite, param, cmd);
                        cmd.ExecuteNonQuery();
                        string message = (string)cmd.Parameters["@ReturnCode"].Value;
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region Study
        public async Task<ResponseModel> AddStudyInsertion(StudyInsertionModel Studies)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                //CSDetailsModels


                //convert list to datatable
                DataTable dtSearchKeyword = Studies.CSSearchKeywordModels.ToDataTable<CSSearchKeywordModel>();
                DataTable dtOutcomeMeasures = Studies.CSOutcomeMeasures.ToDataTable<CSOutcomeMeasures>();
                DataTable dtLocationModel = Studies.CSLocationModel.ToDataTable<CSLocationModel>();
                DataTable dtCriteriaModel = Studies.CSCriteriaModel.ToDataTable<CSCriteriaModel>();
                DataTable dtContactModel = Studies.CSContactModel.ToDataTable<CSContactModel>();
                DataTable dtConditionOrDisease = Studies.CSConditionOrDiseaseModel.ToDataTable<CSConditionOrDiseaseModel>();
                DataTable dtArmsInterventionsModel = Studies.CSArmsInterventionsModel.ToDataTable<CSArmsInterventionsModel>();
                DataTable dtPhase = Studies.CSPhaseModel.ToDataTable<CSPhaseModel>();
                DataTable dtInterventionOrTreatment = Studies.CSInterventionOrTreatmentModel.ToDataTable<CSInterventionOrTreatmentModel>();
                SqlParameter[] param = {
                    new SqlParameter("@CSCode",Studies.CSDetailsModels.CSCode),
                    new SqlParameter("@CSTitle", Studies.CSDetailsModels.CSTitle),
                    new SqlParameter("@CSShortDescription", Studies.CSDetailsModels.CSShortDescription),
                    new SqlParameter("@CSInformationProvider", Studies.CSDetailsModels.CSInformationProvider),
                    new SqlParameter("@CSDescription", Studies.CSDetailsModels.CSDescription),
                    new SqlParameter("@CSStudyType", Studies.CSDetailsModels.CSStudyType),
                    new SqlParameter("@CSActualEnrollment", Studies.CSDetailsModels.CSActualEnrollment),
                    new SqlParameter("@CSAllocation", Studies.CSDetailsModels.CSAllocation),
                    new SqlParameter("@CSInterventionMode", Studies.CSDetailsModels.CSInterventionMode),
                    new SqlParameter("@CSMasking", Studies.CSDetailsModels.CSMasking),
                    new SqlParameter("@CSPrimaryPurpose", Studies.CSDetailsModels.CSPrimaryPurpose),
                    new SqlParameter("@CSOfficialTitle", Studies.CSDetailsModels.CSOfficialTitle),
                    new SqlParameter("@CSActualStartDate", Studies.CSDetailsModels.CSActualStartDate),
                    new SqlParameter("@CSEstPrimaryCompletionDate", Studies.CSDetailsModels.CSEstPrimaryCompletionDate),
                    new SqlParameter("@CSEstStudyCompletionDate", Studies.CSDetailsModels.CSEstStudyCompletionDate),
                    new SqlParameter("@CSAgesEligible", Studies.CSDetailsModels.CSAgesEligible),
                    new SqlParameter("@CSAgesEligibleMoreOrLess", Studies.CSDetailsModels.CSAgesEligibleMoreOrLess),
                    new SqlParameter("@CSSexesEligible", Studies.CSDetailsModels.CSSexesEligible),
                    new SqlParameter("@CSAcceptsHealthyVolunteers", Studies.CSDetailsModels.CSAcceptsHealthyVolunteers),
                    new SqlParameter("@CSIsVerrified", Studies.CSDetailsModels.CSIsVerrified),
                    new SqlParameter("@CSIsVerrifiedBy", Studies.CSDetailsModels.CSIsVerrifiedBy),
                    new SqlParameter("@CSIPDStatement", Studies.CSDetailsModels.CSIPDStatement),
                    new SqlParameter("@ShareIPD", Studies.CSDetailsModels.ShareIPD),
                    new SqlParameter("@CSFDADrugProduct", Studies.CSDetailsModels.CSFDADrugProduct),
                    new SqlParameter("@CSFDADeviceProduct", Studies.CSDetailsModels.CSFDADeviceProduct),
                    new SqlParameter("@CSProductUSA", Studies.CSDetailsModels.CSProductUSA),
                    new SqlParameter("@Keywordsprovidedby", Studies.CSDetailsModels.Keywordsprovidedby),
                    new SqlParameter("@SponserID", Studies.CSDetailsModels.SponserID),
                    new SqlParameter("@IsActive", Studies.CSDetailsModels.IsActive),
                    new SqlParameter("@IsPublish", Studies.CSDetailsModels.IsPublish),
                    new SqlParameter("@IsDeleted", Studies.CSDetailsModels.IsDeleted),
                    //Table Type Parameter
                   new SqlParameter("@CsSearchKeyword",dtSearchKeyword),
                   new SqlParameter("@CsOutcomeMeasures",dtOutcomeMeasures),
                   new SqlParameter("@CSLocation",dtLocationModel),
                   new SqlParameter("@CSCriteria",dtCriteriaModel),
                   new SqlParameter("@CSContact",dtContactModel),
                   new SqlParameter("@CSConditionOrDisease",dtConditionOrDisease),
                   new SqlParameter("@CSArmsInterventions",dtArmsInterventionsModel),
                   new SqlParameter("@CSPhase",dtPhase),
                   new SqlParameter("@CSInterventionOrTreatment",dtInterventionOrTreatment),
                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.AddStudyInvention, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.ServerErrorCode;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> DeleteStudyByCSGuid(GuidModel guidModel)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                //CSDetailsModels


                //convert list to datatable

                SqlParameter[] param = {
                    new SqlParameter("@CSGuiD",guidModel.Guid),
                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.DeleteStudy, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.RecordNotFound;
                    //response.ReturnCode = null;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<List<CSDetailsModel>> GetCSDetailList()
        {
            try
            {
                SqlParameter[] param = { };
                var connection = _IEHDbContext.GetDbConnection();
                List<CSDetailsModel> result = new List<CSDetailsModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GETStudyList, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<CSDetailsModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<StudyInsertionModel> GetStudyInsertionByCSGuid(GuidModel guidModel)
        {
            try
            {
                //SqlParameter[] param = { };
                var connection = _IEHDbContext.GetDbConnection();
                StudyInsertionModel result = new StudyInsertionModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    SqlParameter[] param = {
                    new SqlParameter("@CSGuiD",guidModel.Guid)
                };
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GETStudyByCSGuID, param, cmd);
                        DataSet ds = new DataSet();

                        using (var da = new SqlDataAdapter(cmd as SqlCommand))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            da.Fill(ds);
                        }
                        result.CSSearchKeywordModels = ds.Tables[0].ConvertDataTable<CSSearchKeywordModel>();
                        result.CSPhaseModel = ds.Tables[1].ConvertDataTable<CSPhaseModel>();
                        result.CSLocationModel = ds.Tables[2].ConvertDataTable<CSLocationModel>();
                        result.CSOutcomeMeasures = ds.Tables[3].ConvertDataTable<CSOutcomeMeasures>();
                        result.CSConditionOrDiseaseModel = ds.Tables[4].ConvertDataTable<CSConditionOrDiseaseModel>();
                        result.CSArmsInterventionsModel = ds.Tables[5].ConvertDataTable<CSArmsInterventionsModel>();
                        result.CSCriteriaModel = ds.Tables[6].ConvertDataTable<CSCriteriaModel>();
                        result.CSContactModel = ds.Tables[7].ConvertDataTable<CSContactModel>();
                        result.CSInterventionOrTreatmentModel = ds.Tables[8].ConvertDataTable<CSInterventionOrTreatmentModel>();
                        result.CSDetailsModels = ds.Tables[9].ConvertDataTable<CSDetailsModel>().FirstOrDefault();
                        //CSDetailsModel
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ResponseModel> UpdateStudyInsertion(StudyInsertionModel Studies, Guid csGuid)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                //CSDetailsModels


                //convert list to datatable
                DataTable dtSearchKeyword = Studies.CSSearchKeywordModels.ToDataTable<CSSearchKeywordModel>();
                DataTable dtOutcomeMeasures = Studies.CSOutcomeMeasures.ToDataTable<CSOutcomeMeasures>();
                DataTable dtLocationModel = Studies.CSLocationModel.ToDataTable<CSLocationModel>();
                DataTable dtCriteriaModel = Studies.CSCriteriaModel.ToDataTable<CSCriteriaModel>();
                DataTable dtContactModel = Studies.CSContactModel.ToDataTable<CSContactModel>();
                DataTable dtConditionOrDisease = Studies.CSConditionOrDiseaseModel.ToDataTable<CSConditionOrDiseaseModel>();
                DataTable dtArmsInterventionsModel = Studies.CSArmsInterventionsModel.ToDataTable<CSArmsInterventionsModel>();
                DataTable dtPhase = Studies.CSPhaseModel.ToDataTable<CSPhaseModel>();
                DataTable dtInterventionOrTreatment = Studies.CSInterventionOrTreatmentModel.ToDataTable<CSInterventionOrTreatmentModel>();
                SqlParameter[] param = {
                    new SqlParameter("@CSCode",Studies.CSDetailsModels.CSCode),
                    new SqlParameter("@CSTitle", Studies.CSDetailsModels.CSTitle),
                    new SqlParameter("@CSShortDescription", Studies.CSDetailsModels.CSShortDescription),
                    new SqlParameter("@CSInformationProvider", Studies.CSDetailsModels.CSInformationProvider),
                    new SqlParameter("@CSDescription", Studies.CSDetailsModels.CSDescription),
                    new SqlParameter("@CSStudyType", Studies.CSDetailsModels.CSStudyType),
                    new SqlParameter("@CSActualEnrollment", Studies.CSDetailsModels.CSActualEnrollment),
                    new SqlParameter("@CSAllocation", Studies.CSDetailsModels.CSAllocation),
                    new SqlParameter("@CSInterventionMode", Studies.CSDetailsModels.CSInterventionMode),
                    new SqlParameter("@CSMasking", Studies.CSDetailsModels.CSMasking),
                    new SqlParameter("@CSPrimaryPurpose", Studies.CSDetailsModels.CSPrimaryPurpose),
                    new SqlParameter("@CSOfficialTitle", Studies.CSDetailsModels.CSOfficialTitle),
                    new SqlParameter("@CSActualStartDate", Studies.CSDetailsModels.CSActualStartDate),
                    new SqlParameter("@CSEstPrimaryCompletionDate", Studies.CSDetailsModels.CSEstPrimaryCompletionDate),
                    new SqlParameter("@CSEstStudyCompletionDate", Studies.CSDetailsModels.CSEstStudyCompletionDate),
                    new SqlParameter("@CSAgesEligible", Studies.CSDetailsModels.CSAgesEligible),
                    new SqlParameter("@CSAgesEligibleMoreOrLess", Studies.CSDetailsModels.CSAgesEligibleMoreOrLess),
                    new SqlParameter("@CSSexesEligible", Studies.CSDetailsModels.CSSexesEligible),
                    new SqlParameter("@CSAcceptsHealthyVolunteers", Studies.CSDetailsModels.CSAcceptsHealthyVolunteers),
                    new SqlParameter("@CSIsVerrified", Studies.CSDetailsModels.CSIsVerrified),
                    new SqlParameter("@CSIsVerrifiedBy", Studies.CSDetailsModels.CSIsVerrifiedBy),
                    new SqlParameter("@CSIPDStatement", Studies.CSDetailsModels.CSIPDStatement),
                    new SqlParameter("@ShareIPD", Studies.CSDetailsModels.ShareIPD),
                    new SqlParameter("@CSFDADrugProduct", Studies.CSDetailsModels.CSFDADrugProduct),
                    new SqlParameter("@CSFDADeviceProduct", Studies.CSDetailsModels.CSFDADeviceProduct),
                    new SqlParameter("@CSProductUSA", Studies.CSDetailsModels.CSProductUSA),
                    new SqlParameter("@Keywordsprovidedby", Studies.CSDetailsModels.Keywordsprovidedby),
                    new SqlParameter("@SponserID", Studies.CSDetailsModels.SponserID),
                    new SqlParameter("@IsActive", Studies.CSDetailsModels.IsActive),
                    new SqlParameter("@IsPublish", Studies.CSDetailsModels.IsPublish),
                    new SqlParameter("@IsDeleted", Studies.CSDetailsModels.IsDeleted),
                    new SqlParameter("@CSGuiD",csGuid),
                    //Table Type Parameter
                   new SqlParameter("@CsSearchKeyword",dtSearchKeyword),
                   new SqlParameter("@CsOutcomeMeasures",dtOutcomeMeasures),
                   new SqlParameter("@CSLocation",dtLocationModel),
                   new SqlParameter("@CSCriteria",dtCriteriaModel),
                   new SqlParameter("@CSContact",dtContactModel),
                   new SqlParameter("@CSConditionOrDisease",dtConditionOrDisease),
                   new SqlParameter("@CSArmsInterventions",dtArmsInterventionsModel),
                   new SqlParameter("@CSPhase",dtPhase),
                   new SqlParameter("@CSInterventionOrTreatment",dtInterventionOrTreatment),

                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.UpdateStudyInvention, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.ServerErrorCode;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<List<CSDetailsModel>> SearchStudies(CSDetailsModel searchModel)
        {
            try
            {

                SqlParameter[] param = {
                    new SqlParameter("@IsActive", searchModel.IsActive),
                    new SqlParameter("@CSTitle", searchModel.CSTitle == null ? " " : searchModel.CSTitle),
                    new SqlParameter("@CSLocation", searchModel.CSLocationName == null ? " " : searchModel.CSLocationName),
                    new SqlParameter("@csConditionOrDiseaseText", searchModel.CSConditionOrDiseaseText == null ? " " : searchModel.CSConditionOrDiseaseText),
                    //new SqlParameter("@CSInformationProvider", searchModel.CSInformationProvider),
                    //new SqlParameter("@CSDescription", searchModel.CSDescription),
                    //new SqlParameter("@CSStudyType", searchModel.CSStudyType),
                    //new SqlParameter("@CSActualEnrollment", searchModel.CSActualEnrollment),
                    //new SqlParameter("@CSAllocation", searchModel.CSAllocation),

                    //new SqlParameter("@CSInterventionMode", searchModel.CSInterventionMode),
                    //new SqlParameter("@CSMasking", searchModel.CSMasking),
                    //new SqlParameter("@CSPrimaryPurpose", searchModel.CSPrimaryPurpose),
                    //new SqlParameter("@CSOfficialTitle", searchModel.CSOfficialTitle),
                    //new SqlParameter("@CSActualStartDate", searchModel.CSActualStartDate == null ? " " : searchModel.CSActualStartDate),
                    //new SqlParameter("@CSEstPrimaryCompletionDate", searchModel.CSEstPrimaryCompletionDate),
                    //new SqlParameter("@CSEstStudyCompletionDate", searchModel.CSEstStudyCompletionDate),
                    //new SqlParameter("@CSAgesEligible", searchModel.CSAgesEligible),
                    //new SqlParameter("@CSAgesEligibleMoreOrLess", searchModel.CSAgesEligibleMoreOrLess),
                    //new SqlParameter("@CSSexesEligible", searchModel.CSSexesEligible),
                    //new SqlParameter("@CSAcceptsHealthyVolunteers", searchModel.CSAcceptsHealthyVolunteers),
                    //new SqlParameter("@CSIsVerrified", searchModel.CSIsVerrifiedBy),
                    //new SqlParameter("@CSIsVerrifiedBy", searchModel.CSIsVerrifiedBy),
                    //new SqlParameter("@CSIPDStatement", searchModel.CSIPDStatement),
                    //new SqlParameter("@ShareIPD", searchModel.ShareIPD),
                    //new SqlParameter("@CSFDADrugProduct", searchModel.CSFDADeviceProduct),
                    //new SqlParameter("@CSFDADeviceProduct", searchModel.CSFDADeviceProduct),
                    //new SqlParameter("@CSProductUSA", searchModel.CSProductUSA),
                    //new SqlParameter("@Keywordsprovidedby", searchModel.Keywordsprovidedby),
                    //new SqlParameter("@SponserID", searchModel.SponserID)

                };
                var connection = _IEHDbContext.GetDbConnection();
                List<CSDetailsModel> result = new List<CSDetailsModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.SearchStudies, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<CSDetailsModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ResponseModel> ActiveInactiveStudyByCSGuid(GuidModel guidModel)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                //CSDetailsModels


                //convert list to datatable

                SqlParameter[] param = {
                    new SqlParameter("@CSGuiD",guidModel.Guid),
                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.ActiveInactiveStudy, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.RecordNotFound;
                    //response.ReturnCode = null;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        #endregion

        #region Inventory
        public async Task<CSInventoryModelWithGuid> GetDetails(GuidModel guidModel)
        {
            try
            {
                SqlParameter[] param = {
                  new SqlParameter("@Id",guidModel.Guid),
                };
                var connection = _IEHDbContext.GetDbConnection();
                CSInventoryModelWithGuid result = new CSInventoryModelWithGuid();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetInventoryRecord, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<CSInventoryModelWithGuid>(reader).FirstOrDefault();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ResponseModel> DeleteInventory(GuidModel guidModel)
        {
            try
            {
                SqlParameter[] param = {
                  new SqlParameter("@Id",guidModel.Guid),
                };
                var connection = _IEHDbContext.GetDbConnection();
                ResponseModel result = new ResponseModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.DeleteInventory, param, cmd);
                        cmd.ExecuteNonQuery();
                        result.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        result.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<CodesModelData>> GetCodeList(int type)
        {
            try
            {
                var outParamID = new SqlParameter("@CodeType", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                  new SqlParameter("@Type",type),outParamID
                };

                var connection = _IEHDbContext.GetDbConnection();
                List<CodesModelData> result = new List<CodesModelData>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetStudyCodeList, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {

                            result = _IEHDbContext.DataReaderMapToList<CodesModelData>(reader).ToList();
                            reader.NextResult();
                        }
                    }

                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<StudyInventoryModel> SearchInventory(SearchModelInventory searchModel)
        {
            try
            {
                SqlParameter[] param = {
                  new SqlParameter("@Search",searchModel.Search),
                  new SqlParameter("@CSGuiD",searchModel.Guid)
                };

                var connection = _IEHDbContext.GetDbConnection();
                StudyInventoryModel result = new StudyInventoryModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.SearchInventory, param, cmd);
                        DataSet ds = new DataSet();

                        using (var da = new SqlDataAdapter(cmd as SqlCommand))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            da.Fill(ds);
                        }
                        result.CSInventoryModels = ds.Tables[0].ConvertDataTable<CSInventoryModel>();
                    }

                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ResponseModel> AddStudyInventory(StudyInventoryModel inventoryModel)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };

                //convert list to datatable
                DataTable dtInventory = inventoryModel.CSInventoryModels.ToDataTable<CSInventoryModel>();

                SqlParameter[] param = {
                    new SqlParameter("@CSGuiD", inventoryModel.CSGuid),   
                    //Table Type Parameter
                   new SqlParameter("@CsInventory",dtInventory),
                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.AddStudyInventory, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.ServerErrorCode;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> UpdateStudyInventory(CSInventoryModel inventoryModel)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };

                //convert list to datatable
                // DataTable dtInventory = inventoryModel.CSInventoryModels.ToDataTable<CSInventoryModel>();

                SqlParameter[] param = {
                    new SqlParameter("@CSInventoryGuiD", inventoryModel.CSInventoryGuiD),
                    new SqlParameter("@InventoryType", inventoryModel.InventoryType),
                    new SqlParameter("@InventoryName", inventoryModel.InventoryName),
                    new SqlParameter("@InventoryCode", inventoryModel.InventoryCode),
                    new SqlParameter("@InventoryAvaiableQuantity", inventoryModel.InventoryAvailableQuantity),
                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.UpdateStudyInventory, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.ServerErrorCode;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<StudyInventoryModel> GetStudyInventoryByCSGuid(GuidModel guidModel)
        {
            try
            {
                //SqlParameter[] param = { };
                var connection = _IEHDbContext.GetDbConnection();
                StudyInventoryModel result = new StudyInventoryModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    SqlParameter[] param = {
                    new SqlParameter("@CSGuiD",guidModel.Guid)
                };
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetStudyInventoryByCSGuID, param, cmd);
                        DataSet ds = new DataSet();

                        using (var da = new SqlDataAdapter(cmd as SqlCommand))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            da.Fill(ds);
                        }
                        result.CSInventoryModels = ds.Tables[0].ConvertDataTable<CSInventoryModel>();
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
    }
}

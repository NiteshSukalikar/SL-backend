﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model
{
    public class MailconfigModel
    {
        public string FROM { get; set; }
        public string FROMNAME { get; set; }
        public string SMTP_USERNAME { get; set; }
        public string SMTP_PASSWORD { get; set; }
        public string HOST { get; set; }
        public int PORT { get; set; }
    }
}

﻿

namespace Shared.Enum
{
    public enum AuditLogMaster
    {
        API = 1
    }
}

﻿namespace Shared.Enum
{
    public enum ActiveStatusEnum
    {
        Active = 1,
        Inactive = 2,
        Delete = 3,
    }
}

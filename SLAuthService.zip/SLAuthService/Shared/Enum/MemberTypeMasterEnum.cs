﻿

namespace Shared.Enum
{
    public enum MemberTypeMasterEnum
    {
        User = 1,
        Member = 2,
        Superadmin = 3,
    }
}

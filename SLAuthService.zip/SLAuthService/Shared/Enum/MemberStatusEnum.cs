﻿

namespace Shared.Enum
{
    public enum MemberStatusEnum
    {
        Onboard = 1,
        Active = 2,
        CaseOpen = 3,
        Inactive = 4
    }
}

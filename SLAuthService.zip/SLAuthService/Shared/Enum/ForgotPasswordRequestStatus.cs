﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Enum
{
    public enum ForgotPasswordRequestStatus
    {
        Changed = 1,
        NotChanged = 2,
        InProcess = 3,
    }
}

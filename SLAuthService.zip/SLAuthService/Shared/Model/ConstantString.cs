﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IEH_Shared.Model
{
    public class ConstantString
    {
        public static class ImagesPath
        {

            public const string OrgLogo = "//wwwroot//Images//organizationLogo//";
        }
    }
}

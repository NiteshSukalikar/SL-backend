﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLAuthService.Utility
{
    public class GetConnString
    {
        public static   string getString()
        {
            return "";
        }
    }
}

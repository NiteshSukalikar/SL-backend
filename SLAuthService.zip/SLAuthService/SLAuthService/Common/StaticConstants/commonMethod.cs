﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLAuthService.Common.StaticConstants
{
    public static class commonMethod
    {
        public static Dictionary<string, string> GlobalVariable { get; set; }

        public static void AddObjectToDictionary(string DomainConString)
        {
            GlobalVariable = new Dictionary<string, string>();
            GlobalVariable.Add("DomainConString", DomainConString);
        }
    }
}

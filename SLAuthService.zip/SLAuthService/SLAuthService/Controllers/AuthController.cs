﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using AuthService.Model;
using AuthService.Services.Interfaces;
using AuthService.Utility;
using AuthService.Common.ResponseVM;
using Microsoft.Extensions.Logging;
using Shared.Helper;
using SLAuthService.Model;
using System.Collections.Generic;

namespace IEH_Auth.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        /// <summary>
        /// Defines the _authService
        /// </summary>
        private readonly IAuthService _authService;
        private readonly ILogger<AuthController> _logger;
        private readonly CommonMethods _commonMethods;
        private IHttpContextAccessor _accessor;

        /// <summary>
        /// Defines the applicationsettings
        /// </summary>
        private readonly IOptions<ApplicationSettings> applicationsettings;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthController"/> class.
        /// </summary>
        /// <param name="authService">The authService<see cref="IAuthService"/></param>
        public AuthController(IAuthService authService, IOptions<ApplicationSettings> application, IHttpContextAccessor accessor, ILogger<AuthController> logger)
        {
            _authService = authService;
            _logger = logger;
            applicationsettings = application;
            _commonMethods = new CommonMethods();
            _accessor = accessor;
        }

        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login([FromBody] LoginModel loginVM)
        {
            ResponseVM result = new ResponseVM();
            result.Code = "205";
            GeoData geoData = new GeoData();
            geoData = GetIp();
            loginVM.ipAddress = geoData.Ip;
            loginVM.Country = geoData.Country;
            result = await _authService.Login(loginVM);
            return Ok(result);
        }

        [HttpPost]
        [Route("resendOTP")]
        public async Task<IActionResult> resendOTP([FromBody] resendOTPModel resendOTPModel)
        {
            ResponseVM result = new ResponseVM();
            result.Code = "205";           
            result = await _authService.resendOTP(resendOTPModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("LoginOTPVerification")]
        public async Task<IActionResult> LoginOTPVerification([FromBody] OTPModel model)
        {
            GeoData geodata = new GeoData();
            geodata = GetIp();
            model.ipAddr = geodata.Ip;
            model.Country = geodata.Country;
            ResponseVM result = await _authService.LoginOTPVerification(model);
            return Ok(result);
        }

                
        [HttpPost]
        [AllowAnonymous]
        [Route("forgotPassword")]
        public async Task<IActionResult> forgotPassword([FromBody] ForgotPassword forgotPassword)
        {
            ResponseVM result = await _authService.forgotPassword(forgotPassword);
            return Ok(result);
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("forgotPasswordExpired")]
        public async Task<IActionResult> forgotPasswordExpired([FromBody] PasswordToken passwordToken)
        {
            ResponseVM result = await _authService.forgotPasswordExpired(passwordToken);
            return Ok(result);
        }

        [HttpPost]
        [Route("verfyOtpForgotPassword")]
        public async Task<IActionResult> verfyOtpForgotPassword([FromBody] OTPModel otp)
        {
            ResponseVM result = await _authService.verfyOtpForgotPassword(otp);
            return Ok(result);
        }

        [HttpPost]
        [Route("resetPasswordForgot")]
        public async Task<IActionResult> resetPasswordForgot([FromBody] ResetPassword resetPassword)
        {
            ResponseVM result = await _authService.resetPasswordForgot(resetPassword);
            return Ok(result);
        }

        [NonAction]
        public Shared.Model.TokenClaimsModal GetUserByClaim()
        {
            HttpContext httpContext = HttpContext.Request.HttpContext;
            var claims = _commonMethods.GetUserClaimsFromToken(httpContext);
            return claims;
        }

        [HttpPost]
        [Authorize]
        [Route("ChangePassword")]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePassword password)
        {
            ResponseVM result = await _authService.ChangePassword(password, GetUserByClaim());
            return Ok(result);
        }

        [HttpPost]
        [Route("Logout")]
        public string Logout([FromBody] LogoutModel model)
        {
            string result = _authService.Logout(model);
            return result;
        }

        [NonAction]
        public GeoData GetIp()
        {
            HttpContext httpContext = HttpContext.Request.HttpContext;
            GeoData geoData = new GeoData();
            geoData.Ip = httpContext.Request.Headers["Ip-Address"];
            geoData.Country = httpContext.Request.Headers["Country"];
            return geoData;
        }
        [HttpGet]
        [Route("GetDomainList")]
        public async Task<IActionResult> GetDomainList()
        {
            ResponseVM result = _authService.GetDomainList();
            return Ok(result);
         
        }
    }
}

﻿namespace AuthService.Services.Interfaces
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AuthService.Common.ResponseVM;
    using AuthService.Model;
    using AuthService.Utility;
    using SLAuthService.Model;

    /// <summary>
    /// Defines the <see cref="IUserService" />
    /// </summary>
    public interface IAuthService
    {
        Task<UserDetails> GetUserDetailsByEmail(string email);
        Task<UserDetails> GetUserDetailsById(string userId);
        Task<ResponseVM> Login(LoginModel loginVM);
        Task<ResponseVM> resendOTP(resendOTPModel resendOTPModel);
        Task<ResponseVM> LoginOTPVerification(OTPModel model);
        Task<ResponseVM> forgotPassword(ForgotPassword forgotPassword);
        Task<ResponseVM> forgotPasswordExpired(PasswordToken passwordToken);
        Task<ResponseVM> verfyOtpForgotPassword(OTPModel otp);
        Task<ResponseVM> resetPasswordForgot(ResetPassword resetPassword);
        Task<ResponseVM> ChangePassword(ChangePassword password, Shared.Model.TokenClaimsModal claims);
        string Logout(LogoutModel model);
        string generateRandomOTP();
        Task<VerificationResult> StartVerificationAsync(string phoneNumber, string channel, string email, string firstname, string lastanme, string? forgotPasswordUrl);
        Task<VerificationResult> CheckVerificationAsync(string phoneNumber, string code, string email, string otpVia, string? pinId);
        ResponseVM GetDomainList();
    }
}


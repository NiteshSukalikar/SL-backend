﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLAuthService.Model
{
    public class DomainModel
    {
        public long DomainId { get; set; }
        public string DomainName { get; set; }
    }
}

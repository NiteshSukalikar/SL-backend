﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLAuthService.Model
{
    public class OrganizationList
    {
        public string Id { get; set; }
        public string Organization { get; set; }
    }
}

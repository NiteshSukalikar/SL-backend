﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthService.Model
{
    public class ProviderListFilter
    {
        public string StateId { get; set; }
        //public string CityId { get; set; }
    }
}

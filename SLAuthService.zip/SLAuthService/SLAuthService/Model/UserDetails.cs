﻿namespace AuthService.Model
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Runtime.Serialization;

    /// <summary>
    /// Defines the <see cref="UserDetails" />
    /// </summary>
    [DataContract]
    public class UserDetails 
    {

        public long UserId { get; set; }
        public string EmailAddress { get; set; }
        public string UserName { get; set; }
        public string UserPassword { get; set; }
        public long OrganizationID { get; set; }
        public string ContactNumber { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }  
        public bool? IsStaff { get; set; }
        public Guid? AccountId { get; set; }
        public long? DomainRoleID { get; set; }
        public string Id { get; set; }
        public bool Active { get; set; }
        public bool isActivated { get; set; }
        public string  ActivationCode{ get; set; }
        public long SSN { get; set; }
        public DateTime? Dob{ get; set; }
        public string DobEncrypted { get; set; }
        public bool Status { get; set; }
        public string Mrn { get; set; }      
        public byte[]? _contactNumber { get; set; }
        public int RoleId { get; set; }
        public int? UserType { get; set; }
        public bool OTPRequired { get; set; }
        public string ResponseResult { get; set; }
        public string? ProfilePicture { get; set; }
        public string? LogoName { get; set; }

    }
}

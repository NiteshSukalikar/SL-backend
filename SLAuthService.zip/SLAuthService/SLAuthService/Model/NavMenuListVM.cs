﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLAuthService.Model
{
    public class NavMenuListVM
    {
        public List<NavMenuList> navMenuList { get; set; }
        public List<SideMenu> sideMenu { get; set; }
    }
    public class NavMenuList
    {
        //public long NavMenuActionID { get; set; }
        public string NavName { get; set; }
        public string ActionName { get; set; }
    }
    public class SideMenu
    {
        
        public long UISideMenuID { get; set; }
        public long? ParentSideMenuID { get; set; }
        public string Header { get; set; }
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public int? Order { get; set; }
        public string ActionName { get; set; }
        public bool HasAccess { get; set; }
        public bool IsShow { get; set; }

    }
    public class SideMenu_
    {
        //public SideMenu_(List<SideMenu_> _InnersideMenu)
        //{
        //    InnersideMenu = _InnersideMenu;
        //}
        public long UISideMenuID { get; set; }
        public long? ParentSideMenuID { get; set; }
        public string Header { get; set; }
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public int? Order { get; set; }
        public string ActionName { get; set; }
        public bool HasAccess { get; set; }
        public List<SideMenu_> SubModules { get; set; }
    }


    public class NavListDecoration
    {
        public long SideMenuID { get; set; }
        public string moduleName { get; set; }
        public string Header { get; set; }   
        public string Navigationlink { get; set; }
        public string ClassStyle { get; set; }
        public bool IsShow { get; set; }
        public List<Permission> permissions { get; set; }
        public List<NavListDecoration> SubModules { get; set; }

    }
    public class Permission
    {
        public string label { get; set; }

        public bool value { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Models
{
    public class SearchModel
    {
        public string Guid { get; set; }
        public string Search { get; set; }
    }
}

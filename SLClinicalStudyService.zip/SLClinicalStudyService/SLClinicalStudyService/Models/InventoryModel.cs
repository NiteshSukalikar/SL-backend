﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Models
{
    public class InventoryModel
    {
        public long InventoryID { get; set; }
        public string InventoryName { get; set; }
        public int InventoryType { get; set; }
        public int? InventoryMinimumQuantity { get; set; }
        public int? InventoryAvailableQuantity { get; set; }
        public long OrganizationID { get; set; }
        public long? InventoryHCPCSCode { get; set; }
        public long? InventoryNDCCode { get; set; }
        public long InventoryAddedBy { get; set; }
        public DateTime InventoryAddedDate { get; set; }
        public long InventoryIssuerName { get; set; }
        public long InventoryReturnedBy { get; set; }
        public bool? IsReturned { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        public int? ModifiedBy { get; set; }
        public Guid? InventoryGuid { get; set; }
        public string? HCPC { get; set; }
        public string? ProductNdc { get; set; }
        public string? ProductTypeName { get; set; }
        public string? OrganizationName { get; set; }
    }
}

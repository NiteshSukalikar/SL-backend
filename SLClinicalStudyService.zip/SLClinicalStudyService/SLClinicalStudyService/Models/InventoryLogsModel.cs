﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Models
{
    public class InventoryLogsModel
    {
        public int InvQuantity { get; set; }
        public int AmtPerQuantity { get; set; }
        public int InventoryId { get; set; }
        public int TransactionType { get; set; }
        public int SenderId { get; set; }
        public int ReceiverId { get; set; }      
    }
}

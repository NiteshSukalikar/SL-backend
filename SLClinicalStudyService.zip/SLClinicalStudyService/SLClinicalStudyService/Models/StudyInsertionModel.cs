﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Models
{
    public class StudyInsertionModel
    {
        public CSDetailsModel CSDetailsModels { get; set; }
        public List<CSSearchKeywordModel> CSSearchKeywordModels { get; set; }
        public List<CSOutcomeMeasures> CSOutcomeMeasures { get; set; }
        public List<CSLocationModel> CSLocationModel { get; set; }
        public List<CSCriteriaModel> CSCriteriaModel { get; set; }
        public List<CSContactModel> CSContactModel { get; set; }
        public List<CSConditionOrDiseaseModel> CSConditionOrDiseaseModel { get; set; }
        public List<CSArmsInterventionsModel> CSArmsInterventionsModel { get; set; }
        public List<CSPhaseModel> CSPhaseModel { get; set; }
        public List<CSInterventionOrTreatmentModel> CSInterventionOrTreatmentModel { get; set; }

    }
  
    public class CSDetailsModel
    {
        public long CSStudyID { get; set; }
        public string CSCode { get; set; }
        public string CSTitle { get; set; }
        public string CSShortDescription { get; set; }
        public long CSInformationProvider { get; set; }
        public string? CSDescription { get; set; }
        public int? CSStudyType { get; set; }
        public string? CSActualEnrollment { get; set; }
        public string? CSAllocation { get; set; }
        public string? CSInterventionMode { get; set; }
        public string? CSMasking { get; set; }
        public string? CSPrimaryPurpose { get; set; }
        public string? CSOfficialTitle { get; set; }
        public DateTime? CSActualStartDate { get; set; }
        public DateTime? CSEstPrimaryCompletionDate { get; set; }
        public DateTime? CSEstStudyCompletionDate { get; set; }
        public DateTime? PublishDate { get; set; }
        public int? CSAgesEligible { get; set; }
        public int? CSAgesEligibleMoreOrLess { get; set; }
        public string? CSSexesEligible { get; set; }
        public int? CSAcceptsHealthyVolunteers { get; set; }
        public int? CSIsVerrified { get; set; }
        public string? CSIsVerrifiedBy { get; set; }
        public string? CSIPDStatement { get; set; }
        public int? ShareIPD { get; set; }
        public int? CSFDADrugProduct { get; set; }
        public int? CSFDADeviceProduct { get; set; }
        public int? CSProductUSA { get; set; }
        public long? Keywordsprovidedby { get; set; }
        public long? SponserID { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsPublish { get; set; }
        public bool? IsDeleted { get; set; }

        public Guid? CSGuiD { get; set; }
        public string? CSLocationName { get; set; }
        public string? CSConditionOrDiseaseText { get; set; }

        public bool IsComStdDesc { get; set; }
        public bool IsComStdDesign { get; set; }
        public bool IsComOutComeMeasure { get; set; }
        public bool IsComElgCriteria { get; set; }
        public bool IsComCriteria { get; set; }
        public bool IsComInfo { get; set; }
        public string? Guid { get; set; }
        public long? Id { get; set; }
        public int CanSendInvite { get; set; }

    }

    public class CSSearchKeywordModel
    {
        public Guid? SearchKeywordGuid { get; set; }
        public string? SearchKeywordText { get; set; }
        public int? OrderNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsPublish { get; set; }
        public bool IsDeleted { get; set; }
    }

    public class CSOutcomeMeasures
    {
        public Guid? CSOutcomeMeasuresGuiD { get; set; }
        public int CSPrimarySecondary { get; set; }
        public string CSOutcomeMeasuresText { get; set; }
        public int OrderNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsPublish { get; set; }
        public bool IsDeleted { get; set; }
    }
    public class CSLocationModel
    {
        public Guid? CSLocationGuiD { get; set; }
        public string CSLocationAddress1 { get; set; }
        public string CSLocationAddress2 { get; set; }
        public string CSLocationPhone1 { get; set; }
        public string CSLocationPhone2 { get; set; }
        public string CSLocationEmailAddress1 { get; set; }
        public string CSLocationEmailAddress2 { get; set; }
        public string CSLocationName { get; set; }
        public string CSLocationZip { get; set; }
        public int OrderNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsPublish { get; set; }
        public bool IsDeleted { get; set; }

    }
    public class CSCriteriaModel
    {
        public Guid? CSCriteriaGuid { get; set; }
        public int CSInclusionExclusion { get; set; }
        public string CSCriteriaText { get; set; }
        public int OrderNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsPublish { get; set; }
        public bool IsDeleted { get; set; }

    }
    public class CSContactModel
    {
        public Guid? CSContactGuiD { get; set; }
        public string CSContactFirstName { get; set; }
        public string CSContactMiddleName { get; set; }
        public string CSContactLastName { get; set; }
        public string CSContactPhone1 { get; set; }
        public string? CSContactPhone2 { get; set; }
        public string CSContactEmailAddress1 { get; set; }
        public string? CSContactEmailAddress2 { get; set; }
        public string CSContactAddress1 { get; set; }
        public string? CSContactAddress2 { get; set; }
        public string? StateName { get; set; }
        public int CountryID { get; set; }
        public int OrderNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsPublish { get; set; }
        public bool IsDeleted { get; set; }
    }
    public class CSConditionOrDiseaseModel
    {
        public Guid? CSConditionOrDiseaseGuID { get; set; }
        public int CSConditionOrDisease { get; set; }
        public string CSConditionOrDiseaseText { get; set; }
        public int OrderNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsPublish { get; set; }
        public bool IsDeleted { get; set; }

    }

    public class CSArmsInterventionsModel
    {
        public Guid? CSArmsInterventionsGuID { get; set; }
        public int CSArmsOrIntervention { get; set; }
        public string CSArmsInterventionsText { get; set; }
        public int OrderNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsPublish { get; set; }
        public bool IsDeleted { get; set; }
    }
    public class CSPhaseModel
    {
        public Guid? CSPhaseGuID { get; set; }
        public string CSPhaseText { get; set; }
        public int OrderNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsPublish { get; set; }
        public bool IsDeleted { get; set; }

    }
    public class CSInterventionOrTreatmentModel
    {
        public Guid? CSInterventionOrTreatmentGuID { get; set; }
        public int CSInterventionOrTreatment { get; set; }
        public string CSInterventionOrTreatmentText { get; set; }
        public int OrderNo { get; set; }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Model
{
    public class GuidModel
    {
        public string Guid { get; set; }
        public long? Id { get; set; }
    }
}

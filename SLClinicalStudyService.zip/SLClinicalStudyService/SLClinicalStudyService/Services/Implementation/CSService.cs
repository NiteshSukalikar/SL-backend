﻿using Shared.Enum;
using Shared.Model;
using SLClinicalStudyService.Common.StaticConstants;
using SLClinicalStudyService.Model;
using SLClinicalStudyService.Models;
using SLClinicalStudyService.Repository.UnitOfWorkAndBaseRepo;
using SLClinicalStudyService.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Services.Implementation
{
    public class CSService : ICSService
    {
        private readonly IUnitOfWork _unitOfWork;

        public CSService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        #region Inventory

        public async Task<ResponseModel> GetDetails(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                CSInventoryModelWithGuid result = await _unitOfWork.CSRepositoryModel.GetDetails(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetCodeList(int type)
        {
            var response = new ResponseModel();
            try
            {
                List<CodesModelData> result = await _unitOfWork.CSRepositoryModel.GetCodeList(type);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> SearchInventory(SearchModel search)
        {
            var response = new ResponseModel();
            try
            {
                StudyInventoryModel result = await _unitOfWork.CSRepositoryModel.SearchInventory(search);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetDrugsList()
        {
            var response = new ResponseModel();
            try
            {
                List<InventoryModel> result = await _unitOfWork.CSRepositoryModel.GetDrugsList();
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetInventoriesList()
        {
            var response = new ResponseModel();
            try
            {
                List<InventoryModel> result = await _unitOfWork.CSRepositoryModel.GetInventoriesList();
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> AddStudyInventory(StudyInventoryModel inventoryModel)
        {
            var response = new ResponseModel();
            try
            {
                response = await _unitOfWork.CSRepositoryModel.AddStudyInventory(inventoryModel);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> DeleteInventory(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                ResponseModel result = await _unitOfWork.CSRepositoryModel.DeleteInventory(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        public async Task<ResponseModel> UpdateStudyInventory(CSInventoryModel inventoryModel)
        {
            var response = new ResponseModel();
            try
            {
                response = await _unitOfWork.CSRepositoryModel.UpdateStudyInventory(inventoryModel);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetStudyInventoryByCSGuid(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                StudyInventoryModel result = await _unitOfWork.CSRepositoryModel.GetStudyInventoryByCSGuid(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        #endregion

        #region study

        public async Task<ResponseModel> AddStudyInsertion(StudyInsertionModel Studies)
        {
            var response = new ResponseModel();
            try
            {
                response = await _unitOfWork.CSRepositoryModel.AddStudyInsertion(Studies);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }

        }

        public async Task<ResponseModel> GetCSDetailList()
        {
            var response = new ResponseModel();
            try
            {
                List<CSDetailsModel> result = await _unitOfWork.CSRepositoryModel.GetCSDetailList();
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> GetStudyInsertionByCSGuid(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                StudyInsertionModel result = await _unitOfWork.CSRepositoryModel.GetStudyInsertionByCSGuid(guidModel);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> DeleteStudyByCSGuid(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                response = await _unitOfWork.CSRepositoryModel.DeleteStudyByCSGuid(guidModel);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> UpdateStudyInsertion(StudyInsertionModel Studies, Guid csGuid)
        {
            var response = new ResponseModel();
            try
            {
                if (Studies.CSDetailsModels.IsPublish == true)
                {
                    
                    Studies.CSDetailsModels.IsActive = true;
                }
                response = await _unitOfWork.CSRepositoryModel.UpdateStudyInsertion(Studies, csGuid);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> SearchStudies(CSDetailsModel modelSearch)
        {
            var response = new ResponseModel();
            try
            {
                //Task<MasterEmailTemplateModel> GetEmailTemplate
                List<CSDetailsModel> result = await _unitOfWork.CSRepositoryModel.SearchStudies(modelSearch);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> SearchAllTypeStudies(CSDetailsModel modelSearch)
        {
            var response = new ResponseModel();
            try
            {
                //Task<MasterEmailTemplateModel> GetEmailTemplate
                List<CSDetailsModel> result = await _unitOfWork.CSRepositoryModel.SearchAllTypeStudies(modelSearch);
                if (result != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Data = result;
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = IEHMessages.UserNotFound;
                }

                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> ActiveInactiveStudyByCSGuid(GuidModel guidModel)
        {
            var response = new ResponseModel();
            try
            {
                response = await _unitOfWork.CSRepositoryModel.ActiveInactiveStudyByCSGuid(guidModel);
                if (response.ReturnCode != null)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    response.Message = IEHMessages.OperationSuccessful;
                }
                else
                {
                    response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                    response.Data = null;
                    response.Message = response.Message;
                }
                return response;
            }
            catch (Exception e)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }


        #endregion


    }
}

﻿using Shared.Model;
using SLClinicalStudyService.Model;
using SLClinicalStudyService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Services.Interface
{
    public interface ICSService
    {
        // Get All Lists
        Task<ResponseModel> GetInventoriesList();
        Task<ResponseModel> GetDrugsList();
        Task<ResponseModel> AddStudyInventory(StudyInventoryModel inventoryModel);
        Task<ResponseModel> UpdateStudyInventory(CSInventoryModel inventoryModel);
        Task<ResponseModel> GetStudyInventoryByCSGuid(GuidModel guidModel);
        Task<ResponseModel> GetIssueStudyInventoryByCSGuid(GuidModel guidModel);
        Task<ResponseModel> GetCodeList(int type);
        Task<ResponseModel> DeleteInventory(GuidModel guidModel);
        Task<ResponseModel> GetDetails(GuidModel guidModel);
        Task<ResponseModel> SearchInventory(SearchModel searchModel);
        Task<ResponseModel> IssueInventoryLogs(CSInventoryLogsModel csInventoryLogsModel);

        // Get Single record
        Task<ResponseModel> AddStudyInsertion(StudyInsertionModel Studies);
        Task<ResponseModel> GetCSDetailList(GuidModel guidModel);

        Task<ResponseModel> GetSponsorCSList(GuidModel guidModel);


        Task<ResponseModel> GetCSPublishedStudyList(GuidModel guidModel);        
        Task<ResponseModel> GetOrganizationPoolStudyList(GuidModel guidModel);

        Task<ResponseModel> GetApprovedOrganizationStudyList(GuidModel guidModel);
        Task<ResponseModel> GetApprovedCROStudyList(GuidModel guidModel);
        
        Task<ResponseModel> GetStudyInsertionByCSGuid(GuidModel guidModel);
        Task<ResponseModel> DeleteStudyByCSGuid(GuidModel guidModel);
        Task<ResponseModel> ActiveInactiveStudyByCSGuid(GuidModel guidModel);
        Task<ResponseModel> UpdateStudyInsertion(StudyInsertionModel Studies, Guid csGuid);
        Task<ResponseModel> SearchStudies(CSDetailsModel search);
        Task<ResponseModel> SearchAllTypeStudies(CSDetailsModel search);
        Task<ResponseModel> InventoryLogsInsert(InventoryLogsModel search);
        Task<ResponseModel> GetStudyListOfOrganization(GuidModel guidModel);
        Task<ResponseModel> SearchAccepetedStudyOfOrganization(CSDetailsModel search);
    }
}

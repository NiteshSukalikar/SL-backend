﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Shared.Helper;
using Shared.Model;
using SLClinicalStudyService.Model;
using SLClinicalStudyService.Models;
using SLClinicalStudyService.Services.Interface;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InventoryController : ControllerBase
    {
        private readonly ICSService _csService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<InventoryController> _logger;
        private readonly CommonMethods _commonMethods;

        public InventoryController(ICSService ICSservice, IConfiguration Configuration, ILogger<InventoryController> logger)
        {
            _csService = ICSservice;
            _configuration = Configuration;
            _logger = logger;
            _commonMethods = new CommonMethods();
        }

        [HttpGet]
        [Route("GetInventoriesList")]
        public async Task<IActionResult> GetInventoriesList()
        {
            ResponseModel result = await _csService.GetInventoriesList();
            return Ok(result);
        }

        [HttpGet]
        [Route("GetDrugsList")]
        public async Task<IActionResult> GetDrugsList()
        {
            ResponseModel result = await _csService.GetDrugsList();
            return Ok(result);
        }

        [HttpPost]
        [Route("GetDetails")]
        public async Task<IActionResult> GetDetails([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.GetDetails(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("AddStudyInventory")]
        public async Task<IActionResult> AddStudyInventory(StudyInventoryModel inventoryModel)
        {
            ResponseModel result = await _csService.AddStudyInventory(inventoryModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("UpdateStudyInventory")]
        public async Task<IActionResult> UpdateStudyInventory(CSInventoryModel inventoryModel)
        {
            ResponseModel result = await _csService.UpdateStudyInventory(inventoryModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetStudyInventoryByCSGuid")]
        public async Task<IActionResult> GetStudyInventoryByCSGuid([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.GetStudyInventoryByCSGuid(guidModel);
            return Ok(result);
        }

        [HttpGet]
        [Route("GetCodeList")]
        public async Task<IActionResult> GetCodeList(int type)
        {
            ResponseModel result = await _csService.GetCodeList(type);
            return Ok(result);
        }

        [HttpPost]
        [Route("DeleteInventory")]
        public async Task<IActionResult> DeleteInventory([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.DeleteInventory(guidModel);
            return Ok(result);
        }


        [HttpPost]
        [Route("SearchInventory")]
        public async Task<IActionResult> SearchInventory([FromBody] SearchModel searchModel)
        {

            ResponseModel result = await _csService.SearchInventory(searchModel);
            return Ok(result);
        }

    }
}

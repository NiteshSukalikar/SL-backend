﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Shared.Helper;
using Shared.Model;
using SLClinicalStudyService.Model;
using SLClinicalStudyService.Models;
using SLClinicalStudyService.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudyController : ControllerBase
    {
        private readonly ICSService _csService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<InventoryController> _logger;
        private readonly CommonMethods _commonMethods;
        public StudyController(ICSService ICSservice, IConfiguration Configuration, ILogger<InventoryController> logger)
        {
            _csService = ICSservice;
            _configuration = Configuration;
            _logger = logger;
            _commonMethods = new CommonMethods();
        }
        [HttpPost]
        [Route("AddStudy")]
        public async Task<IActionResult> AddStudy(StudyInsertionModel Studies)
        {
            ResponseModel result = await _csService.AddStudyInsertion(Studies);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetCSList")]
        public async Task<IActionResult> GetCSList([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.GetCSDetailList(guidModel);
            return Ok(result);
        }        


        [HttpPost]
        [Route("GetSponsorCSList")]
        public async Task<IActionResult> GetSponsorCSList([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.GetSponsorCSList(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetCSPublishedStudyList")]
        public async Task<IActionResult> GetCSPublishedStudyList([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.GetCSPublishedStudyList(guidModel);
            return Ok(result);
        }



        [HttpPost]       
        [Route("GetOrganizationPoolStudyList")]
        public async Task<IActionResult> GetOrganizationPoolStudyList([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.GetOrganizationPoolStudyList(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetApprovedOrganizationStudyList")]
        public async Task<IActionResult> GetApprovedOrganizationStudyList([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.GetApprovedOrganizationStudyList(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("GetApprovedCROStudyList")]
        public async Task<IActionResult> GetApprovedCROStudyList([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.GetCSPublishedStudyList(guidModel);
            return Ok(result);
        }


        [HttpPost]
        [Route("GetStudyByCSGuid")]
        public async Task<IActionResult> GetStudyByCSGuid([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.GetStudyInsertionByCSGuid(guidModel);
            return Ok(result);
        }
        [HttpPost]
        [Route("DeleteStudyByCSGuid")]
        public async Task<IActionResult> DeleteStudyByCSGuid([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.DeleteStudyByCSGuid(guidModel);
            return Ok(result);
        }
        [HttpPost]
        [Route("ActiveInactiveStudy")]
        public async Task<IActionResult> ActiveInactiveStudyByCSGuid([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.ActiveInactiveStudyByCSGuid(guidModel);
            return Ok(result);
        }
        [HttpPost]
        [Route("UpdateStudy")]
        public async Task<IActionResult> UpdateStudy(StudyInsertionModel Studies)
        {
            Guid csGuid = (Guid)Studies.CSDetailsModels.CSGuiD;
            ResponseModel result = await _csService.UpdateStudyInsertion(Studies,csGuid);
            return Ok(result);
        }
        [HttpPost]
        [Route("SearchStudies")]
        public async Task<IActionResult> SearchStudies(CSDetailsModel model)
        {

            ResponseModel result = await _csService.SearchStudies(model);
            return Ok(result);
        }

        [HttpPost]
        [Route("SearchAllTypeStudies")]
        public async Task<IActionResult> SearchAllTypeStudies(CSDetailsModel model)
        {

            ResponseModel result = await _csService.SearchAllTypeStudies(model);
            return Ok(result);
        }
        //DO this page
        [HttpPost]
        [Route("GetStudyListOfOrganization")]
        public async Task<IActionResult> GetStudyListOfOrganization([FromBody] GuidModel guidModel)
        {
            ResponseModel result = await _csService.GetStudyListOfOrganization(guidModel);
            return Ok(result);
        }

        [HttpPost]
        [Route("SearchAccepetedStudyOfOrganization")]
        public async Task<IActionResult> SearchAccepetedStudyOfOrganization(CSDetailsModel model)
        {

            ResponseModel result = await _csService.SearchAccepetedStudyOfOrganization(model);
            return Ok(result);
        }

    }
}

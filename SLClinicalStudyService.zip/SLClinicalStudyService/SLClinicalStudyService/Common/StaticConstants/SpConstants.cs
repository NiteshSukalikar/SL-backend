﻿namespace SLClinicalStudyService.Common.StaticConstants
{
    /// <summary>
    /// Constants for Stored Procedure Names
    /// Defines the <see cref="SpConstants" />
    /// </summary>
    public static class SpConstants
    {       
        public const string GetInventoriesList = "USP_GetInventoriesList";
        public const string GetDrugList = "USP_GetDrugList";
        public const string AddStudyInventory = "USP_AddStudyInventory";
        public const string UpdateStudyInventory = "USP_UpdateStudyInventory";
        public const string GetStudyInventoryByCSGuID = "USP_GetStudyInventoryByCSGuID";
        public const string GetStudyCodeList = "USP_GetCodesList";
        public const string SearchInventory = "USP_SearchInventory";
        public const string DeleteInventory = "USP_DeleteInventory";
        public const string GetInventoryRecord = "USP_GetInventoryRecord";


        public const string AddStudyInvention = "USP_AddStudyInvention";
        public const string GETStudyList = "USP_GETStudyList";
        public const string GETStudyByCSGuID = "USP_GETStudyByCSGuID";
        public const string DeleteStudy = "USP_DELETESTUDY";
        public const string ActiveInactiveStudy = "USP_ActiveInactiveStudy";
       //public const string UpdateStudyInvention = "USP_UpdateStudyInvention";
        public const string UpdateStudyInvention = "USP_UpdateStudyWithChild";
        public const string SearchStudies = "USP_CSDetailsSearch";
        public const string SearchAllTypeStudies = "USP_SearchStudy";
    }
}

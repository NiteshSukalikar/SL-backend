﻿using Microsoft.Data.SqlClient;
using Shared.Enum;
using Shared.Helper;
using Shared.Model;
using SLClinicalStudyService.Common.StaticConstants;
using SLClinicalStudyService.Infrastructure.DataAccess;
using SLClinicalStudyService.Model;
using SLClinicalStudyService.Models;
using SLClinicalStudyService.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Repository.Implementation
{
    public class CSRepository : ICSRepository
    {
        private readonly IEHDbContext _IEHDbContext;
        private readonly CommonMethods _commonMethods;

        public CSRepository(IEHDbContext IEHDbContext)
        {
            _IEHDbContext = IEHDbContext;
            _commonMethods = new CommonMethods();
        }

        #region study
        public async Task<ResponseModel> AddStudyInsertion(StudyInsertionModel Studies)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                //CSDetailsModels


                //convert list to datatable
                DataTable dtSearchKeyword = Studies.CSSearchKeywordModels.ToDataTable<CSSearchKeywordModel>();
                DataTable dtOutcomeMeasures = Studies.CSOutcomeMeasures.ToDataTable<CSOutcomeMeasures>();
                DataTable dtLocationModel = Studies.CSLocationModel.ToDataTable<CSLocationModel>();
                DataTable dtCriteriaModel = Studies.CSCriteriaModel.ToDataTable<CSCriteriaModel>();
                DataTable dtContactModel = Studies.CSContactModel.ToDataTable<CSContactModel>();
                DataTable dtConditionOrDisease = Studies.CSConditionOrDiseaseModel.ToDataTable<CSConditionOrDiseaseModel>();
                DataTable dtArmsInterventionsModel = Studies.CSArmsInterventionsModel.ToDataTable<CSArmsInterventionsModel>();
                DataTable dtPhase = Studies.CSPhaseModel.ToDataTable<CSPhaseModel>();
                DataTable dtInterventionOrTreatment = Studies.CSInterventionOrTreatmentModel.ToDataTable<CSInterventionOrTreatmentModel>();
                SqlParameter[] param = {
                    new SqlParameter("@CSCode",Studies.CSDetailsModels.CSCode),
                    new SqlParameter("@CSTitle", Studies.CSDetailsModels.CSTitle),
                    new SqlParameter("@CSShortDescription", Studies.CSDetailsModels.CSShortDescription),
                    new SqlParameter("@CSInformationProvider", Studies.CSDetailsModels.CSInformationProvider),
                    new SqlParameter("@CSDescription", Studies.CSDetailsModels.CSDescription),
                    new SqlParameter("@CSStudyType", Studies.CSDetailsModels.CSStudyType),
                    new SqlParameter("@CSActualEnrollment", Studies.CSDetailsModels.CSActualEnrollment),
                    new SqlParameter("@CSAllocation", Studies.CSDetailsModels.CSAllocation),
                    new SqlParameter("@CSInterventionMode", Studies.CSDetailsModels.CSInterventionMode),
                    new SqlParameter("@CSMasking", Studies.CSDetailsModels.CSMasking),
                    new SqlParameter("@CSPrimaryPurpose", Studies.CSDetailsModels.CSPrimaryPurpose),
                    new SqlParameter("@CSOfficialTitle", Studies.CSDetailsModels.CSOfficialTitle),
                    new SqlParameter("@CSActualStartDate", Studies.CSDetailsModels.CSActualStartDate),
                    new SqlParameter("@CSEstPrimaryCompletionDate", Studies.CSDetailsModels.CSEstPrimaryCompletionDate),
                    new SqlParameter("@CSEstStudyCompletionDate", Studies.CSDetailsModels.CSEstStudyCompletionDate),
                    new SqlParameter("@CSAgesEligible", Studies.CSDetailsModels.CSAgesEligible),
                    new SqlParameter("@CSAgesEligibleMoreOrLess", Studies.CSDetailsModels.CSAgesEligibleMoreOrLess),
                    new SqlParameter("@CSSexesEligible", Studies.CSDetailsModels.CSSexesEligible),
                    new SqlParameter("@CSAcceptsHealthyVolunteers", Studies.CSDetailsModels.CSAcceptsHealthyVolunteers),
                    new SqlParameter("@CSIsVerrified", Studies.CSDetailsModels.CSIsVerrified),
                    new SqlParameter("@CSIsVerrifiedBy", Studies.CSDetailsModels.CSIsVerrifiedBy),
                    new SqlParameter("@CSIPDStatement", Studies.CSDetailsModels.CSIPDStatement),
                    new SqlParameter("@ShareIPD", Studies.CSDetailsModels.ShareIPD),
                    new SqlParameter("@CSFDADrugProduct", Studies.CSDetailsModels.CSFDADrugProduct),
                    new SqlParameter("@CSFDADeviceProduct", Studies.CSDetailsModels.CSFDADeviceProduct),
                    new SqlParameter("@CSProductUSA", Studies.CSDetailsModels.CSProductUSA),
                    new SqlParameter("@Keywordsprovidedby", Studies.CSDetailsModels.Keywordsprovidedby),
                    new SqlParameter("@SponserID", Studies.CSDetailsModels.SponserID),
                    new SqlParameter("@IsActive", Studies.CSDetailsModels.IsActive),
                    new SqlParameter("@IsPublish", Studies.CSDetailsModels.IsPublish),
                    new SqlParameter("@IsDeleted", Studies.CSDetailsModels.IsDeleted),
                    //Table Type Parameter
                   new SqlParameter("@CsSearchKeyword",dtSearchKeyword),
                   new SqlParameter("@CsOutcomeMeasures",dtOutcomeMeasures),
                   new SqlParameter("@CSLocation",dtLocationModel),
                   new SqlParameter("@CSCriteria",dtCriteriaModel),
                   new SqlParameter("@CSContact",dtContactModel),
                   new SqlParameter("@CSConditionOrDisease",dtConditionOrDisease),
                   new SqlParameter("@CSArmsInterventions",dtArmsInterventionsModel),
                   new SqlParameter("@CSPhase",dtPhase),
                   new SqlParameter("@CSInterventionOrTreatment",dtInterventionOrTreatment),
                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.AddStudyInvention, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.ServerErrorCode;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> DeleteStudyByCSGuid(GuidModel guidModel)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                //CSDetailsModels


                //convert list to datatable

                SqlParameter[] param = {
                    new SqlParameter("@CSGuiD",guidModel.Guid),
                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.DeleteStudy, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.RecordNotFound;
                    //response.ReturnCode = null;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<List<CSDetailsModel>> GetCSDetailList()
        {
            try
            {
                SqlParameter[] param = { };
                var connection = _IEHDbContext.GetDbConnection();
                List<CSDetailsModel> result = new List<CSDetailsModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GETStudyList, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<CSDetailsModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<StudyInsertionModel> GetStudyInsertionByCSGuid(GuidModel guidModel)
        {
            try
            {
                //SqlParameter[] param = { };
                var connection = _IEHDbContext.GetDbConnection();
                StudyInsertionModel result = new StudyInsertionModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    SqlParameter[] param = {
                    new SqlParameter("@CSGuiD",guidModel.Guid)
                };
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GETStudyByCSGuID, param, cmd);
                        DataSet ds = new DataSet();

                        using (var da = new SqlDataAdapter(cmd as SqlCommand))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            da.Fill(ds);
                        }
                        result.CSSearchKeywordModels = ds.Tables[0].ConvertDataTable<CSSearchKeywordModel>();
                        result.CSPhaseModel = ds.Tables[1].ConvertDataTable<CSPhaseModel>();
                        result.CSLocationModel = ds.Tables[2].ConvertDataTable<CSLocationModel>();
                        result.CSOutcomeMeasures = ds.Tables[3].ConvertDataTable<CSOutcomeMeasures>();
                        result.CSConditionOrDiseaseModel = ds.Tables[4].ConvertDataTable<CSConditionOrDiseaseModel>();
                        result.CSArmsInterventionsModel = ds.Tables[5].ConvertDataTable<CSArmsInterventionsModel>();
                        result.CSCriteriaModel = ds.Tables[6].ConvertDataTable<CSCriteriaModel>();
                        result.CSContactModel = ds.Tables[7].ConvertDataTable<CSContactModel>();
                        result.CSInterventionOrTreatmentModel = ds.Tables[8].ConvertDataTable<CSInterventionOrTreatmentModel>();
                        result.CSDetailsModels = ds.Tables[9].ConvertDataTable<CSDetailsModel>().FirstOrDefault();
                        //CSDetailsModel
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ResponseModel> UpdateStudyInsertion(StudyInsertionModel Studies, Guid csGuid)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                //CSDetailsModels


                //convert list to datatable
                DataTable dtSearchKeyword = Studies.CSSearchKeywordModels.ToDataTable<CSSearchKeywordModel>();
                DataTable dtOutcomeMeasures = Studies.CSOutcomeMeasures.ToDataTable<CSOutcomeMeasures>();
                DataTable dtLocationModel = Studies.CSLocationModel.ToDataTable<CSLocationModel>();
                DataTable dtCriteriaModel = Studies.CSCriteriaModel.ToDataTable<CSCriteriaModel>();
                DataTable dtContactModel = Studies.CSContactModel.ToDataTable<CSContactModel>();
                DataTable dtConditionOrDisease = Studies.CSConditionOrDiseaseModel.ToDataTable<CSConditionOrDiseaseModel>();
                DataTable dtArmsInterventionsModel = Studies.CSArmsInterventionsModel.ToDataTable<CSArmsInterventionsModel>();
                DataTable dtPhase = Studies.CSPhaseModel.ToDataTable<CSPhaseModel>();
                DataTable dtInterventionOrTreatment = Studies.CSInterventionOrTreatmentModel.ToDataTable<CSInterventionOrTreatmentModel>();
                SqlParameter[] param = {
                    new SqlParameter("@CSCode",Studies.CSDetailsModels.CSCode),
                    new SqlParameter("@CSTitle", Studies.CSDetailsModels.CSTitle),
                    new SqlParameter("@CSShortDescription", Studies.CSDetailsModels.CSShortDescription),
                    new SqlParameter("@CSInformationProvider", Studies.CSDetailsModels.CSInformationProvider),
                    new SqlParameter("@CSDescription", Studies.CSDetailsModels.CSDescription),
                    new SqlParameter("@CSStudyType", Studies.CSDetailsModels.CSStudyType),
                    new SqlParameter("@CSActualEnrollment", Studies.CSDetailsModels.CSActualEnrollment),
                    new SqlParameter("@CSAllocation", Studies.CSDetailsModels.CSAllocation),
                    new SqlParameter("@CSInterventionMode", Studies.CSDetailsModels.CSInterventionMode),
                    new SqlParameter("@CSMasking", Studies.CSDetailsModels.CSMasking),
                    new SqlParameter("@CSPrimaryPurpose", Studies.CSDetailsModels.CSPrimaryPurpose),
                    new SqlParameter("@CSOfficialTitle", Studies.CSDetailsModels.CSOfficialTitle),
                    new SqlParameter("@CSActualStartDate", Studies.CSDetailsModels.CSActualStartDate),
                    new SqlParameter("@CSEstPrimaryCompletionDate", Studies.CSDetailsModels.CSEstPrimaryCompletionDate),
                    new SqlParameter("@CSEstStudyCompletionDate", Studies.CSDetailsModels.CSEstStudyCompletionDate),
                    new SqlParameter("@CSAgesEligible", Studies.CSDetailsModels.CSAgesEligible),
                    new SqlParameter("@CSAgesEligibleMoreOrLess", Studies.CSDetailsModels.CSAgesEligibleMoreOrLess),
                    new SqlParameter("@CSSexesEligible", Studies.CSDetailsModels.CSSexesEligible),
                    new SqlParameter("@CSAcceptsHealthyVolunteers", Studies.CSDetailsModels.CSAcceptsHealthyVolunteers),
                    new SqlParameter("@CSIsVerrified", Studies.CSDetailsModels.CSIsVerrified),
                    new SqlParameter("@CSIsVerrifiedBy", Studies.CSDetailsModels.CSIsVerrifiedBy),
                    new SqlParameter("@CSIPDStatement", Studies.CSDetailsModels.CSIPDStatement),
                    new SqlParameter("@ShareIPD", Studies.CSDetailsModels.ShareIPD),
                    new SqlParameter("@CSFDADrugProduct", Studies.CSDetailsModels.CSFDADrugProduct),
                    new SqlParameter("@CSFDADeviceProduct", Studies.CSDetailsModels.CSFDADeviceProduct),
                    new SqlParameter("@CSProductUSA", Studies.CSDetailsModels.CSProductUSA),
                    new SqlParameter("@Keywordsprovidedby", Studies.CSDetailsModels.Keywordsprovidedby),
                    new SqlParameter("@SponserID", Studies.CSDetailsModels.SponserID),
                    new SqlParameter("@IsActive", Studies.CSDetailsModels.IsActive),
                    new SqlParameter("@IsPublish", Studies.CSDetailsModels.IsPublish),
                    new SqlParameter("@IsDeleted", Studies.CSDetailsModels.IsDeleted),
                    new SqlParameter("@CSGuiD",csGuid),
                    //Table Type Parameter
                   new SqlParameter("@CsSearchKeyword",dtSearchKeyword),
                   new SqlParameter("@CsOutcomeMeasures",dtOutcomeMeasures),
                   new SqlParameter("@CSLocation",dtLocationModel),
                   new SqlParameter("@CSCriteria",dtCriteriaModel),
                   new SqlParameter("@CSContact",dtContactModel),
                   new SqlParameter("@CSConditionOrDisease",dtConditionOrDisease),
                   new SqlParameter("@CSArmsInterventions",dtArmsInterventionsModel),
                   new SqlParameter("@CSPhase",dtPhase),
                   new SqlParameter("@CSInterventionOrTreatment",dtInterventionOrTreatment),

                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.UpdateStudyInvention, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.ServerErrorCode;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<List<CSDetailsModel>> SearchStudies(CSDetailsModel searchModel)
        {
            try
            {

                SqlParameter[] param = {
                    new SqlParameter("@IsActive", searchModel.IsActive),
                    new SqlParameter("@CSTitle", searchModel.CSTitle == null ? " " : searchModel.CSTitle),
                    new SqlParameter("@CSLocation", searchModel.CSLocationName == null ? " " : searchModel.CSLocationName),
                    new SqlParameter("@csConditionOrDiseaseText", searchModel.CSConditionOrDiseaseText == null ? " " : searchModel.CSConditionOrDiseaseText),
                    //new SqlParameter("@CSInformationProvider", searchModel.CSInformationProvider),
                    //new SqlParameter("@CSDescription", searchModel.CSDescription),
                    //new SqlParameter("@CSStudyType", searchModel.CSStudyType),
                    //new SqlParameter("@CSActualEnrollment", searchModel.CSActualEnrollment),
                    //new SqlParameter("@CSAllocation", searchModel.CSAllocation),

                    //new SqlParameter("@CSInterventionMode", searchModel.CSInterventionMode),
                    //new SqlParameter("@CSMasking", searchModel.CSMasking),
                    //new SqlParameter("@CSPrimaryPurpose", searchModel.CSPrimaryPurpose),
                    //new SqlParameter("@CSOfficialTitle", searchModel.CSOfficialTitle),
                    //new SqlParameter("@CSActualStartDate", searchModel.CSActualStartDate == null ? " " : searchModel.CSActualStartDate),
                    //new SqlParameter("@CSEstPrimaryCompletionDate", searchModel.CSEstPrimaryCompletionDate),
                    //new SqlParameter("@CSEstStudyCompletionDate", searchModel.CSEstStudyCompletionDate),
                    //new SqlParameter("@CSAgesEligible", searchModel.CSAgesEligible),
                    //new SqlParameter("@CSAgesEligibleMoreOrLess", searchModel.CSAgesEligibleMoreOrLess),
                    //new SqlParameter("@CSSexesEligible", searchModel.CSSexesEligible),
                    //new SqlParameter("@CSAcceptsHealthyVolunteers", searchModel.CSAcceptsHealthyVolunteers),
                    //new SqlParameter("@CSIsVerrified", searchModel.CSIsVerrifiedBy),
                    //new SqlParameter("@CSIsVerrifiedBy", searchModel.CSIsVerrifiedBy),
                    //new SqlParameter("@CSIPDStatement", searchModel.CSIPDStatement),
                    //new SqlParameter("@ShareIPD", searchModel.ShareIPD),
                    //new SqlParameter("@CSFDADrugProduct", searchModel.CSFDADeviceProduct),
                    //new SqlParameter("@CSFDADeviceProduct", searchModel.CSFDADeviceProduct),
                    //new SqlParameter("@CSProductUSA", searchModel.CSProductUSA),
                    //new SqlParameter("@Keywordsprovidedby", searchModel.Keywordsprovidedby),
                    //new SqlParameter("@SponserID", searchModel.SponserID)

                };
                var connection = _IEHDbContext.GetDbConnection();
                List<CSDetailsModel> result = new List<CSDetailsModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.SearchStudies, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<CSDetailsModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<CSDetailsModel>> SearchAllTypeStudies(CSDetailsModel searchModel)
        {
            try
            {

                SqlParameter[] param = {                 
                    new SqlParameter("@CSTitle", searchModel.CSTitle == null ? " " : searchModel.CSTitle),
                    new SqlParameter("@csConditionOrDiseaseText", searchModel.CSConditionOrDiseaseText == null ? " " : searchModel.CSConditionOrDiseaseText),
                    //new SqlParameter("@CSInformationProvider", searchModel.CSInformationProvider),
                    //new SqlParameter("@CSDescription", searchModel.CSDescription),
                    //new SqlParameter("@CSStudyType", searchModel.CSStudyType),
                    //new SqlParameter("@CSActualEnrollment", searchModel.CSActualEnrollment),
                    //new SqlParameter("@CSAllocation", searchModel.CSAllocation),

                    //new SqlParameter("@CSInterventionMode", searchModel.CSInterventionMode),
                    //new SqlParameter("@CSMasking", searchModel.CSMasking),
                    //new SqlParameter("@CSPrimaryPurpose", searchModel.CSPrimaryPurpose),
                    //new SqlParameter("@CSOfficialTitle", searchModel.CSOfficialTitle),
                    //new SqlParameter("@CSActualStartDate", searchModel.CSActualStartDate == null ? " " : searchModel.CSActualStartDate),
                    //new SqlParameter("@CSEstPrimaryCompletionDate", searchModel.CSEstPrimaryCompletionDate),
                    //new SqlParameter("@CSEstStudyCompletionDate", searchModel.CSEstStudyCompletionDate),
                    //new SqlParameter("@CSAgesEligible", searchModel.CSAgesEligible),
                    //new SqlParameter("@CSAgesEligibleMoreOrLess", searchModel.CSAgesEligibleMoreOrLess),
                    //new SqlParameter("@CSSexesEligible", searchModel.CSSexesEligible),
                    //new SqlParameter("@CSAcceptsHealthyVolunteers", searchModel.CSAcceptsHealthyVolunteers),
                    //new SqlParameter("@CSIsVerrified", searchModel.CSIsVerrifiedBy),
                    //new SqlParameter("@CSIsVerrifiedBy", searchModel.CSIsVerrifiedBy),
                    //new SqlParameter("@CSIPDStatement", searchModel.CSIPDStatement),
                    //new SqlParameter("@ShareIPD", searchModel.ShareIPD),
                    //new SqlParameter("@CSFDADrugProduct", searchModel.CSFDADeviceProduct),
                    //new SqlParameter("@CSFDADeviceProduct", searchModel.CSFDADeviceProduct),
                    //new SqlParameter("@CSProductUSA", searchModel.CSProductUSA),
                    //new SqlParameter("@Keywordsprovidedby", searchModel.Keywordsprovidedby),
                    //new SqlParameter("@SponserID", searchModel.SponserID)

                };
                var connection = _IEHDbContext.GetDbConnection();
                List<CSDetailsModel> result = new List<CSDetailsModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.SearchAllTypeStudies, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<CSDetailsModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ResponseModel> ActiveInactiveStudyByCSGuid(GuidModel guidModel)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                //CSDetailsModels


                //convert list to datatable

                SqlParameter[] param = {
                    new SqlParameter("@CSGuiD",guidModel.Guid),
                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.ActiveInactiveStudy, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.RecordNotFound;
                    //response.ReturnCode = null;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }
        #endregion



        #region Inventory
        public async Task<CSInventoryModelWithGuid> GetDetails(GuidModel guidModel)
        {
            try
            {
                SqlParameter[] param = {
                  new SqlParameter("@Id",guidModel.Guid),
                };
                var connection = _IEHDbContext.GetDbConnection();
                CSInventoryModelWithGuid result = new CSInventoryModelWithGuid();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetInventoryRecord, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<CSInventoryModelWithGuid>(reader).FirstOrDefault();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ResponseModel> DeleteInventory(GuidModel guidModel)
        {
            try
            {
                SqlParameter[] param = {
                  new SqlParameter("@Id",guidModel.Guid),
                };
                var connection = _IEHDbContext.GetDbConnection();
                ResponseModel result = new ResponseModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.DeleteInventory, param, cmd);
                        cmd.ExecuteNonQuery();
                        result.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        result.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<CodesModelData>> GetCodeList(int type)
        {
            try
            {
                var outParamID = new SqlParameter("@CodeType", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter[] param = {
                  new SqlParameter("@Type",type),outParamID
                };

                var connection = _IEHDbContext.GetDbConnection();
                List<CodesModelData> result = new List<CodesModelData>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetStudyCodeList, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {

                            result = _IEHDbContext.DataReaderMapToList<CodesModelData>(reader).ToList();
                            reader.NextResult();
                        }
                    }

                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<StudyInventoryModel> SearchInventory(SearchModel searchModel)
        {
            try
            {
                SqlParameter[] param = {
                  new SqlParameter("@Search",searchModel.Search),
                  new SqlParameter("@CSGuiD",searchModel.Guid)
                };

                var connection = _IEHDbContext.GetDbConnection();
                StudyInventoryModel result = new StudyInventoryModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.SearchInventory, param, cmd);
                        DataSet ds = new DataSet();

                        using (var da = new SqlDataAdapter(cmd as SqlCommand))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            da.Fill(ds);
                        }
                        result.CSInventoryModels = ds.Tables[0].ConvertDataTable<CSInventoryModel>();
                    }

                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<InventoryModel>> GetDrugsList()
        {
            try
            {
                SqlParameter[] param = { };
                var connection = _IEHDbContext.GetDbConnection();
                List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetDrugList, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<InventoryModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<InventoryModel>> GetInventoriesList()
        {
            try
            {
                SqlParameter[] param = { };
                var connection = _IEHDbContext.GetDbConnection();
                List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetInventoriesList, param, cmd);
                        using (var reader = cmd.ExecuteReader())
                        {
                            result = _IEHDbContext.DataReaderMapToList<InventoryModel>(reader).ToList();
                            reader.NextResult();
                        }
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ResponseModel> AddStudyInventory(StudyInventoryModel inventoryModel)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };

                //convert list to datatable
                DataTable dtInventory = inventoryModel.CSInventoryModels.ToDataTable<CSInventoryModel>();

                SqlParameter[] param = {
                    new SqlParameter("@CSGuiD", inventoryModel.CSGuid),   
                    //Table Type Parameter
                   new SqlParameter("@CsInventory",dtInventory),
                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.AddStudyInventory, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.ServerErrorCode;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<ResponseModel> UpdateStudyInventory(CSInventoryModel inventoryModel)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
                {
                    Direction = ParameterDirection.Output
                };

                //convert list to datatable
                // DataTable dtInventory = inventoryModel.CSInventoryModels.ToDataTable<CSInventoryModel>();

                SqlParameter[] param = {
                    new SqlParameter("@CSInventoryGuiD", inventoryModel.CSInventoryGuiD),
                    new SqlParameter("@InventoryType", inventoryModel.InventoryType),
                    new SqlParameter("@InventoryName", inventoryModel.InventoryName),
                    new SqlParameter("@InventoryCode", inventoryModel.InventoryCode),
                    new SqlParameter("@InventoryAvaiableQuantity", inventoryModel.InventoryAvailableQuantity),
                   outParam
                };

                //Execute the query
                var connection = _IEHDbContext.GetDbConnection();
                //List<InventoryModel> result = new List<InventoryModel>();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.UpdateStudyInventory, param, cmd);
                        cmd.ExecuteNonQuery();
                        response.ReturnCode = cmd.Parameters["@ReturnCode"].Value;
                        response.StatusCode = ((int)StatusCode.StatusCode200).ToString();
                    }

                }
                catch (Exception ex)
                {
                    response.StatusCode = ((int)StatusCode.StatusCode500).ToString();
                    response.Data = null;
                    // response.ReturnCode = null;
                    response.Message = IEHMessages.ServerErrorCode;
                }
                finally
                {
                    connection.Close();
                }

                return response;

            }
            catch (Exception ex)
            {
                response.StatusCode = ((int)StatusCode.StatusCode205).ToString();
                response.Data = null;
                // response.ReturnCode = null;
                response.Message = IEHMessages.InternalServerError;
                return response;
            }
        }

        public async Task<StudyInventoryModel> GetStudyInventoryByCSGuid(GuidModel guidModel)
        {
            try
            {
                //SqlParameter[] param = { };
                var connection = _IEHDbContext.GetDbConnection();
                StudyInventoryModel result = new StudyInventoryModel();
                try
                {
                    if (connection.State == ConnectionState.Closed) { connection.Open(); }
                    SqlParameter[] param = {
                    new SqlParameter("@CSGuiD",guidModel.Guid)
                };
                    using (var cmd = connection.CreateCommand())
                    {
                        _IEHDbContext.AddParametersToDbCommand(SpConstants.GetStudyInventoryByCSGuID, param, cmd);
                        DataSet ds = new DataSet();

                        using (var da = new SqlDataAdapter(cmd as SqlCommand))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            da.Fill(ds);
                        }
                        result.CSInventoryModels = ds.Tables[0].ConvertDataTable<CSInventoryModel>();
                    }
                    return result;
                }
                finally
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

    }
}

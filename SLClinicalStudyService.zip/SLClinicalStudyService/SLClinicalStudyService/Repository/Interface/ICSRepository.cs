﻿using Shared.Model;
using SLClinicalStudyService.Model;
using SLClinicalStudyService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLClinicalStudyService.Repository.Interface
{
    public interface ICSRepository
    {
        // Get All Lists
        Task<List<InventoryModel>> GetInventoriesList();
        Task<List<InventoryModel>> GetDrugsList();
        Task<List<CodesModelData>> GetCodeList(int type);
        Task<StudyInventoryModel> SearchInventory(SearchModel searchModel);
        Task<ResponseModel> AddStudyInventory(StudyInventoryModel inventoryModel);
        Task<ResponseModel> UpdateStudyInventory(CSInventoryModel inventoryModel);
        Task<StudyInventoryModel> GetStudyInventoryByCSGuid(GuidModel guidModel);
        Task<CSInventoryModelWithGuid> GetDetails(GuidModel guidModel);
        Task<ResponseModel> DeleteInventory(GuidModel guidModel);

        // Get Single Record

        Task<ResponseModel> AddStudyInsertion(StudyInsertionModel Studies);
        Task<List<CSDetailsModel>> GetCSDetailList();
        Task<StudyInsertionModel> GetStudyInsertionByCSGuid(GuidModel guidModel);
        Task<ResponseModel> DeleteStudyByCSGuid(GuidModel guidModel);
        Task<ResponseModel> ActiveInactiveStudyByCSGuid(GuidModel guidModel);
        Task<ResponseModel> UpdateStudyInsertion(StudyInsertionModel Studies, Guid csGuid);
        Task<List<CSDetailsModel>> SearchStudies(CSDetailsModel model);
        Task<List<CSDetailsModel>> SearchAllTypeStudies(CSDetailsModel model);
    }
}

﻿using SLClinicalStudyService.Infrastructure.DataAccess;
using SLClinicalStudyService.Repository.Implementation;
using SLClinicalStudyService.Repository.Interface;
using System;

namespace SLClinicalStudyService.Repository.UnitOfWorkAndBaseRepo
{


    /// <summary>
    /// Defines The UnitOfWork />
    /// </summary>
    public class UnitOfWork : IUnitOfWork
    {
        /// <summary>
        /// Defines the _context
        /// </summary>
        private readonly IEHDbContext _context;

        /// <summary>
        /// Defines the adminDashboardRepository
        /// </summary>
        private ICSRepository CSRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="UnitOfWork"/> class.
        /// </summary>
        /// <param name="context">The context<see cref="IEHDbContext"/></param>
        public UnitOfWork(IEHDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// The Complete
        /// </summary>
        /// <returns>The <see cref="int"/></returns>
        public int Complete()
        {
            return _context.SaveChanges();
        }
        
        public ICSRepository CSRepositoryModel
        {
            get
            {
                if (CSRepository == null)
                {
                    CSRepository = new CSRepository(_context);
                }
                return CSRepository;
            }
        }

        /// <summary>
        /// Defines the disposed
        /// </summary>
        private bool disposed = false;

        /// <summary>
        /// The Dispose
        /// </summary>
        /// <param name="disposing">The disposing<see cref="bool"/></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed && disposing)
            {
                _context.Dispose();
            }
            this.disposed = true;
        }

        /// <summary>
        /// The Dispose
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
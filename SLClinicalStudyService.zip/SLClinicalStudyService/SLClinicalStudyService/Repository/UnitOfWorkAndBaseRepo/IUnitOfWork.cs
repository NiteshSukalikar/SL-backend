﻿
namespace SLClinicalStudyService.Repository.UnitOfWorkAndBaseRepo
{
    using System;
    using SLClinicalStudyService.Repository.Interface;

    /// <summary>
    /// Defines the <see cref="IUnitOfWork" />
    /// </summary>
    public interface IUnitOfWork : IDisposable
    {
        /// <summary>
        /// Gets the UserDetailsModel
        /// </summary>
        ICSRepository CSRepositoryModel { get; }
        /// <summary>
        /// The Complete
        /// </summary>
        /// <returns>The <see cref="int"/></returns>
        int Complete();
    }
}

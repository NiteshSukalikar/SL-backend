using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using SLClinicalStudyService.Common.StaticConstants;
using SLClinicalStudyService.Infrastructure.DataAccess;
using SLClinicalStudyService.Repository.Implementation;
using SLClinicalStudyService.Repository.Interface;
using SLClinicalStudyService.Repository.UnitOfWorkAndBaseRepo;
using SLClinicalStudyService.Services.Implementation;
using SLClinicalStudyService.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace SLClinicalStudyService
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            ReadConfigSettings();

            services.AddSingleton(Configuration);
            services.AddDbContext<IEHDbContext>(options => options.UseSqlServer(Constants.DbConn));
            services.AddTransient<IUnitOfWork, UnitOfWork>();
            services.AddTransient<ICSRepository, CSRepository>();
            services.AddTransient<ICSService, CSService>();
            services.AddControllers();

            services.AddTransient<ICSService, CSService>();
            services.AddTransient<ICSRepository, CSRepository>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddTransient<IUnitOfWork, UnitOfWork>();
            services.AddTransient<HttpClient, HttpClient>();
            services.AddCors();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "SLClinicalStudyService", Version = "v1" });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();             
            }

            app.UseSwagger();
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "SLClinicalStudyService v1"));

            app.UseHttpsRedirection();
            app.UseCors(builder => builder
                           .AllowAnyHeader()
                           .AllowAnyMethod()
                           .AllowAnyOrigin());

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

        private void ReadConfigSettings()
        {
            Constants.DbConn = Configuration["App:DbConn"];
        }
    }
}

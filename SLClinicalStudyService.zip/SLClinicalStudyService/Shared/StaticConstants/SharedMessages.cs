﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.StaticConstants
{
    public static class SharedMessages
    {

        /// <summary>
        /// Gets or sets the SupportEmail
        /// </summary>
        public static string SupportEmail { get; set; }

        /// <summary>
        /// Gets or sets the GeneralException
        /// </summary>
        public static string GeneralException = "Something went wrong! Please try after sometime.";

        /// <summary>
        /// Gets or sets the RecordNotFound
        /// </summary>
        public static string RecordNotFound = "Record Not Found";

        /// <summary>
        /// Gets or sets the SavedSuccessfully
        /// </summary>
        public static string SavedSuccessfully = "Saved Successfully";

        /// <summary>
        /// Gets or sets the UpdatedSuccessfully
        /// </summary>
        public static string UpdatedSuccessfully = "Updated Successfully";

        /// <summary>
        /// Gets or sets the DeletedSuccessfully
        /// </summary>
        public static string DeletedSuccessfully = "Deleted Successfully";

        /// <summary>
        /// Gets or sets the ServerErrorCode
        /// </summary>
        public static string ServerErrorCode = "500";

        /// <summary>
        /// Gets or sets the InvalidTokenCode
        /// </summary>
        public static string InvalidTokenCode = "401";

        /// <summary>
        /// Gets or sets the Ok
        /// </summary>
        public static string Ok = "200";

        /// <summary>
        /// Gets or sets the BadRequest
        /// </summary>
        public static string BadRequest = "400";

        /// <summary>
        /// Gets or sets the InvalidToken
        /// </summary>
        //public static string InvalidToken = "Invalid Token";

        /// <summary>
        /// Internal server error
        /// </summary>
        public static string InternalServerError = "Internal server error";
        public static string Success = "Success";
    }
}
